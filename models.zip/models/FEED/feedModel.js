
const fs = require('fs');
const db = require("../../config/connection");
var timeAgo = require('node-time-ago');
const merge = require('deepmerge');
const {
    getVideoDurationInSeconds
} = require('get-video-duration')
var bodyParser = require('body-parser');
var timeout = require('connect-timeout');
const multer = require('fastify-multer');
const crypto = require("crypto");
const {
    exec
} = require("child_process");
var path = require('path')
var storage = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, '../uploads/video/');
    },
    filename: function(req, file, cb) {
        cb(null, "feeds_" +crypto.createHash('md5').update('abcdefgh').digest('hex') + Date.now() + path.extname(file.originalname));
    }
});
var feed = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, '../uploads/feeds/');
    },
    filename: function(req, file, cb) {
        cb(null, "feeds_" +crypto.createHash('md5').update('abcdefgh').digest('hex') + Date.now() + path.extname(file.originalname));
    }
});
var comment = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, '../uploads/comment_media/');
    },
    filename: function(req, file, cb) {
        cb(null, "feeds_comment_" + crypto.createHash('md5').update('abcdefgh').digest('hex') + Date.now() + path.extname(file.originalname));
    }
});
exports.follow_user = async (req, res) => {
	try {
    if (req.body.followered_to_id && req.body.follower_by_id && req.body.follower_status) {
        db.query(`SELECT *  from tbl_followers where followered_to_id = ? AND follower_by_id = ? `, [req.body.followered_to_id, req.body.follower_by_id], function(error, results1, fields) {
            if (error) throw error;
            if (results1.length <= 0) {
                db.query(`INSERT INTO tbl_followers SET ?`, req.body, function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: "fail"
                        });
                    } else {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success"
                        });
                    }
                });
            } else {
                db.query(`UPDATE tbl_followers SET follower_status = ? where followered_to_id = ? AND follower_by_id = ?`, [req.body.follower_status, req.body.followered_to_id, req.body.follower_by_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: "fail"
                        });
                    } else {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success"
                        });
                    }
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail"
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_all_count = async (req, res) => {
	try {
    if (!req.query.feed_id) {
        return res.status(400).send({
            status: 400,
            msg: "fail"
        });
    } else {
        db.query(`SELECT * FROM tbl_like_details WHERE like_details_feed_id = ?`, [req.query.feed_id], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            } else {
                if (results.length > 0) {
                    db.query(`SELECT feed_fellings, COUNT(*) as total FROM tbl_like_details WHERE like_details_feed_id = ? GROUP BY feed_fellings`, [req.query.feed_id], function(error, results12, fields) {
                        if (error) {
                            return res.status(400).send({
                                status: 400,
                                msg: "fail"
                            });
                        } else {
                            if (results12.length > 0) {
                                var final_array1 = [];
                                var cc = 0;
                                Object.keys(results12).forEach(function(key, idx, array) {
                                    var result_data = results12[key];
                                    db.query(`SELECT * FROM tbl_like_details WHERE like_details_feed_id = ? AND feed_fellings = ?`, [req.query.feed_id, result_data.feed_fellings], function(err, rows, fields) {
                                        if (err) {
                                            return res.status(400).send({
                                                status: 400,
                                                msg: err
                                            });
                                        } else {
                                            if (rows.length > 0) {
                                                cc = cc + rows.length;
                                                var d = [];
                                                Object.keys(rows).forEach(function(key1, idx1, array1) {
                                                    var final = rows[key1];
                                                    //// //////console.log(final.like_details_liked_user_id);
                                                    db.query(`SELECT * FROM tbl_user_profile WHERE user_id = ? `, [final.like_details_liked_user_id], function(err, rows_user, fields) {
                                                        if (err) {
                                                            return res.status(400).send({
                                                                status: 400,
                                                                msg: err
                                                            });
                                                        } else {
                                                            if (rows_user.length > 0) {
                                                                var totalfriend = 0;
                                                                db.query(`SELECT * FROM tbl_friend_request WHERE (receiver_user_id = ? or sender_user_id = ?) AND request_status = ?`, [rows_user[0].user_id, rows_user[0].user_id, '1'], function(error, results1167, fields) {
                                                                    if (error) {
                                                                        totalfriend = 0;
                                                                    } else {
                                                                        totalfriend = results1167.length;
                                                                    }
                                                                    d.push({
                                                                        user_id: rows_user[0].user_id,
                                                                        user_name: rows_user[0].user_name,
                                                                        user_profile_img: rows_user[0].user_profile_img,
                                                                        user_phone: rows_user[0].user_phone,
                                                                        friendCount: totalfriend
                                                                    });
                                                                    if (idx1 === array1.length - 1) {
                                                                        final_array1.push({
                                                                            feed_fellings: result_data.feed_fellings,
                                                                            count: result_data.total,
                                                                            user: d
                                                                        });
                                                                    }
                                                                    if (idx === array.length - 1) {
                                                                        return res.status(200).send({
                                                                            status: 200,
                                                                            msg: "Success",
                                                                            totalLikeCount: cc,
                                                                            feedCountList: final_array1
                                                                        });
                                                                    }
                                                                });
                                                            }
                                                        }
                                                    });

                                                });
                                            }
                                        }
                                    });
                                });
                            }
                        }
                    });
                } else {
                    return res.status(404).send({
                        status: 404,
                        msg: "No Record Found",
                         totalLikeCount: 0,
                                                                            feedCountList: []
                    });
                }
            }
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.hide_feed = async (req, res) => {
	try {
    let upload = multer({
        storage: storage,
    }).single('user_profile_background');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        } else {
            if (req.body.feed_id && req.body.feed_hide_user_id && req.body.feed_user_id) {
                db.query(`SELECT *  from tbl_feed_hide where feed_user_id = ? AND feed_hide_user_id = ? AND feed_id = ?`, [req.body.feed_user_id, req.body.feed_hide_user_id, req.body.feed_id], function(error, results1, fields) {
                    if (error) throw error;
                    if (results1.length <= 0) {
                        db.query(`INSERT INTO tbl_feed_hide SET ?`, req.body, function(error, results, fields) {
                            if (error) {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail"
                                });
                            } else {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Success",
                                    feed_hide_id: results.insertId
                                });
                            }
                        });
                    } else {
                        return res.status(422).send({
                            status: 422,
                            msg: "Record already exists",
                            feed_hide_id:0
                        });
                    }
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                    feed_hide_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.report_feed = async (req, res) => {
	try {
    let upload = multer({
        storage: storage,
    }).single('user_profile_background');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        } else {
            if (req.body.feed_id && req.body.feed_report_user_id && req.body.feed_user_id) {
                db.query(`INSERT INTO tbl_feed_report SET ?`, req.body, function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: "fail"
                        });
                    } else {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success"
                        });
                    }
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.save_feed = async (req, res) => {
	try {
    let upload = multer({
        storage: storage,
    }).single('user_profile_background');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        } else {
            if (req.body.feed_id && req.body.save_feed_user_id) {
                db.query(`SELECT *  from tbl_save_feed where save_feed_user_id = ? AND feed_id = ?`, [req.body.save_feed_user_id, req.body.feed_id], function(error, results1, fields) {
                    if (error) throw error;
                    if (results1.length <= 0) {
                        db.query(`INSERT INTO tbl_save_feed SET ?`, req.body, function(error, results, fields) {
                            if (error) {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail"
                                });
                            } else {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Success"
                                });
                            }
                        });
                    } else {
                        return res.status(422).send({
                            status: 422,
                            msg: "Record already exists"
                        });
                    }
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.update_feed_group_status = async (req, res) => {
	try {
    if (req.query.feed_group_status && req.query.group_ids) {
        var final_array = [];
        var array = (req.query.group_ids).split(",");
        //// //////console.log(array.length);
        let i = 0
        while (i < array.length) {
            db.query(`UPDATE tbl_feed SET feed_group_status = ? where feed_type = ?`, [req.query.feed_group_status, array[i]], function(error, results, fields) {
                if (error) {
                    return res.status(400).send({
                        status: 400,
                        msg: "fail"
                    });
                } else {
                    if (i == array.length) {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success"
                        });
                    }
                }
            });
            i++;
        }
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail1"
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.edit_feeds = async (req, res) => {
	try {
    let upload = multer({
        storage: feed,
    }).fields([{
        name: 'feed_media',
        maxCount: 10
    }, {
        name: 'page_profile_picture'
    }]);
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            console.log(req.body);
            if (req.body.feed_user_id && req.body.feed_id) {
                  db.query(`SELECT *  from tbl_feed where feed_user_id = ? AND feed_id = ?`, [req.body.feed_user_id, req.body.feed_id], function(error, results156, fields) {
                    if (error){ return res.status(400).send({
                status: 400,
                msg: error
            });}else{
                    if (results156.length > 0) {
                var i = 0;
                var feed_media = [];
                var feed_media_type = '';
                var feed_short_video = [];
                var feed_video_length = [];
                var feed_video_thumbnail = [];
                if (typeof req.files.feed_media !== 'undefined') {
                    Object.keys(req.files.feed_media).forEach(function(key, idx1, array1) {
                        var result_file = req.files.feed_media[key];
                        let ext = result_file.originalname.substring(result_file.originalname.lastIndexOf('.'), result_file.originalname.length);
                        if (ext == ".png" || ext == ".jpg" || ext == ".jpeg") {
                            let image_file_path = result_file.path;
                            let ext = (result_file.filename).substring((result_file.filename).lastIndexOf('.'), (result_file.filename).length);
                            let image = "feed_image_" + crypto.createHash('md5').update('abcdefgh').digest('hex') + Date.now() + ext;
                            let path_to_store_generated_width = "../uploads/feeds/" + image;
                            let cmd = "ffmpeg -i " + image_file_path + " -vf scale=iw*2:ih*2 " + path_to_store_generated_width;
                            exec(cmd, (error, stdout, stderr) => {
                                if (error) {
                                    i++;
                                    //   //// //////console.log(`error: ${error.message}`);
                                    // return;
                                }
                                if (stderr) {
                                    //  //// //////console.log(`stderr: ${stderr}`);
                                    //return;
                                }
                                //  //// //////console.log(`stdout: ${stdout}`);
                            });
                            feed_media.push(define.BASE_URL+"feeds/"+image);
                            if (feed_media_type == '')
                                feed_media_type = 'image';
                            // fs.unlink(result_file.path);
                        }
                        let video_file_path = result_file.path;
                        getVideoDurationInSeconds(video_file_path).then((duration) => {
                            if (ext === '.mov' || ext === '.avchd' || ext === '.mkv' || ext === '.webm' || ext === '.gif' || ext === '.mp4' || ext === 'video/ogg' || ext === '.wmv' || ext === 'video/x-flv' || ext === '.avi') {
                                let video_file_path = result_file.path;
                                let ext = (result_file.filename).substring((result_file.filename).lastIndexOf('.'), (result_file.filename).length);

                                let video = "feed_video_" + crypto.createHash('md5').update('abcdefgh').digest('hex') + Date.now() + ext;
                                let path_to_store_generated_width = "../uploads/feeds/" + video;
                                let cmd = "ffmpeg -i " + video_file_path + " -max_muxing_queue_size 21512512 -vf scale=iw*2:ih*2 -preset slow -crf 28 " + path_to_store_generated_width;
                                exec(cmd, (error, stdout, stderr) => {
                                    if (error) {
                                        i = 1;
                                        //   //// //////console.log(`error: ${error.message}`);
                                        // return;
                                    }
                                    if (stderr) {
                                        //  //// //////console.log(`stderr: ${stderr}`);
                                        //return;
                                    }
                                    //  //// //////console.log(`stdout: ${stdout}`);
                                });
                                let video1 = "feed_thumbnail_" + crypto.createHash('md5').update('abcdefgh').digest('hex') + Date.now() + ".jpg";
                                let path_to_store_generated_thumbnail = "../uploads/feeds/" + video1;
                                let sec = 4;
                                let cmd1 = "ffmpeg  -i " + video_file_path + " -vf scale=iw*2:ih*2 -deinterlace -an -ss " + sec + " -t 00:00:01   -r 1 -y -vcodec mjpeg -f mjpeg " + path_to_store_generated_thumbnail + " 2>&1";
                                //    exec(cmd1);
                                exec(cmd1, (error, stdout, stderr) => {
                                    if (error) {}
                                    if (stderr) {

                                    }
                                });

                                let video2 = "feed_short_video_" + crypto.createHash('md5').update('abcdefgh').digest('hex') + Date.now() + ext;
                                let path_to_store_generated_short_video = "../uploads/feeds/" + video2;
                                let cmd2 = "ffmpeg -i " + video_file_path + " -max_muxing_queue_size 21512512 -vf scale=iw*2:ih*2  -ss 00:01 -to 00:05 -c:v libx264 -crf 28 " + path_to_store_generated_short_video;
                                // exec(cmd2);
                                exec(cmd2, (error, stdout, stderr) => {
                                    if (error) {
                                        i = 1;
                                        //// //////console.log(`error: ${error.message}`);
                                        //  return;
                                    }
                                    if (stderr) {
                                        //// //////console.log(`stderr short video: ${stderr}`);
                                        // return;
                                    }
                                    //// //////console.log(`stdout: ${stdout}`);
                                });

                                //  //// //////console.log("DURATION"+duration);
                                feed_video_length.push(Math.round(duration));



                                if (feed_media_type == '')
                                    feed_media_type = 'video';

                                feed_media.push(define.BASE_URL+"feeds/"+video);
                                feed_video_thumbnail.push(define.BASE_URL+"feeds/"+video1);
                                feed_short_video.push(define.BASE_URL+"feeds/"+video2);
                                // fs.unlink(video_file_path);
                            }
                            if (idx1 === array1.length - 1) {
                                if (i == 0) {
                                    req.body.feed_media = feed_media.toString();
                                    if(req.body.old_media){
                        if(req.body.old_media!=''){
                            req.body.feed_media=req.body.old_media+","+req.body.feed_media;
                        }
                      
                    }
                      delete(req.body.old_media);
                                    req.body.feed_video_thumbnail = feed_video_thumbnail.toString();
                                    req.body.feed_short_video = feed_short_video.toString();
                                    //// //////console.log(feed_video_length);
                                    req.body.feed_video_length = feed_video_length.toString();
                                    req.body.feed_media_type = feed_media_type;
                                    var feed_id= req.body.feed_id;
                                    delete(req.body.feed_id);
                                    db.query(`UPDATE tbl_feed SET ? where feed_user_id = ? AND feed_id = ?`, [req.body,req.body.feed_user_id, feed_id], function(error, results, fields) {
                                        if (error) {
                                            return res.status(400).send({
                                                status: 400,
                                                msg: error
                                            });
                                        } else {
                                            return res.status(200).send({
                                                status: 200,
                                                msg: "Success"
                                            });
                                        }
                                    });
                                } else {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: "Media file is corrupted "
                                    });
                                }
                            }
                        });
                    });
                } else {
                  //  if(req.body.old_media){
                        console.log(req.body.old_media);
                     //   if(req.body.old_media!=''){
                            req.body.feed_media=req.body.old_media;
                        //}
                       
                   // }
                     delete(req.body.old_media);
                     var feed_id= req.body.feed_id;
                     delete(req.body.feed_id);
                                    db.query(`UPDATE tbl_feed SET ? where feed_user_id = ? AND feed_id = ?`, [req.body,req.body.feed_user_id, feed_id], function(error, results, fields) {
                                        if (error) {
                            return res.status(400).send({
                                status: 400,
                                msg: error
                            });
                        } else {
                            return res.status(200).send({
                                status: 200,
                                msg: "Success"
                            });
                        }
                    });
                }
                    } else {
                return res.status(400).send({
                    status: 400,
                    msg: "Record not found."
                });
            }
            }
                  });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1"
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.insert_feed = async (req, res) => {
	try {
    let upload = multer({
        storage: feed,
    }).fields([{
        name: 'feed_media',
        maxCount: 10
    }, {
        name: 'page_profile_picture'
    }]);
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        } else {
            if (req.body.feed_user_id) {
                //console.log(req.files);
                //console.log(req.body);
                var i = 0;
                var feed_media = [];
                var feed_media_type = '';
                var feed_short_video = [];
                var feed_video_length = [];
                var feed_video_thumbnail = [];
                if (typeof req.files.feed_media !== 'undefined') {
                    Object.keys(req.files.feed_media).forEach(function(key, idx1, array1) {
                        var result_file = req.files.feed_media[key];
                        let ext = result_file.originalname.substring(result_file.originalname.lastIndexOf('.'), result_file.originalname.length);
                        if (ext == ".png" || ext == ".jpg" || ext == ".jpeg" || ext == ".tif" || ext == ".bmp" || ext == ".raw" || ext == ".cr2" || ext == ".sr2") {
                            let image_file_path = result_file.path;
                            let ext = (result_file.filename).substring((result_file.filename).lastIndexOf('.'), (result_file.filename).length);
                            let image = "feeds_image_" + crypto.createHash('md5').update('abcdefgh').digest('hex') + Date.now() + ext;
                            let path_to_store_generated_width = "../uploads/feeds/" + image;
                            let cmd = "ffmpeg -i " + image_file_path + " -vf scale=iw*2:ih*2 " + path_to_store_generated_width;
                            exec(cmd, (error, stdout, stderr) => {
                                if (error) {
                                    i++;
                                   console.log(`error: ${error.message}`);
                                    // return;
                                }
                                if (stderr) {
                                console.log(`stderr: ${stderr}`);
                                    //return;
                                }
                                //  //// //////console.log(`stdout: ${stdout}`);
                            });
                            feed_media.push(define.BASE_URL+"feeds/"+image);
                         //   fs.unlinkSync(image_file_path);
                            if (feed_media_type == '')
                                feed_media_type = 'image';
                                if (idx1 === array1.length - 1) {
                                if (i == 0) {
                                    //console.log(feed_media.toString());
                                    req.body.feed_media = feed_media.toString();
                                    req.body.feed_video_thumbnail = feed_video_thumbnail.toString();
                                    req.body.feed_short_video = feed_short_video.toString();
                                    //// //////console.log(feed_video_length);
                                    req.body.feed_video_length = feed_video_length.toString();
                                    req.body.feed_media_type = feed_media_type;
                                    db.query(`INSERT INTO tbl_feed SET ?`, req.body, function(error, results, fields) {
                                        if (error) {
                                            return res.status(400).send({
                                                status: 400,
                                                msg: "fail1"
                                            });
                                        } else {
                                            return res.status(200).send({
                                                status: 200,
                                                msg: "Success",
                                                test: "Now video Uploaded successfully"
                                            });
                                        }
                                    });
                                } else {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: "Media file is corrupted "
                                    });
                                }
                            }
                        }
                        let video_file_path = result_file.path;
                         if (ext === '.mov' || ext === '.avchd' || ext === '.mkv' || ext === '.webm' || ext === '.gif' || ext === '.mp4' || ext === 'video/ogg' || ext === '.wmv' || ext === 'video/x-flv' || ext === '.avi') {
                        getVideoDurationInSeconds(video_file_path).then((duration) => {
                           
                                let video_file_path = result_file.path;
                                let ext = (result_file.filename).substring((result_file.filename).lastIndexOf('.'), (result_file.filename).length);

                                let video = "feed_video_" + crypto.createHash('md5').update('abcdefgh').digest('hex') + Date.now() + ext;
                                let path_to_store_generated_width = "../uploads/feeds/" + video;
                                let cmd = "ffmpeg -i " + video_file_path + " -preset slow -crf 40 " + path_to_store_generated_width;
                                exec(cmd, (error, stdout, stderr) => {
                                    if (error) {
                                        i = 1;
                                 console.log(`error: ${error.message}`);
                                        // return;
                                    }
                                    if (stderr) {
                                   console.log(`stderr: ${stderr}`);
                                        //return;
                                    }
                                    //  //// //////console.log(`stdout: ${stdout}`);
                                });
                                let video1 = "feed_thumbnail_" + crypto.createHash('md5').update('abcdefgh').digest('hex') + Date.now() + ".jpg";
                                let path_to_store_generated_thumbnail = "../uploads/feeds/" + video1;
                                let sec = 4;
                                let cmd1 = "ffmpeg  -i " + video_file_path + " -vf scale=iw*2:ih*2 -deinterlace -an -ss " + sec + " -t 00:00:01   -r 1 -y -vcodec mjpeg -f mjpeg " + path_to_store_generated_thumbnail + " 2>&1";
                                //    exec(cmd1);
                                exec(cmd1, (error, stdout, stderr) => {
                                    if (error) {}
                                    if (stderr) {

                                    }
                                });

                                let video2 = "feed_short_video_" + crypto.createHash('md5').update('abcdefgh').digest('hex') + Date.now() + ext;
                                let path_to_store_generated_short_video = "../uploads/feeds/" + video2;
                                let cmd2 = "ffmpeg -i " + video_file_path + " -ss 00:01 -to 00:05 -c:v libx264 -crf 40 " + path_to_store_generated_short_video;
                                // exec(cmd2);
                                exec(cmd2, (error, stdout, stderr) => {
                                    if (error) {
                                        i = 1;
                                        console.log(`error: ${error.message}`);
                                        //  return;
                                    }
                                    if (stderr) {
                                     console.log(`stderr short video: ${stderr}`);
                                        // return;
                                    }
                                    //// //////console.log(`stdout: ${stdout}`);
                                });

                                //  //// //////console.log("DURATION"+duration);
                                feed_video_length.push(Math.round(duration));



                                if (feed_media_type == '')
                                    feed_media_type = 'video';

                                feed_media.push(define.BASE_URL+"feeds/"+video);
                                feed_video_thumbnail.push(define.BASE_URL+"feeds/"+video1);
                                feed_short_video.push(define.BASE_URL+"feeds/"+video2);
                              //  fs.unlinkSync(video_file_path);
                                    if (idx1 === array1.length - 1) {
                                if (i == 0) {
                                    //console.log(feed_media.toString());
                                    req.body.feed_media = feed_media.toString();
                                    req.body.feed_video_thumbnail = feed_video_thumbnail.toString();
                                    req.body.feed_short_video = feed_short_video.toString();
                                    //// //////console.log(feed_video_length);
                                    req.body.feed_video_length = feed_video_length.toString();
                                    req.body.feed_media_type = feed_media_type;
                                    db.query(`INSERT INTO tbl_feed SET ?`, req.body, function(error, results, fields) {
                                        if (error) {
                                            return res.status(400).send({
                                                status: 400,
                                                msg: "fail2"
                                            });
                                        } else {
                                            return res.status(200).send({
                                                status: 200,
                                                msg: "Success",
                                                test: "Now video Uploaded successfully"
                                            });
                                        }
                                    });
                                } else {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: "Media file is corrupted "
                                    });
                                }
                            }
                           
                        });
                         }
                        
                    });
                } else {
                    db.query(`INSERT INTO tbl_feed SET ?`, req.body, function(error, results, fields) {
                        if (error) {
                            return res.status(400).send({
                                status: 400,
                                msg: "fail1"
                            });
                        } else {
                            return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                test: "Now video Uploaded successfully"
                            });
                        }
                    });
                }
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1"
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_feed = async (req, res) => {
	try {
    if (req.query.page_no) {
        var pagination = [];
        var alldata = [];
        var flag = 0;
        var allsharedata = [];
        if (res.allData && res.allData.length > 0) {
            alldata = res.allData.filter((item, i, ar) => ar.indexOf(item) === i);
        }
        if (res.allShareData && res.allShareData.length > 0) {
            allsharedata = res.allShareData.filter((item, i, ar) => ar.indexOf(item) === i);
        }
        var d = [];
        d = merge(allsharedata, alldata);
        //console.log(req.query.feed_type_number );
        var feed = [];
        if (req.query.feed_type_number == 1 || req.query.feed_type_number == 0) {
            req.query.feed_user_id = res.feed_user_id;
            if (req.query.user_id && d.length > 0) {
                d = d.sort(function(a, b) {
                    return b - a;
                });
                d = d.reverse();
               console.log(d);
                d.forEach(function(element, index) {
                    var klo = element.split("#");
                    element = klo[0];
                    //console.log(element);
                    var sql = db.query(`SELECT * From tbl_feed where feed_id=?`, [element], function(error, results, fields) {
                        if (error) {
                            return res.status(400).send({
                                status: 400,
                                msg: "fail"
                            });
                        } else {
                            var flagg=1;
                         if(results.length<=0){
                             flagg=0;
                             results[0]={
                                 feed_id:''
                             }
                         }
                            db.query(`SELECT COUNT(*) AS numrows FROM tbl_feed_comment where comment_feed_id=? and comment_operation=?;
                        SELECT * FROM tbl_like_details where like_details_feed_id=? ORDER BY created_date DESC LIMIT 2;
                          SELECT * From tbl_feed_share where feed_id=?;SELECT * From tbl_feed where feed_id=?;`, [element, '0', element, results[0].feed_id, results[0].shared_feed_id], function(error, results_comment, fields) {
                                if (error) throw error;
                                var user = '';
                                var sh_user = '';
                                if(flagg==1){
                                if (klo[1] == "1") {
                                    results[0].is_shared = "1";
                                } else {
                                    results[0].is_shared = "0";
                                }
                                if (results_comment[3].length > 0) {
                                    results_comment[3][0].comment_count = 0;
                                    results_comment[3][0].feed_fellings = "8";
                                    results_comment[3][0].first_feed_fellings = "0";
                                    results_comment[3][0].last_reacted_user = "";
                                    results_comment[3][0].second_feed_fellings = "";
                                    results_comment[3][0].follow = "friend";
                                    results_comment[3][0].follower_count = 0;
                                    results_comment[3][0].shared_feed = [];
                                    results_comment[3][0].eventList = {
                                        "event_id": "",
                                        "event_user_id": "",
                                        "feed_id": "",
                                        "event_name": "",
                                        "event_contact": "",
                                        "event_address": "",
                                        "event_email": "",
                                        "event_description": "",
                                        "event_start_date": "",
                                        "event_end_date": "",
                                        "event_start_time": "",
                                        "event_end_time": "",
                                        "event_gallery": "",
                                        "event_type": "",
                                        "created_date": "",
                                        "modified_date": "",
                                        "event_business_id": "",
                                        "event_web_link": "",
                                        "event_status": "",
                                        "event_interested_count": "0",
                                        "event_going_count": "0",
                                        "going": 0,
                                        "interested": 0
                                    };
                                    results_comment[3][0].feed_duration = timeAgo(new Date(results_comment[3][0].created_date).toISOString());
                                   // results[0].shared_feed_data = results_comment[3][0];
                                } else {
                                   // results[0].shared_feed_data = {};
                                }
                                results[0].feed_duration = timeAgo(new Date(results[0].created_date).toISOString());
                                results[0].comment_count = results_comment[0][0].numrows;
                                if (results_comment[1].length > 0) {
                                    user = results_comment[1][0].like_details_liked_user_id;
                                    results[0].first_feed_fellings = results_comment[1][0].feed_fellings;
                                } else {
                                    results[0].first_feed_fellings = '';
                                }
                                if (results_comment[1].length > 1) {
                                    results[0].second_feed_fellings = results_comment[1][1].feed_fellings;
                                } else {
                                    results[0].second_feed_fellings = '';
                                }
                                if (results_comment[2].length > 0) {
                                    sh_user = results_comment[2][0].feed_share_user_id;
                                }
                                 }
                                //////console.log(user);
                                db.query(`SELECT * FROM tbl_user_profile where user_id=?;
                                    Select count(*) as total from tbl_followers where follower_by_id=? and followered_to_id=?;
                                    Select count(*) as total from tbl_followers where followered_to_id=? and follower_status=?;
                                    Select * from tbl_like_details where  like_details_feed_id=? and like_details_liked_user_id=?;
                                    SELECT * FROM tbl_user_profile where user_id=?;
                                     SELECT * FROM tbl_events where event_id=?;
                                      Select count(*) as total from tbl_event_going where event_going_user_id=? and event_id=?;
                                      Select count(*) as total from tbl_event_intersted where event_intersted_user_id=? and event_id=?;
                                      SELECT * FROM tbl_user_profile where user_id=?`, [user,
                                    results[0].feed_user_id, req.query.user_id,
                                    results[0].feed_user_id, 1,
                                    results[0].feed_id, req.query.user_id,
                                    sh_user,
                                    results[0].event_id,
                                    req.query.user_id, results[0].event_id,
                                    req.query.user_id, results[0].event_id,
                                    results[0].feed_user_id
                                ], function(error, results_rat, fields) {
                                    if (error) throw error;
                                     if(flagg==1){
                                         if(results_rat[8].length>0){
                                              results[0].feed_user_name=results_rat[8][0].user_name;
                                              results[0].feed_user_image=results_rat[8][0].user_profile_img;
                                         }
                                    if (results_rat[0].length > 0) {
                                        results[0].last_reacted_user = results_rat[0][0].user_name;
                                    } else {
                                        results[0].last_reacted_user = '';
                                    }
                                    if (results_comment[2].length > 0) {
                                        if (results_rat[4].length > 0) {
                                            results_comment[2][0].user_name = results_rat[4][0].user_name;
                                            results_comment[2][0].user_profile_img = results_rat[4][0].user_profile_img;
                                        } else {
                                            results_comment[2][0].user_name = '';
                                            results_comment[2][0].user_profile_img = '';
                                        }
                                    }
                                    if (results_rat[5].length > 0) {
                                        results_rat[5][0].going = results_rat[6][0].total > 0 ? 1 : 0;
                                        results_rat[5][0].interested = results_rat[7][0].total > 0 ? 1 : 0;
                                        results[0].eventList = results_rat[5][0];
                                    } else {
                                        results[0].eventList = {
                                            "event_id": "",
                                            "event_user_id": "",
                                            "feed_id": "",
                                            "event_name": "",
                                            "event_contact": "",
                                            "event_address": "",
                                            "event_email": "",
                                            "event_description": "",
                                            "event_start_date": "",
                                            "event_end_date": "",
                                            "event_start_time": "",
                                            "event_end_time": "",
                                            "event_gallery": "",
                                            "event_type": "",
                                            "created_date": "",
                                            "modified_date": "",
                                            "event_business_id": "",
                                            "event_web_link": "",
                                            "event_status": "",
                                            "event_interested_count": "0",
                                            "event_going_count": "0",
                                            "going": 0,
                                            "interested": 0
                                        };
                                    }
                                    results[0].follow = results_rat[1][0].total > 0 ? 'friend' : 'friend';
                                    results[0].feed_fellings = results_rat[3].length > 0 ? results_rat[3][0].feed_fellings : '8';
                                    results[0].follower_count = results_rat[2][0].total;
                                    if ( results_comment[2].length > 0) {
                                        results[0].shared_feed = results_comment[2][0];
                                    } else {
                                        results[0].shared_feed = [];
                                    }
                                  
                                    feed.push(results[0]);
                                    }
                                    if (index == d.length - 1) {
                                      feed=  feed.sort((a, b) => (a.feed_id < b.feed_id) ? 1 : -1);
                                        let no_of_records_per_page = 3;
                                        let max_pages = parseInt(Math.ceil((feed.length) / no_of_records_per_page));
                                        if (req.query.page_no <= max_pages) {
                                            let page_no = req.query.page_no;

                                            // PAGINATION START

                                            let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
                                            let sliceData = feed.slice(offset, offset + no_of_records_per_page)
                                            var pagination = {
                                                total_rows: feed.length,
                                                total_pages: parseInt(Math.ceil((feed.length) / no_of_records_per_page)),
                                                per_page: no_of_records_per_page,
                                                offset: offset,
                                                current_page_no: page_no
                                            };
                                            // PAGINATION END

                                            return res.status(200).send({
                                                status: 200,
                                                msg: "Success",
                                                feedListCount: feed.length,
                                                feedList: sliceData,
                                                pagination: pagination
                                            });
                                        } else {
                                            return res.status(404).send({
                                                status: 404,
                                                msg: "Page no missing or Its incorrect.",
                                                   feedListCount: 0,
                                                feedList: [],
                                                 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }

                                            });
                                        }
                                    }
                                });
                            });
                        }
                    });
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail12",
                                          feedListCount: 0,
                                                feedList: [],
                                                 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                });
            }
        } else if (req.query.feed_type_number == 2) {
            //console.log(req.query);
            d=alldata;
            req.query.feed_user_id = res.feed_user_id;
            if (req.query.user_id && d.length > 0) {
                d = d.sort(function(a, b) {
                    return a - b;
                });
                d = d.reverse();
                console.log(d);
                d.forEach(function(element, index) {
                    var klo = element.split("#");
                    element = klo[0];
                    //////console.log(klo[1]);
                    db.query(`SELECT * From tbl_feed where feed_id=?`, [element], function(error, results, fields) {
                        if (error) {
                            return res.status(400).send({
                                status: 400,
                                msg: "fail"
                            });
                        } else {
                            if(results.length<=0){
                                results[0]={
                                    feed_id:'',
                                    shared_feed_id:''
                                }
                            }
                            //console.log(results[0]);
                            db.query(`SELECT COUNT(*) AS numrows FROM tbl_feed_comment where comment_feed_id=? and comment_operation=?;
                        SELECT * FROM tbl_like_details where like_details_feed_id=? ORDER BY created_date DESC LIMIT 2;
                        SELECT * From tbl_feed_share where feed_id=?;SELECT * From tbl_feed where feed_id=?;`, [element, '0', element, results[0].feed_id, results[0].shared_feed_id], function(error, results_comment, fields) {
                                if (error) throw error;
                                var user = '';
                                var sh_user = '';
                                if (klo[1] == "1") {
                                    results[0].is_shared = "1";
                                } else {
                                    results[0].is_shared = "0";
                                }
                                if (results_comment[3].length > 0) {
                                    results_comment[3][0].comment_count = 0;
                                    results_comment[3][0].feed_fellings = "8";
                                    results_comment[3][0].first_feed_fellings = "0";
                                    results_comment[3][0].last_reacted_user = "";
                                    results_comment[3][0].second_feed_fellings = "";
                                    results_comment[3][0].follow = "friend";
                                    results_comment[3][0].follower_count = 0;
                                    results_comment[3][0].shared_feed = [];
                                    results_comment[3][0].eventList = {
                                        "event_id": "",
                                        "event_user_id": "",
                                        "feed_id": "",
                                        "event_name": "",
                                        "event_contact": "",
                                        "event_address": "",
                                        "event_email": "",
                                        "event_description": "",
                                        "event_start_date": "",
                                        "event_end_date": "",
                                        "event_start_time": "",
                                        "event_end_time": "",
                                        "event_gallery": "",
                                        "event_type": "",
                                        "created_date": "",
                                        "modified_date": "",
                                        "event_business_id": "",
                                        "event_web_link": "",
                                        "event_status": "",
                                        "event_interested_count": "0",
                                        "event_going_count": "0",
                                        "going": 0,
                                        "interested": 0
                                    };
                                    results_comment[3][0].feed_duration = timeAgo(new Date(results_comment[3][0].created_date).toISOString());
                                  //  results[0].shared_feed_data = results_comment[3][0];
                                } else {
                                   // results[0].shared_feed_data = {};
                                }
                                 if(results[0].feed_id!=''){
                                results[0].feed_duration = timeAgo(new Date(results[0].created_date).toISOString());
                                results[0].comment_count = results_comment[0][0].numrows;
                                if (results_comment[1].length > 0) {
                                    user = results_comment[1][0].like_details_liked_user_id;
                                    results[0].first_feed_fellings = results_comment[1][0].feed_fellings;
                                } else {
                                    results[0].first_feed_fellings = '';
                                }
                                if (results_comment[1].length > 1) {
                                    results[0].second_feed_fellings = results_comment[1][1].feed_fellings;
                                } else {
                                    results[0].second_feed_fellings = '';
                                }
                                if (results_comment[2].length > 0) {
                                    sh_user = results_comment[2][0].feed_share_user_id;
                                }
                                 }
                                //////console.log(user);
                                db.query(`SELECT * FROM tbl_user_profile where user_id=?;
                                    Select count(*) as total from tbl_followers where follower_by_id=? and followered_to_id=?;
                                    Select count(*) as total from tbl_followers where followered_to_id=? and follower_status=?;
                                    Select * from tbl_like_details where  like_details_feed_id=? and like_details_liked_user_id=?;
                                    SELECT * FROM tbl_user_profile where user_id=?;
                                     SELECT * FROM tbl_events where event_id=?;
                                      Select count(*) as total from tbl_event_going where event_going_user_id=? and event_id=?;
                                      Select count(*) as total from tbl_event_intersted where event_intersted_user_id=? and event_id=?;
                                      `, [user,
                                    results[0].feed_user_id, req.query.user_id,
                                    results[0].feed_user_id, 1,
                                    results[0].feed_id, req.query.user_id,
                                    sh_user,
                                    results[0].event_id,
                                    req.query.user_id, results[0].event_id,
                                    req.query.user_id, results[0].event_id
                                ], function(error, results_rat, fields) {
                                    if (error) throw error;
                                    if (results_rat[0].length > 0) {
                                        results[0].last_reacted_user = results_rat[0][0].user_name;
                                    } else {
                                        results[0].last_reacted_user = '';
                                    }
                                    if (results_comment[2].length > 0) {
                                        if (results_rat[4].length > 0) {
                                            results_comment[2][0].user_name = results_rat[4][0].user_name;
                                            results_comment[2][0].user_profile_img = results_rat[4][0].user_profile_img;
                                        } else {
                                            results_comment[2][0].user_name = '';
                                            results_comment[2][0].user_profile_img = '';
                                        }
                                    }
                                    if (results_rat[5].length > 0) {
                                        results_rat[5][0].going = results_rat[6][0].total > 0 ? 1 : 0;
                                        results_rat[5][0].interested = results_rat[7][0].total > 0 ? 1 : 0;
                                        results[0].eventList = results_rat[5][0];
                                    } else {
                                        results[0].eventList = {
                                            "event_id": "",
                                            "event_user_id": "",
                                            "feed_id": "",
                                            "event_name": "",
                                            "event_contact": "",
                                            "event_address": "",
                                            "event_email": "",
                                            "event_description": "",
                                            "event_start_date": "",
                                            "event_end_date": "",
                                            "event_start_time": "",
                                            "event_end_time": "",
                                            "event_gallery": "",
                                            "event_type": "",
                                            "created_date": "",
                                            "modified_date": "",
                                            "event_business_id": "",
                                            "event_web_link": "",
                                            "event_status": "",
                                            "event_interested_count": "0",
                                            "event_going_count": "0",
                                            "going": 0,
                                            "interested": 0
                                        };
                                    }
                                    results[0].follow = results_rat[1][0].total > 0 ? 'friend' : 'friend';
                                    results[0].feed_fellings = results_rat[3].length > 0 ? results_rat[3][0].feed_fellings : '8';
                                    results[0].follower_count = results_rat[2][0].total;
                                    if (results_comment[2].length > 0) {
                                        results[0].shared_feed = results_comment[2][0];
                                    } else {
                                        results[0].shared_feed = [];
                                    }
                                    if(results[0].feed_id!='')
                                    feed.push(results[0]);
                                    if (index == d.length - 1) {
                                         feed=  feed.sort((a, b) => (a.feed_id < b.feed_id) ? 1 : -1);
                                        let no_of_records_per_page = 3;
                                        let max_pages = parseInt(Math.ceil((feed.length) / no_of_records_per_page));
                                        if (req.query.page_no <= max_pages) {
                                            let page_no = req.query.page_no;

                                            // PAGINATION START

                                            let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
                                            let sliceData = feed.slice(offset, offset + no_of_records_per_page)
                                            var pagination = {
                                                total_rows: feed.length,
                                                total_pages: parseInt(Math.ceil((feed.length) / no_of_records_per_page)),
                                                per_page: no_of_records_per_page,
                                                offset: offset,
                                                current_page_no: page_no
                                            };
                                            // PAGINATION END

                                            return res.status(200).send({
                                                status: 200,
                                                msg: "Success",
                                                feedListCount: feed.length,
                                                feedList: sliceData,
                                                pagination: pagination
                                            });
                                        } else {
                                            return res.status(404).send({
                                                status: 404,
                                                msg: "Page no missing or Its incorrect.",
                                                                      feedListCount: 0,
                                                feedList: [],
                                                 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                                            });
                                        }
                                    }
                                });
                            });
                        }
                    });
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                                          feedListCount: 0,
                                                feedList: [],
                                                 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                });
            }
        } else {
            return res.status(400).send({
                status: 400,
                msg: "fail",
                                      feedListCount: 0,
                                                feedList: [],
                                                 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
            });
        }
    } else {
        return res.status(404).send({
            status: 404,
            msg: "Page no missing or Its incorrect",
                                  feedListCount: 0,
                                                feedList: [],
                                                 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
        });
    }
	} catch (err) {
	    console.log(err);
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_not_approved_feed = async (req, res) => {
	try {
    if (req.query.page_no) {
        var pagination = [];
        var alldata = [];
        var flag = 0;
        var allsharedata = [];
        if (res.allData && res.allData.length > 0) {
            alldata = res.allData.filter((item, i, ar) => ar.indexOf(item) === i);
        }
        if (res.allShareData && res.allShareData.length > 0) {
            allsharedata = res.allShareData.filter((item, i, ar) => ar.indexOf(item) === i);
        }
        var d = [];
        d = merge(allsharedata, alldata);
        //////console.log(d);
        var feed = [];
        if (req.query.group_id) {
            //  req.body.feed_user_id = res.feed_user_id;
            if (req.query.user_id && d.length > 0) {
                d = d.sort(function(a, b) {
                    return a - b;
                });
                d = d.reverse();
                //////console.log(d.length);
                d.forEach(function(element, index) {
                    var klo = element.split("#");
                    element = klo[0];
                    //////console.log(klo[1]);
                    db.query(`SELECT * From tbl_feed where feed_id=?`, [element], function(error, results, fields) {
                        if (error) {
                            return res.status(400).send({
                                status: 400,
                                msg: "fail"
                            });
                        } else {
                              if(results.length<=0){
                                results[0]={
                                    feed_id:'',
                                    shared_feed_id:''
                                }
                            }
                            db.query(`SELECT COUNT(*) AS numrows FROM tbl_feed_comment where comment_feed_id=? and comment_operation=?;
                        SELECT * FROM tbl_like_details where like_details_feed_id=? ORDER BY created_date DESC LIMIT 2;
                        SELECT * From tbl_feed_share where feed_id=?;`, [element, '0', element, results[0].feed_id], function(error, results_comment, fields) {
                                if (error) throw error;
                                var user = '';
                                var sh_user = '';
                                if (klo[1] == "1") {
                                    results[0].is_shared = "1";
                                } else {
                                    results[0].is_shared = "0";
                                }
                                if( results[0].feed_id!=''){
                                results[0].feed_duration = timeAgo(new Date(results[0].created_date).toISOString());
                                results[0].comment_count = results_comment[0][0].numrows;
                                if (results_comment[1].length > 0) {
                                    user = results_comment[1][0].like_details_liked_user_id;
                                    results[0].first_feed_fellings = results_comment[1][0].feed_fellings;
                                } else {
                                    results[0].first_feed_fellings = '';
                                }
                                if (results_comment[1].length > 1) {
                                    results[0].second_feed_fellings = results_comment[1][1].feed_fellings;
                                } else {
                                    results[0].second_feed_fellings = '';
                                }
                                if (results_comment[2].length > 0) {
                                    sh_user = results_comment[2][0].feed_share_user_id;
                                }
                                }
                                //////console.log(user);
                                db.query(`SELECT * FROM tbl_user_profile where user_id=?;
                                    Select count(*) as total from tbl_followers where follower_by_id=? and followered_to_id=?;
                                    Select count(*) as total from tbl_followers where followered_to_id=? and follower_status=?;
                                    Select * from tbl_like_details where  like_details_feed_id=? and like_details_liked_user_id=?;
                                    SELECT * FROM tbl_user_profile where user_id=?;
                                     SELECT * FROM tbl_events where event_id=?;
                                      Select count(*) as total from tbl_event_going where event_going_user_id=? and event_id=?;
                                      Select count(*) as total from tbl_event_intersted where event_intersted_user_id=? and event_id=?;
                                      `, [user,
                                    results[0].feed_user_id, req.query.user_id,
                                    results[0].feed_user_id, 1,
                                    results[0].feed_id, req.query.user_id,
                                    sh_user,
                                    results[0].event_id,
                                    req.query.user_id, results[0].event_id,
                                    req.query.user_id, results[0].event_id
                                ], function(error, results_rat, fields) {
                                    if (error) throw error;
                                      if( results[0].feed_id!=''){
                                    if (results_rat[0].length > 0) {
                                        results[0].last_reacted_user = results_rat[0][0].user_name;
                                    } else {
                                        results[0].last_reacted_user = '';
                                    }
                                    if (results_comment[2].length > 0) {
                                        if (results_rat[4].length > 0) {
                                            results_comment[2][0].user_name = results_rat[4][0].user_name;
                                            results_comment[2][0].user_profile_img = results_rat[4][0].user_profile_img;
                                        } else {
                                            results_comment[2][0].user_name = '';
                                            results_comment[2][0].user_profile_img = '';
                                        }
                                    }
                                    if (results_rat[5].length > 0) {
                                        results_rat[5][0].going = results_rat[6][0].total > 0 ? 1 : 0;
                                        results_rat[5][0].interested = results_rat[7][0].total > 0 ? 1 : 0;
                                        results[0].eventList = results_rat[5][0];
                                    } else {
                                        results[0].eventList = {
                                            "event_id": "",
                                            "event_user_id": "",
                                            "feed_id": "",
                                            "event_name": "",
                                            "event_contact": "",
                                            "event_address": "",
                                            "event_email": "",
                                            "event_description": "",
                                            "event_start_date": "",
                                            "event_end_date": "",
                                            "event_start_time": "",
                                            "event_end_time": "",
                                            "event_gallery": "",
                                            "event_type": "",
                                            "created_date": "",
                                            "modified_date": "",
                                            "event_business_id": "",
                                            "event_web_link": "",
                                            "event_status": "",
                                            "event_interested_count": "0",
                                            "event_going_count": "0",
                                            "going": 0,
                                            "interested": 0
                                        };
                                    }
                                    results[0].follow = results_rat[1][0].total > 0 ? 'friend' : 'friend';
                                    results[0].feed_fellings = results_rat[3].length > 0 ? results_rat[3][0].feed_fellings : '8';
                                    results[0].follower_count = results_rat[2][0].total;
                                    if (flag == 1 && results_comment[2].length > 0) {
                                        results[0].shared_feed = results_comment[2][0];
                                    } else {
                                        results[0].shared_feed = [];
                                    }
                                    feed.push(results[0]);
                                      }
                                    if (index == d.length - 1) {
                                         feed=  feed.sort((a, b) => (a.feed_id < b.feed_id) ? 1 : -1);
                                        let no_of_records_per_page = 3;
                                        let max_pages = parseInt(Math.ceil((feed.length) / no_of_records_per_page));
                                        if (req.query.page_no <= max_pages) {
                                            let page_no = req.query.page_no;

                                            // PAGINATION START

                                            let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
                                            let sliceData = feed.slice(offset, offset + no_of_records_per_page)
                                            var pagination = {
                                                total_rows: feed.length,
                                                total_pages: parseInt(Math.ceil((feed.length) / no_of_records_per_page)),
                                                per_page: no_of_records_per_page,
                                                offset: offset,
                                                current_page_no: page_no
                                            };
                                            // PAGINATION END

                                            return res.status(200).send({
                                                status: 200,
                                                msg: "Success",
                                                notApprovedFeedListCount: feed.length,
                                                notApprovedFeedList: sliceData,
                                                pagination: pagination
                                            });
                                        } else {
                                            return res.status(404).send({
                                                status: 404,
                                                msg: "Page no missing or Its incorrect.",
                                                                      notApprovedFeedListCount: 0,
                                                notApprovedFeedList: [],
                                                 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                                            });
                                        }
                                    }
                                });
                            });
                        }
                    });
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail12",
                                                             notApprovedFeedListCount: 0,
                                                notApprovedFeedList: [],
                                                 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                });
            }
        } else {
            return res.status(400).send({
                status: 400,
                msg: "fail",
                                                         notApprovedFeedListCount: 0,
                                                notApprovedFeedList: [],
                                                 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
            });
        }
    } else {
        return res.status(404).send({
            status: 404,
            msg: "Page no missing or Its incorrect",
                                                     notApprovedFeedListCount: 0,
                                                notApprovedFeedList: [],
                                                 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_business_feed = async (req, res) => {
	try {
    if (req.query.page_no) {
        var pagination = [];
        var alldata = [];
        var flag = 0;
        var allsharedata = [];
        if (res.allData && res.allData.length > 0) {
            alldata = res.allData.filter((item, i, ar) => ar.indexOf(item) === i);
        }
        if (res.allShareData && res.allShareData.length > 0) {
            allsharedata = res.allShareData.filter((item, i, ar) => ar.indexOf(item) === i);
        }
        var d = [];
        d = merge(allsharedata, alldata);
        //////console.log(d);
        var feed = [];
        if (req.query.user_id && d.length > 0) {
            d = d.sort(function(a, b) {
                return a - b;
            });
            d = d.reverse();
            //////console.log(d.length);
            d.forEach(function(element, index) {
                var klo = element.split("#");
                element = klo[0];
                //////console.log(klo[1]);
                db.query(`SELECT * From tbl_feed where feed_id=?`, [element], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: "fail"
                        });
                    } else {
                        db.query(`SELECT COUNT(*) AS numrows FROM tbl_feed_comment where comment_feed_id=? and comment_operation=?;
                        SELECT * FROM tbl_like_details where like_details_feed_id=? ORDER BY created_date DESC LIMIT 2;
                        SELECT * From tbl_feed_share where feed_id=?;`, [element, '0', element, results[0].feed_id], function(error, results_comment, fields) {
                            if (error) throw error;
                            var user = '';
                            var sh_user = '';
                            if (klo[1] == "1") {
                                results[0].is_shared = "1";
                            } else {
                                results[0].is_shared = "0";
                            }

                            results[0].feed_duration = timeAgo(new Date(results[0].created_date).toISOString());
                            results[0].comment_count = results_comment[0][0].numrows;
                            if (results_comment[1].length > 0) {
                                user = results_comment[1][0].like_details_liked_user_id;
                                results[0].first_feed_fellings = results_comment[1][0].feed_fellings;
                            } else {
                                results[0].first_feed_fellings = '';
                            }
                            if (results_comment[1].length > 1) {
                                results[0].second_feed_fellings = results_comment[1][1].feed_fellings;
                            } else {
                                results[0].second_feed_fellings = '';
                            }
                            if (results_comment[2].length > 0) {
                                sh_user = results_comment[2][0].feed_share_user_id;
                            }
                            //////console.log(user);
                            db.query(`SELECT * FROM tbl_user_profile where user_id=?;
                                    Select count(*) as total from tbl_followers where follower_by_id=? and followered_to_id=?;
                                    Select count(*) as total from tbl_followers where followered_to_id=? and follower_status=?;
                                    Select * from tbl_like_details where  like_details_feed_id=? and like_details_liked_user_id=?;
                                    SELECT * FROM tbl_user_profile where user_id=?;
                                     SELECT * FROM tbl_events where event_id=?;
                                      Select count(*) as total from tbl_event_going where event_going_user_id=? and event_id=?;
                                      Select count(*) as total from tbl_event_intersted where event_intersted_user_id=? and event_id=?;
                                      `, [user,
                                results[0].feed_user_id, req.query.user_id,
                                results[0].feed_user_id, 1,
                                results[0].feed_id, req.query.user_id,
                                sh_user,
                                results[0].event_id,
                                req.query.user_id, results[0].event_id,
                                req.query.user_id, results[0].event_id
                            ], function(error, results_rat, fields) {
                                if (error) throw error;
                                if (results_rat[0].length > 0) {
                                    results[0].last_reacted_user = results_rat[0][0].user_name;
                                } else {
                                    results[0].last_reacted_user = '';
                                }
                                if (results_comment[2].length > 0) {
                                    if (results_rat[4].length > 0) {
                                        results_comment[2][0].user_name = results_rat[4][0].user_name;
                                        results_comment[2][0].user_profile_img = results_rat[4][0].user_profile_img;
                                    } else {
                                        results_comment[2][0].user_name = '';
                                        results_comment[2][0].user_profile_img = '';
                                    }
                                }
                                if (results_rat[5].length > 0) {
                                    results_rat[5][0].going = results_rat[6][0].total > 0 ? 1 : 0;
                                    results_rat[5][0].interested = results_rat[7][0].total > 0 ? 1 : 0;
                                    results[0].eventList = results_rat[5][0];
                                } else {
                                    results[0].eventList = {
                                        "event_id": "",
                                        "event_user_id": "",
                                        "feed_id": "",
                                        "event_name": "",
                                        "event_contact": "",
                                        "event_address": "",
                                        "event_email": "",
                                        "event_description": "",
                                        "event_start_date": "",
                                        "event_end_date": "",
                                        "event_start_time": "",
                                        "event_end_time": "",
                                        "event_gallery": "",
                                        "event_type": "",
                                        "created_date": "",
                                        "modified_date": "",
                                        "event_business_id": "",
                                        "event_web_link": "",
                                        "event_status": "",
                                        "event_interested_count": "0",
                                        "event_going_count": "0",
                                        "going": 0,
                                        "interested": 0
                                    };
                                }
                                results[0].follow = results_rat[1][0].total > 0 ? 'friend' : 'friend';
                                results[0].feed_fellings = results_rat[3].length > 0 ? results_rat[3][0].feed_fellings : '8';
                                results[0].follower_count = results_rat[2][0].total;
                                // if (flag == 1 && results_comment[2].length > 0) {
                                //     results[0].shared_feed = results_comment[2][0];
                                // } else {
                                //     results[0].shared_feed = [];
                                // }
                                feed.push(results[0]);
                                if (index == d.length - 1) {
                                     feed=  feed.sort((a, b) => (a.feed_id < b.feed_id) ? 1 : -1);
                                    let no_of_records_per_page = 3;
                                    let max_pages = parseInt(Math.ceil((feed.length) / no_of_records_per_page));
                                    if (req.query.page_no <= max_pages) {
                                        let page_no = req.query.page_no;

                                        // PAGINATION START

                                        let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
                                        let sliceData = feed.slice(offset, offset + no_of_records_per_page)
                                        var pagination = {
                                            total_rows: feed.length,
                                            total_pages: parseInt(Math.ceil((feed.length) / no_of_records_per_page)),
                                            per_page: no_of_records_per_page,
                                            offset: offset,
                                            current_page_no: page_no
                                        };
                                        // PAGINATION END

                                        return res.status(200).send({
                                            status: 200,
                                            msg: "Success",
                                            feedListCount: feed.length,
                                            feedList: sliceData,
                                            pagination: pagination
                                        });
                                    } else {
                                        return res.status(404).send({
                                            status: 404,
                                            msg: "Page no missing or Its incorrect.",
                                                                                     feedListCount: 0,
                                                feedList: [],
                                                 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                                        });
                                    }
                                }
                            });
                        });
                    }
                });
            });
        } else {
            return res.status(400).send({
                status: 400,
                msg: "fail12",
                                                                        feedListCount: 0,
                                                feedList: [],
                                                 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
            });
        }
    } else {
        return res.status(404).send({
            status: 404,
            msg: "Page no missing or Its incorrect",
                                                                    feedListCount: 0,
                                                feedList: [],
                                                 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.shared_feed_delete = async (req, res) => {
	try {
    if (req.query.feed_share_id) {
        var comment = [];
        db.query(`DELETE FROM tbl_feed_share where feed_share_id=?;`, [req.query.feed_share_id], function(error, results_comment, fields) {
            if (error) throw error;
            return res.status(200).send({
                status: 200,
                msg: "Success"
            });
        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail"
        });
    }

	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_shared_feed = async (req, res) => {
	try {
    if (req.query.page_no && req.query.feed_share_user_id) {
        var pagination = [];
        var feed = [];
        var flag = 0;
        
        if (req.query.feed_share_user_id) {
            db.query(`SELECT * From tbl_feed_share where feed_share_user_id=?`, [req.query.feed_share_user_id], function(error, results_error, fields) {
                if (error) {
                    return res.status(400).send({
                        status: 400,
                        msg: "fail"
                    });
                } else {
                    
                 if(results_error.length>0){    
                    
            
            db.query(`SELECT ts.*,tf.* From tbl_feed_share ts inner join tbl_feed tf on ts.feed_id=tf.feed_id  where ts.feed_share_user_id=?`, [req.query.feed_share_user_id], function(error, results, fields) {
                if (error) {
                    return res.status(400).send({
                        status: 400,
                        msg: "fail"
                    });
                } else {
                    if(results.length<=0){
                        results[0]={
                            feed_id:''
                        };
                    }
                    if (results.length > 0) {
                        Object.keys(results).forEach(function(key, idx, array) {
                            var result12 = results[key];
                            var element = result12.feed_id;
                            db.query(`SELECT COUNT(*) AS numrows FROM tbl_feed_comment where comment_feed_id=? and comment_operation=?;
                        SELECT * FROM tbl_like_details where like_details_feed_id=? ORDER BY created_date DESC LIMIT 2;
                        SELECT * From tbl_feed_share where feed_id=?;`, [element, '0', element, result12.feed_id], function(error, results_comment, fields) {
                                if (error) throw error;
                                var user = '';
                                var sh_user = '';
                                //     if(klo[1]=="1"){
                                // result12.is_shared = "1";
                                // }else{
                                //      result12.is_shared = "0";
                                // }
                                console.log(result12.created_date);
                               if(element!='')
                                result12.feed_duration = timeAgo(new Date(result12.created_date).toISOString());
                            
                                result12.comment_count = results_comment[0][0].numrows;
                                if (results_comment[1].length > 0) {
                                    user = results_comment[1][0].like_details_liked_user_id;
                                    result12.first_feed_fellings = results_comment[1][0].feed_fellings;
                                } else {
                                    result12.first_feed_fellings = '';
                                }
                                if (results_comment[1].length > 1) {
                                    result12.second_feed_fellings = results_comment[1][1].feed_fellings;
                                } else {
                                    result12.second_feed_fellings = '';
                                }
                                if (results_comment[2].length > 0) {
                                    sh_user = results_comment[2][0].feed_share_user_id;
                                }
                                // //////console.log(user);
                                db.query(`SELECT * FROM tbl_user_profile where user_id=?;
                                    Select count(*) as total from tbl_followers where follower_by_id=? and followered_to_id=?;
                                    Select count(*) as total from tbl_followers where followered_to_id=? and follower_status=?;
                                    Select * from tbl_like_details where  like_details_feed_id=? and like_details_liked_user_id=?;
                                    SELECT * FROM tbl_user_profile where user_id=?;
                                     SELECT * FROM tbl_events where event_id=?;
                                      Select count(*) as total from tbl_event_going where event_going_user_id=? and event_id=?;
                                      Select count(*) as total from tbl_event_intersted where event_intersted_user_id=? and event_id=?;
                                      `, [user,
                                    result12.feed_user_id, req.query.feed_share_user_id,
                                    result12.feed_user_id, 1,
                                    result12.feed_id, req.query.feed_share_user_id,
                                    sh_user,
                                    result12.event_id,
                                    req.query.feed_share_user_id, result12.event_id,
                                    req.query.feed_share_user_id, result12.event_id
                                ], function(error, results_rat, fields) {
                                    if (error) throw error;
                                    if (results_rat[0].length > 0) {
                                        result12.last_reacted_user = results_rat[0][0].user_name;
                                    } else {
                                        result12.last_reacted_user = '';
                                    }
                                    if (results_comment[2].length > 0) {
                                        if (results_rat[4].length > 0) {
                                            results_comment[2][0].user_name = results_rat[4][0].user_name;
                                            results_comment[2][0].user_profile_img = results_rat[4][0].user_profile_img;
                                        } else {
                                            results_comment[2][0].user_name = '';
                                            results_comment[2][0].user_profile_img = '';
                                        }
                                    }
                                    if (results_rat[5].length > 0) {
                                        results_rat[5][0].going = results_rat[6][0].total > 0 ? 1 : 0;
                                        results_rat[5][0].interested = results_rat[7][0].total > 0 ? 1 : 0;
                                        result12.eventList = results_rat[5][0];
                                    } else {
                                        result12.eventList = {
                                            "event_id": "",
                                            "event_user_id": "",
                                            "feed_id": "",
                                            "event_name": "",
                                            "event_contact": "",
                                            "event_address": "",
                                            "event_email": "",
                                            "event_description": "",
                                            "event_start_date": "",
                                            "event_end_date": "",
                                            "event_start_time": "",
                                            "event_end_time": "",
                                            "event_gallery": "",
                                            "event_type": "",
                                            "created_date": "",
                                            "modified_date": "",
                                            "event_business_id": "",
                                            "event_web_link": "",
                                            "event_status": "",
                                            "event_interested_count": "0",
                                            "event_going_count": "0",
                                            "going": 0,
                                            "interested": 0
                                        };
                                    }
                                    result12.follow = results_rat[1][0].total > 0 ? 'friend' : 'friend';
                                    result12.feed_fellings = results_rat[3].length > 0 ? results_rat[3][0].feed_fellings : '8';
                                    result12.follower_count = results_rat[2][0].total;
                                    // if (flag == 1 && results_comment[2].length > 0) {
                                    //     result12.shared_feed = results_comment[2][0];
                                    // } else {
                                    //     result12.shared_feed = [];
                                    // }
                                    if(result12.feed_id!='')
                                    feed.push(result12);
                                    if (idx === array.length - 1) {
                                         feed=  feed.sort((a, b) => (a.feed_id < b.feed_id) ? 1 : -1);
                                        let no_of_records_per_page = 3;
                                        let max_pages = parseInt(Math.ceil((feed.length) / no_of_records_per_page));
                                        if (req.query.page_no <= max_pages) {
                                            let page_no = req.query.page_no;

                                            // PAGINATION START

                                            let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
                                            let sliceData = feed.slice(offset, offset + no_of_records_per_page)
                                            var pagination = {
                                                total_rows: feed.length,
                                                total_pages: parseInt(Math.ceil((feed.length) / no_of_records_per_page)),
                                                per_page: no_of_records_per_page,
                                                offset: offset,
                                                current_page_no: page_no
                                            };
                                            // PAGINATION END

                                            return res.status(200).send({
                                                status: 200,
                                                msg: "Success",
                                                sharedFeedListCount: feed.length,
                                                sharedFeedList: sliceData,
                                                pagination: pagination
                                            });
                                        } else {
                                            return res.status(404).send({
                                                status: 404,
                                                msg: "Record not found.",
                                                                                                        sharedFeedListCount: 0,
                                                sharedFeedList: [],
                                                 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                                            });
                                        }
                                    }
                                });
                            });
                        });
                    } else {
                        return res.status(400).send({
                            status: 400,
                            msg: "Record not found.",
                                                                                                         sharedFeedListCount: 0,
                                                sharedFeedList: [],
                                                 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                        });
                    }
                }
            });
                    
                 }
                 
                 else {
            return res.status(400).send({
                status: 400,
                msg: "fail12",
                                                                                             sharedFeedListCount: 0,
                                                sharedFeedList: [],
                                                 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
            });
        }
                    
                }
            
            });

        } else {
            return res.status(400).send({
                status: 400,
                msg: "fail12",
                                                                                             sharedFeedListCount: 0,
                                                sharedFeedList: [],
                                                 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
            });
        }
    } else {
        return res.status(404).send({
            status: 404,
            msg: "Page no missing or Its incorrect",
                                                                                         sharedFeedListCount: 0,
                                                sharedFeedList: [],
                                                 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.video_list = async (req, res) => {
	try {
    if (req.query.page_no && req.query.user_id) {
      console.log(res.allData);
         var alldata = [];
        var flag = 0;
        var allsharedata = [];
        if (res.allData && res.allData.length > 0) {
            alldata = res.allData.filter((item, i, ar) => ar.indexOf(item) === i);
        }
        var pagination = [];
        var feed = [];
        var dmk = [];
        dmk = alldata;
            if (req.query.user_id && dmk.length > 0) {
                dmk.forEach(function(elementfeed, index) {
                    var klo = elementfeed.split("#");
                    elementfeed = klo[0];
               //     console.log(elementfeed);
                var sql = db.query(`SELECT * From tbl_feed where feed_id=? and feed_media_type=? `, [elementfeed,'video'], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: "fail"
                        });
                    } else {
                        console.log(results);
                          if(results.length<=0){
                              results[0]={
                                  feed_media:'',
                                  feed_id:''
                              }
                          }
                      //  if(results.length>0){
              //  Object.keys(results).forEach(function(key, idx, array) {
                    var result123 = results[0];
                    var string=result123.feed_media;
                            var element = result123.feed_id;
                            var d = string.split(",");
                            var flagg = 1;
                            if (d.length <= 0) {
                                flagg = 0;
                                d =[''];
                            }
                            console.log(d);
                d.forEach(function(element11, index11) {
                    result123.feed_media=element11;
                            db.query(`SELECT COUNT(*) AS numrows FROM tbl_feed_comment where comment_feed_id=? and comment_operation=?;
                        SELECT * FROM tbl_like_details where like_details_feed_id=? ORDER BY created_date DESC LIMIT 2;
                          SELECT * From tbl_feed_share where feed_id=?;SELECT * From tbl_feed where feed_id=?;`, [elementfeed, '0', elementfeed, result123.feed_id, result123.shared_feed_id], function(error, results_comment, fields) {
                                if (error) throw error;
                                var user = '';
                                var sh_user = '';
                                if (flagg == 1) {
                                
                                    if (results_comment[3].length > 0) {
                                        results_comment[3][0].comment_count = 0;
                                        results_comment[3][0].feed_fellings = "8";
                                        results_comment[3][0].first_feed_fellings = "0";
                                        results_comment[3][0].last_reacted_user = "";
                                        results_comment[3][0].second_feed_fellings = "";
                                        results_comment[3][0].follow = "friend";
                                        results_comment[3][0].follower_count = 0;
                                        results_comment[3][0].shared_feed = [];
                                 
                                        results_comment[3][0].feed_duration = timeAgo(new Date(results_comment[3][0].created_date).toISOString());
                                        //result123.shared_feed_data = results_comment[3][0];
                                    }
                                      if(result123.feed_id!=''){
                                    result123.feed_duration = timeAgo(new Date(result123.created_date).toISOString());
                                    result123.comment_count = results_comment[0][0].numrows;
                                      }
                                    if (results_comment[1].length > 0) {
                                        user = results_comment[1][0].like_details_liked_user_id;
                                        result123.first_feed_fellings = results_comment[1][0].feed_fellings;
                                    } else {
                                        result123.first_feed_fellings = '';
                                    }
                                    if (results_comment[1].length > 1) {
                                        result123.second_feed_fellings = results_comment[1][1].feed_fellings;
                                    } else {
                                        result123.second_feed_fellings = '';
                                    }
                                    if (results_comment[2].length > 0) {
                                        sh_user = results_comment[2][0].feed_share_user_id;
                                    }
                                }
                                //////console.log(user);
                                db.query(`SELECT * FROM tbl_user_profile where user_id=?;
                                    Select count(*) as total from tbl_followers where follower_by_id=? and followered_to_id=?;
                                    Select count(*) as total from tbl_followers where followered_to_id=? and follower_status=?;
                                    Select * from tbl_like_details where  like_details_feed_id=? and like_details_liked_user_id=?;
                                    SELECT * FROM tbl_user_profile where user_id=?;
                                     SELECT * FROM tbl_events where event_id=?;
                                      Select count(*) as total from tbl_event_going where event_going_user_id=? and event_id=?;
                                      Select count(*) as total from tbl_event_intersted where event_intersted_user_id=? and event_id=?;`, [user,
                                    result123.feed_user_id, req.query.user_id,
                                    result123.feed_user_id, 1,
                                    result123.feed_id, req.query.user_id,
                                    sh_user,
                                    result123.event_id,
                                    req.query.user_id, result123.event_id,
                                    req.query.user_id, result123.event_id
                                ], function(error, results_rat, fields) {
                                    if (error) throw error;
                                    if (flagg == 1) {
                                        if (results_rat[0].length > 0) {
                                            result123.last_reacted_user = results_rat[0][0].user_name;
                                        } else {
                                            result123.last_reacted_user = '';
                                        }
                                        if (results_comment[2].length > 0) {
                                            if (results_rat[4].length > 0) {
                                                results_comment[2][0].user_name = results_rat[4][0].user_name;
                                                results_comment[2][0].user_profile_img = results_rat[4][0].user_profile_img;
                                            } else {
                                                results_comment[2][0].user_name = '';
                                                results_comment[2][0].user_profile_img = '';
                                            }
                                        }
                                     result123.user_reaction='';
                                        result123.follow = results_rat[1][0].total > 0 ? 'friend' : 'friend';
                                        result123.feed_fellings = results_rat[3].length > 0 ? results_rat[3][0].feed_fellings : '8';
                                        result123.follower_count = results_rat[2][0].total;
                                      
                                        if(result123.feed_id!='')
                                        feed.push(result123);
                                      // console.log(result123);
                                    }
                                    if ( index11==d.length-1  && index==dmk.length-1) {
                                        feed = feed.sort((a, b) => (a.feed_id < b.feed_id) ? 1 : -1);
                                       /// let no_of_records_per_page = 3;
                                        let no_of_records_per_page = 5;
                                        let max_pages = parseInt(Math.ceil((feed.length) / no_of_records_per_page));
                                        if (req.query.page_no <= max_pages) {
                                            let page_no = req.query.page_no;
                                            let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
                                            let sliceData = feed.slice(offset, offset + no_of_records_per_page)
                                            var pagination = {
                                                total_rows: feed.length,
                                                total_pages: parseInt(Math.ceil((feed.length) / no_of_records_per_page)),
                                                per_page: no_of_records_per_page,
                                                offset: offset,
                                                current_page_no: page_no
                                            };
                                            // PAGINATION END

                                            return res.status(200).send({
                                                status: 200,
                                                msg: "Success",
                                                videoListCount: feed.length,
                                                videoList: sliceData,
                                                pagination: pagination
                                            });
                                        } else {
                                            return res.status(404).send({
                                                status: 404,
                                                msg: "Page no missing or Its incorrect.",
                                                videoListCount: 0,
                                                videoList: [],
                                                pagination: {
                                                    total_rows: 0,
                                                    total_pages: 0,
                                                    per_page: 0,
                                                    offset: 0,
                                                    current_page_no: '0'
                                                }

                                            });
                                        }
                                    }
                                });
                            });
                });//
            // });
            //         }else{
            //               return res.status(400).send({
            //         status: 400,
            //         msg: "fail",
            //         videoListCount: 0,
            //         videoList: [],
            //         pagination: {
            //             total_rows: 0,
            //             total_pages: 0,
            //             per_page: 0,
            //             offset: 0,
            //             current_page_no: '0'
            //         }
            //     });
            //         }
                 }///
                });
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail12",
                    videoListCount: 0,
                    videoList: [],
                    pagination: {
                        total_rows: 0,
                        total_pages: 0,
                        per_page: 0,
                        offset: 0,
                        current_page_no: '0'
                    }
                });
            }
    } else {
        return res.status(404).send({
            status: 404,
            msg: "Page no missing or Its incorrect",
            videoListCount: 0,
            videoList: [],
            pagination: {
                total_rows: 0,
                total_pages: 0,
                per_page: 0,
                offset: 0,
                current_page_no: '0'
            }
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_personal_feeds = async (req, res) => {
	try {
    if (req.query.page_no) {
        var pagination = [];
        var feed = [];
        var flag = 0;
        if (req.query.user_id) {
            db.query(`SELECT * From tbl_feed where feed_user_id=? and feed_is_deleted=? and feed_type_number=? order by feed_id desc`, [req.query.user_id, '0', '0'], function(error, results, fields) {
                if (error) {
                    return res.status(400).send({
                        status: 400,
                        msg: "fail"
                    });
                } else {
                    if (results.length > 0) {
                        Object.keys(results).forEach(function(key, idx, array) {
                            var result12 = results[key];
                            var element = result12.feed_id;
                            db.query(`SELECT COUNT(*) AS numrows FROM tbl_feed_comment where comment_feed_id=? and comment_operation=?;
                        SELECT * FROM tbl_like_details where like_details_feed_id=? ORDER BY created_date DESC LIMIT 2;
                        SELECT * From tbl_feed_share where feed_id=?;`, [element, '0', element, result12.feed_id], function(error, results_comment, fields) {
                                if (error) throw error;
                                var user = '';
                                var sh_user = '';
                                //     if(klo[1]=="1"){
                                // result12.is_shared = "1";
                                // }else{
                                //      result12.is_shared = "0";
                                // }

                                result12.feed_duration = timeAgo(new Date(result12.created_date).toISOString());
                                result12.comment_count = results_comment[0][0].numrows;
                                if (results_comment[1].length > 0) {
                                    user = results_comment[1][0].like_details_liked_user_id;
                                    result12.first_feed_fellings = results_comment[1][0].feed_fellings;
                                } else {
                                    result12.first_feed_fellings = '';
                                }
                                if (results_comment[1].length > 1) {
                                    result12.second_feed_fellings = results_comment[1][1].feed_fellings;
                                } else {
                                    result12.second_feed_fellings = '';
                                }
                                if (results_comment[2].length > 0) {
                                    sh_user = results_comment[2][0].feed_share_user_id;
                                }
                                // //////console.log(user);
                                db.query(`SELECT * FROM tbl_user_profile where user_id=?;
                                    Select count(*) as total from tbl_followers where follower_by_id=? and followered_to_id=?;
                                    Select count(*) as total from tbl_followers where followered_to_id=? and follower_status=?;
                                    Select * from tbl_like_details where  like_details_feed_id=? and like_details_liked_user_id=?;
                                    SELECT * FROM tbl_user_profile where user_id=?;
                                     SELECT * FROM tbl_events where event_id=?;
                                      Select count(*) as total from tbl_event_going where event_going_user_id=? and event_id=?;
                                      Select count(*) as total from tbl_event_intersted where event_intersted_user_id=? and event_id=?;
                                      `, [user,
                                    result12.feed_user_id, req.query.user_id,
                                    result12.feed_user_id, 1,
                                    result12.feed_id, req.query.user_id,
                                    sh_user,
                                    result12.event_id,
                                    req.query.user_id, result12.event_id,
                                    req.query.user_id, result12.event_id
                                ], function(error, results_rat, fields) {
                                    if (error) throw error;
                                    if (results_rat[0].length > 0) {
                                        result12.last_reacted_user = results_rat[0][0].user_name;
                                    } else {
                                        result12.last_reacted_user = '';
                                    }
                                    if (results_comment[2].length > 0) {
                                        if (results_rat[4].length > 0) {
                                            results_comment[2][0].user_name = results_rat[4][0].user_name;
                                            results_comment[2][0].user_profile_img = results_rat[4][0].user_profile_img;
                                        } else {
                                            results_comment[2][0].user_name = '';
                                            results_comment[2][0].user_profile_img = '';
                                        }
                                    }
                                    if (results_rat[5].length > 0) {
                                        results_rat[5][0].going = results_rat[6][0].total > 0 ? 1 : 0;
                                        results_rat[5][0].interested = results_rat[7][0].total > 0 ? 1 : 0;
                                        result12.eventList = results_rat[5][0];
                                    } else {
                                        result12.eventList = {
                                            "event_id": "",
                                            "event_user_id": "",
                                            "feed_id": "",
                                            "event_name": "",
                                            "event_contact": "",
                                            "event_address": "",
                                            "event_email": "",
                                            "event_description": "",
                                            "event_start_date": "",
                                            "event_end_date": "",
                                            "event_start_time": "",
                                            "event_end_time": "",
                                            "event_gallery": "",
                                            "event_type": "",
                                            "created_date": "",
                                            "modified_date": "",
                                            "event_business_id": "",
                                            "event_web_link": "",
                                            "event_status": "",
                                            "event_interested_count": "0",
                                            "event_going_count": "0",
                                            "going": 0,
                                            "interested": 0
                                        };
                                    }
                                    result12.follow = results_rat[1][0].total > 0 ? 'friend' : 'friend';
                                    result12.feed_fellings = results_rat[3].length > 0 ? results_rat[3][0].feed_fellings : '8';
                                    result12.follower_count = results_rat[2][0].total;
                                    if (flag == 1 && results_comment[2].length > 0) {
                                        result12.shared_feed = results_comment[2][0];
                                    } else {
                                        result12.shared_feed = [];
                                    }
                                    feed.push(result12);
                                    if (idx === array.length - 1) {
                                         feed=  feed.sort((a, b) => (a.feed_id < b.feed_id) ? 1 : -1);
                                        let no_of_records_per_page = 3;
                                        let max_pages = parseInt(Math.ceil((feed.length) / no_of_records_per_page));
                                        if (req.query.page_no <= max_pages) {
                                            let page_no = req.query.page_no;

                                            // PAGINATION START

                                            let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
                                            let sliceData = feed.slice(offset, offset + no_of_records_per_page)
                                            var pagination = {
                                                total_rows: feed.length,
                                                total_pages: parseInt(Math.ceil((feed.length) / no_of_records_per_page)),
                                                per_page: no_of_records_per_page,
                                                offset: offset,
                                                current_page_no: page_no
                                            };
                                            // PAGINATION END

                                            return res.status(200).send({
                                                status: 200,
                                                msg: "Success",
                                                personalFeedListCount: feed.length,
                                                personalFeedList: sliceData,
                                                pagination: pagination
                                            });
                                        } else {
                                            return res.status(404).send({
                                                status: 404,
                                                msg: "Page no missing or Its incorrect.",
                                                                                                                             personalFeedListCount: 0,
                                                personalFeedList: [],
                                                 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                                            });
                                        }
                                    }
                                });
                            });
                        });
                    } else {
                        return res.status(400).send({
                            status: 400,
                            msg: "Record not found.",
                                                                                                                                personalFeedListCount: 0,
                                                personalFeedList: [],
                                                 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                        });
                    }
                }
            });

        } else {
            return res.status(400).send({
                status: 400,
                msg: "fail12",
                                                                                                                    personalFeedListCount: 0,
                                                personalFeedList: [],
                                                 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
            });
        }
    } else {
        return res.status(404).send({
            status: 404,
            msg: "Page no missing or Its incorrect",
                                                                                                                personalFeedListCount: 0,
                                                personalFeedList: [],
                                                 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.feed_comment_insert = async (req, res) => {
	try {
    let upload = multer({
        storage: comment,
    }).fields([{
        name: 'comment_media',
        maxCount: 10
    }]);
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        } else {

            if (req.body.comment_user_id && req.body.comment_feed_id) {
                var pt = define.BASE_URL+"comment_media/";
                if (typeof req.files.comment_media !== 'undefined') {
                    req.body.comment_media = pt + req.files.comment_media[0].filename;
                }
                if(req.body.gif_url){
                  req.body.comment_media  =req.body.gif_url;
                }
                delete(req.body.gif_url);
                db.query(`INSERT INTO tbl_feed_comment SET ?`, [req.body], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: "fail"
                        });
                    } else {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success",
                            comment_media: (req.body.comment_media) ? req.body.comment_media : '',
                            comment_id: results.insertId
                        });
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                    comment_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.feed_comment_update = async (req, res) => {
	try {
    let upload = multer({
        storage: comment,
    }).fields([{
        name: 'comment_media',
        maxCount: 10
    }]);
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        } else {
            if (req.body.comment_id) {
                var comment_id = req.body.comment_id;
                delete(req.body.comment_id);
                var pt =define.BASE_URL+"comment_media/";
                if (typeof req.files.comment_media !== 'undefined') {
                    req.body.comment_media = pt + req.files.comment_media[0].filename;
                }
                db.query(`UPDATE tbl_feed_comment SET ? where comment_id=?`, [req.body, comment_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: "fail"
                        });
                    } else {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success",
                            comment_media: (req.body.comment_media) ? req.body.comment_media : '',
                        });
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                    comment_media:''
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.feed_comment_delete = async (req, res) => {
	try {
    if (req.query.comment_id) {
        var comment = [];
        db.query(`DELETE FROM tbl_feed_comment where comment_id=?;`, [req.query.comment_id], function(error, results_comment, fields) {
            if (error) throw error;
            return res.status(200).send({
                status: 200,
                msg: "Success"
            });
        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail"
        });
    }

	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_feed_comment_reply_report = async (req, res) => {
	try {
    let upload = multer({
        storage: comment,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        } else {
            if (req.body.comment_user_id) {
                db.query(`INSERT INTO tbl_feed_comment_reply_report SET ?`, [req.body], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: "fail"
                        });
                    } else {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success",
                            comment_reply_report_id: results.insertId
                        });
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                    comment_reply_report_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.feed_comment_reply_update = async (req, res) => {
	try {
            let upload = multer({
                storage: comment,
            }).fields([{
                name: 'reply_comment_media',
                maxCount: 10
            }]);
            upload(req, res, function(err) {
                if (err) {
                    return res.status(400).send({
                        status: 400,
                        msg: "fail"
                    });
                } else {

                    if (req.body.comment_reply_id) {
                        db.query(`select * from  tbl_feed_comment_reply where comment_reply_id=?`, [req.body.comment_reply_id], function(error, results1, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: "fail"
                                    });
                                } else {
                                    if (results1.length > 0) {
                                        var pt = define.BASE_URL+"comment_media/";
                                        if (typeof req.files.reply_comment_media !== 'undefined') {
                                            req.body.reply_comment_media = pt + req.files.reply_comment_media[0].filename;
                                        }
                                        var comment_reply_id = req.body.comment_reply_id;
                                        delete(req.body.comment_reply_id);
                                        db.query(`UPDATE tbl_feed_comment_reply SET ? where comment_reply_id=?`, [req.body, comment_reply_id], function(error, results, fields) {
                                            if (error) {
                                                return res.status(400).send({
                                                    status: 400,
                                                    msg: "fail"
                                                });
                                            } else {
                                                return res.status(200).send({
                                                    status: 200,
                                                    msg: "Success",
                                                    reply_comment_media: (req.body.reply_comment_media) ? req.body.reply_comment_media : '',
                                                });
                                            }
                                        });
                                    } else {
                                        return res.status(400).send({
                                            status: 400,
                                            msg: "Record not found.",
                                            reply_comment_media:''
                                        });
                                    }
                                }

                            });
                        }else{
                            return res.status(400).send({
                                status: 400,
                                msg: "Record not found.",
                                reply_comment_media:''
                            });
                        }
                    }
        });
} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_feed_comment_reply_reply_report = async (req, res) => {
	try {
                let upload = multer({
                    storage: comment,
                }).single('');
                upload(req, res, function(err) {
                    if (err) {
                        return res.status(400).send({
                            status: 400,
                            msg: "fail"
                        });
                    } else {
                        if (req.body.comment_reply_user_id) {
                            db.query(`INSERT INTO tbl_feed_comment_reply_reply_report SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: "fail"
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        comment_reply_reply_report_id: results.insertId
                                    });
                                }
                            });

                        } else {
                            return res.status(400).send({
                                status: 400,
                                msg: "fail",
                                comment_reply_reply_report_id:0
                            });
                        }
                    }
                });
            } catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.feed_comment_reply_reply_update = async (req, res) => {
	try {
                let upload = multer({
                    storage: comment,
                }).fields([{
                    name: 'reply_reply_comment_media',
                    maxCount: 10
                }]);
                upload(req, res, function(err) {
                    if (err) {
                        return res.status(400).send({
                            status: 400,
                            msg: "fail"
                        });
                    } else {

                        if (req.body.comment_reply_reply_id) {
                            db.query(`select * from  tbl_feed_comment_reply_reply where comment_reply_reply_id=?`, [req.body.comment_reply_reply_id], function(error, results1, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: "fail"
                                    });
                                } else {
                                    if (results1.length > 0) {
                                        var pt = define.BASE_URL+"comment_media/";
                                        if (typeof req.files.reply_reply_comment_media !== 'undefined') {
                                            req.body.reply_reply_comment_media = pt + req.files.reply_reply_comment_media[0].filename;
                                        }
                                        var comment_reply_reply_id = req.body.comment_reply_reply_id;
                                        delete(req.body.comment_reply_reply_id);
                                        db.query(`UPDATE tbl_feed_comment_reply_reply SET ? where comment_reply_reply_id=?`, [req.body, comment_reply_reply_id], function(error, results, fields) {
                                            if (error) {
                                                return res.status(400).send({
                                                    status: 400,
                                                    msg: "fail"
                                                });
                                            } else {
                                                return res.status(200).send({
                                                    status: 200,
                                                    msg: "Success",
                                                    reply_reply_comment_media: (req.body.reply_reply_comment_media) ? req.body.reply_reply_comment_media : '',
                                                });
                                            }
                                        });
                                    } else {
                                        return res.status(400).send({
                                            status: 400,
                                            msg: "Record not found.",
                                            reply_reply_comment_media:''
                                        });
                                    }
                                }

                            });
                        } else {
                            return res.status(400).send({
                                status: 400,
                                msg: "fail1",
                                   reply_reply_comment_media:''
                            });
                        }
                    }
                });
            } catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_feed_comment_report = async (req, res) => {
	try {
    let upload = multer({
        storage: comment,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        } else {
            if (req.body.feed_user_id) {
                db.query(`INSERT INTO tbl_feed_comment_report SET ?`, [req.body], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: "fail"
                        });
                    } else {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success",
                            feed_comment_report_id: results.insertId
                        });
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                    feed_comment_report_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.feed_comment_reply_insert = async (req, res) => {
	try {
    let upload = multer({
        storage: comment,
    }).fields([{
        name: 'reply_comment_media',
        maxCount: 10
    }]);
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        } else {

            if (req.body.comment_reply_user_id && req.body.comment_id) {
                var pt = define.BASE_URL+"comment_media/";
                if (typeof req.files.reply_comment_media !== 'undefined') {
                    req.body.reply_comment_media = pt + req.files.reply_comment_media[0].filename;
                }
                  if(req.body.gif_url){
                  req.body.reply_comment_media  =req.body.gif_url;
                }
                delete(req.body.gif_url);
                db.query(`INSERT INTO tbl_feed_comment_reply SET ?`, [req.body], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: "fail"
                        });
                    } else {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success",
                            reply_comment_media: (req.body.reply_comment_media) ? req.body.reply_comment_media : '',
                            comment_reply_id: results.insertId
                            
                        });
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    comment_reply_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.feed_comment_reply_reply_insert = async (req, res) => {
	try {
    let upload = multer({
        storage: comment,
    }).fields([{
        name: 'reply_reply_comment_media',
        maxCount: 10
    }]);
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        } else {

            if (req.body.comment_reply_reply_user_id && req.body.comment_reply_id) {
                var pt = define.BASE_URL+"comment_media/";
                if (typeof req.files.reply_reply_comment_media !== 'undefined') {
                    req.body.reply_reply_comment_media = pt + req.files.reply_reply_comment_media[0].filename;
                }
                   if(req.body.gif_url){
                  req.body.reply_reply_comment_media  =req.body.gif_url;
                }
                delete(req.body.gif_url);
                db.query(`INSERT INTO tbl_feed_comment_reply_reply SET ?`, [req.body], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: "fail"
                        });
                    } else {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success",
                            reply_reply_comment_media: (req.body.reply_reply_comment_media) ? req.body.reply_reply_comment_media : '',
                            comment_reply_reply_id: results.insertId
                        });
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    comment_reply_reply_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.feed_comments = async (req, res) => {
	try {
    if (req.query.comment_feed_id && req.query.page_no) {
        var no_of_records_per_page = 10;
        var rowno = req.query.page_no;
        if (rowno != 0) {
            rowno = (rowno - 1) * no_of_records_per_page;
        }
        var comment = [];
        db.query(`SELECT * FROM tbl_feed_comment where comment_feed_id=? and comment_operation=? LIMIT ? OFFSET ?;SELECT COUNT(*) AS numrows FROM tbl_feed_comment where comment_feed_id=? and comment_operation=?`, [req.query.comment_feed_id, '0', no_of_records_per_page, rowno, req.query.comment_feed_id, '0'], function(error, results_comment, fields) {
            if (error) throw error;
            if (results_comment[0].length > 0) {
                //// //////console.log(timeAgo(new Date('2022-02-22 07:12:49').toISOString()));
                Object.keys(results_comment[0]).forEach(function(key12, idx12, array12) {
                    var results_comment_data = results_comment[0][key12];
                    db.query(`SELECT * FROM tbl_user_profile where user_id=?;SELECT reaction_comment_id, COUNT(*) as total FROM tbl_comment_reaction WHERE reaction_comment_id = ? GROUP BY reaction_comment_id;SELECT * FROM tbl_comment_reaction WHERE reaction_comment_id = ? and reaction_user_id=?`, [results_comment_data.comment_user_id, results_comment_data.comment_id, results_comment_data.comment_id, req.query.user_id], function(error, results_comment1, fields) {
                        if (error) throw error;
                        if (results_comment1[0].length > 0) {
                            results_comment_data.user_name = results_comment1[0][0].user_name;
                            results_comment_data.user_profile_img = results_comment1[0][0].user_profile_img;
                        } else {
                            results_comment_data.user_name = '';
                            results_comment_data.user_profile_img = '';
                        }
                        if (results_comment1[1].length > 0)
                            results_comment_data.reaction_count = results_comment1[1][0].total;
                        else
                            results_comment_data.reaction_count = 0;

                        if (results_comment1[2].length > 0)
                            results_comment_data.user_reaction_string = results_comment1[2][0].comment_feeling_string;
                        else
                            results_comment_data.user_reaction_string = '';
                        results_comment_data.is_friend = (res.totalfriendsList.includes(results_comment_data.comment_user_id)) ? "1" : "0";
                        if (results_comment_data.created_date != '0000-00-00 00:00:00')
                            results_comment_data.comment_ago = timeAgo(new Date(results_comment_data.created_date).toISOString());
                        else
                            results_comment_data.comment_ago = 'just now';


                        var comment_re = [];
                        db.query(`SELECT * FROM tbl_feed_comment_reply where comment_id=? and comment_reply_operation=?`, [results_comment_data.comment_id, '0'], function(error, results_comment_re, fields) {
                            if (error) throw error;
                            if (results_comment_re.length > 0) {
                                Object.keys(results_comment_re).forEach(function(key_re, idx_re, array_re) {
                                    var results_comment_reply_data = results_comment_re[key_re];
                                    db.query(`SELECT * FROM tbl_user_profile where user_id=?;SELECT reaction_comment_reply_id, COUNT(*) as total FROM tbl_comment_reply_reaction WHERE reaction_comment_reply_id = ? GROUP BY reaction_comment_reply_id;SELECT * FROM tbl_comment_reply_reaction WHERE reaction_comment_reply_id = ? and reaction_user_id=?`, [results_comment_reply_data.comment_reply_user_id, results_comment_reply_data.comment_reply_id, results_comment_reply_data.comment_reply_id, req.query.user_id], function(error, results_comment_reply, fields) {
                                        if (error) throw error;
                                        if (results_comment_reply[0].length > 0) {
                                            results_comment_reply_data.user_name = results_comment_reply[0][0].user_name;
                                            results_comment_reply_data.user_profile_img = results_comment_reply[0][0].user_profile_img;
                                        } else {
                                            results_comment_reply_data.user_name = '';
                                            results_comment_reply_data.user_profile_img = '';
                                        }
                                        if (results_comment_reply[1].length > 0)
                                            results_comment_reply_data.reaction_count = results_comment_reply[1][0].total;
                                        else
                                            results_comment_reply_data.reaction_count = 0;

                                        if (results_comment_reply[2].length > 0)
                                            results_comment_reply_data.user_reaction_string = results_comment_reply[2][0].comment_reply_feeling_string;
                                        else
                                            results_comment_reply_data.user_reaction_string = '';
                                        results_comment_reply_data.is_friend = (res.totalfriendsList.includes(results_comment_reply_data.comment_reply_user_id)) ? "1" : "0";
                                        if (results_comment_reply_data.created_date != '0000-00-00 00:00:00')
                                            results_comment_reply_data.comment_reply_ago = timeAgo(new Date(results_comment_reply_data.created_date).toISOString());
                                        else
                                            results_comment_reply_data.comment_reply_ago = 'just now';
                                        comment_re.push(results_comment_reply_data);
                                        if (idx_re === array_re.length - 1) {
                                            results_comment_data.comment_replies = comment_re;
                                            comment.push(results_comment_data);

                                            if (idx12 === array12.length - 1) {
                                                let max_pages = parseInt(Math.ceil((results_comment[1][0].numrows) / no_of_records_per_page));
                                                if (req.query.page_no && req.query.page_no <= max_pages) {
                                                    let page_no = req.query.page_no;
                                                    // PAGINATION START
                                                    let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
                                                    //  let sliceData = final_array.slice(offset, offset + no_of_records_per_page)
                                                    var pagination = {
                                                        total_rows: results_comment[1][0].numrows,
                                                        total_pages: parseInt(Math.ceil((results_comment[1][0].numrows) / no_of_records_per_page)),
                                                        per_page: no_of_records_per_page,
                                                        offset: offset,
                                                        current_page_no: page_no
                                                    };
                                                    return res.status(200).send({
                                                        status: 200,
                                                        msg: "Success",
                                                        commentListCount: results_comment[1][0].numrows,
                                                        commentList: comment,
                                                        pagination: pagination
                                                    });
                                                } else {
                                                    return res.status(404).send({
                                                        status: 404,
                                                        msg: "Page no missing or Its incorrect.",
                                                            commentListCount: 0,
                                                        commentList: [],
                                                         pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }

                                                    });
                                                }
                                            }
                                        }

                                    });
                                });
                            } else {
                                results_comment_data.comment_replies = [];
                                comment.push(results_comment_data);
                                if (idx12 === array12.length - 1) {
                                    let max_pages = parseInt(Math.ceil((results_comment[1][0].numrows) / no_of_records_per_page));
                                    if (req.query.page_no && req.query.page_no <= max_pages) {
                                        let page_no = req.query.page_no;
                                        // PAGINATION START
                                        let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
                                        //  let sliceData = final_array.slice(offset, offset + no_of_records_per_page)
                                        var pagination = {
                                            total_rows: results_comment[1][0].numrows,
                                            total_pages: parseInt(Math.ceil((results_comment[1][0].numrows) / no_of_records_per_page)),
                                            per_page: no_of_records_per_page,
                                            offset: offset,
                                            current_page_no: page_no
                                        };
                                        return res.status(200).send({
                                            status: 200,
                                            msg: "Success",
                                            commentListCount: results_comment[1][0].numrows,
                                            commentList: comment,
                                            pagination: pagination
                                        });
                                    } else {
                                        return res.status(404).send({
                                            status: 404,
                                            msg: "Page no missing or Its incorrect.",
                                                                          commentListCount: 0,
                                                        commentList: [],
                                                         pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                                        });
                                    }
                                }
                            }

                        });
                    });
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail12",
                                                  commentListCount: 0,
                                                        commentList: [],
                                                         pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                });
            }
        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
                                          commentListCount: 0,
                                                        commentList: [],
                                                         pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.feed_comments_reply = async (req, res) => {
	try {
    if (req.query.comment_id) {
        var comment_re = [];
        db.query(`SELECT * FROM tbl_feed_comment_reply where comment_id=? and comment_reply_operation=?`, [req.query.comment_id, '0'], function(error, results_comment_re, fields) {
            if (error) throw error;
            if (results_comment_re.length > 0) {
                Object.keys(results_comment_re).forEach(function(key_re, idx_re, array_re) {
                    var results_comment_reply_data = results_comment_re[key_re];
                    db.query(`SELECT * FROM tbl_user_profile where user_id=?;SELECT reaction_comment_reply_id, COUNT(*) as total FROM tbl_comment_reply_reaction WHERE reaction_comment_reply_id = ? GROUP BY reaction_comment_reply_id;SELECT * FROM tbl_comment_reply_reaction WHERE reaction_comment_reply_id = ? and reaction_user_id=?`, [results_comment_reply_data.comment_reply_user_id, results_comment_reply_data.comment_reply_id, results_comment_reply_data.comment_reply_id, req.query.user_id], function(error, results_comment_reply, fields) {
                        if (error) throw error;
                        if (results_comment_reply[0].length > 0) {
                            results_comment_reply_data.user_name = results_comment_reply[0][0].user_name;
                            results_comment_reply_data.user_profile_img = results_comment_reply[0][0].user_profile_img;
                        } else {
                            results_comment_reply_data.user_name = '';
                            results_comment_reply_data.user_profile_img = '';
                        }
                        if (results_comment_reply[1].length > 0)
                            results_comment_reply_data.reaction_count = results_comment_reply[1][0].total;
                        else
                            results_comment_reply_data.reaction_count = 0;

                        if (results_comment_reply[2].length > 0)
                            results_comment_reply_data.user_reaction_string = results_comment_reply[2][0].comment_reply_feeling_string;
                        else
                            results_comment_reply_data.user_reaction_string = '';
                        results_comment_reply_data.is_friend = (res.totalfriendsList.includes(results_comment_reply_data.comment_reply_user_id)) ? "1" : "0";
                        if (results_comment_reply_data.created_date != '0000-00-00 00:00:00')
                            results_comment_reply_data.comment_reply_ago = timeAgo(new Date(results_comment_reply_data.created_date).toISOString());
                        else
                            results_comment_reply_data.comment_reply_ago = 'just now';
                        comment_re.push(results_comment_reply_data);
                        if (idx_re === array_re.length - 1) {
                            return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                commentReplyListCount: comment_re.length,
                                commentReplyList: comment_re
                            });
                        }

                    });
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                     commentReplyListCount: 0,
                                commentReplyList: []
                });
            }
        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
             commentReplyListCount: 0,
                                commentReplyList: []
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.feed_comments_reply_reply = async (req, res) => {
	try {
    if (req.query.comment_reply_id) {
        var comment_re = [];
        db.query(`SELECT * FROM tbl_feed_comment_reply_reply where comment_reply_id=? and comment_reply_reply_operation=?`, [req.query.comment_reply_id, '0'], function(error, results_comment_re, fields) {
            if (error) throw error;
            if (results_comment_re.length > 0) {
                Object.keys(results_comment_re).forEach(function(key_re, idx_re, array_re) {
                    var results_comment_reply_reply_data = results_comment_re[key_re];
                    db.query(`SELECT * FROM tbl_user_profile where user_id=?;SELECT reaction_comment_reply_reply_id, COUNT(*) as total FROM tbl_comment_reply_reply_reaction WHERE reaction_comment_reply_reply_id = ? GROUP BY reaction_comment_reply_reply_id;SELECT * FROM tbl_comment_reply_reply_reaction WHERE reaction_comment_reply_reply_id = ? and reaction_user_id=?`, [results_comment_reply_reply_data.comment_reply_reply_user_id, results_comment_reply_reply_data.comment_reply_reply_id, results_comment_reply_reply_data.comment_reply_reply_id, req.query.user_id], function(error, results_comment_reply_reply, fields) {
                        if (error) throw error;
                        if (results_comment_reply_reply[0].length > 0) {
                            results_comment_reply_reply_data.user_name = results_comment_reply_reply[0][0].user_name;
                            results_comment_reply_reply_data.user_profile_img = results_comment_reply_reply[0][0].user_profile_img;
                        } else {
                            results_comment_reply_reply_data.user_name = '';
                            results_comment_reply_reply_data.user_profile_img = '';
                        }
                        if (results_comment_reply_reply[1].length > 0)
                            results_comment_reply_reply_data.reaction_count = results_comment_reply_reply[1][0].total;
                        else
                            results_comment_reply_reply_data.reaction_count = 0;

                        if (results_comment_reply_reply[2].length > 0)
                            results_comment_reply_reply_data.user_reaction_string = results_comment_reply_reply[2][0].comment_reply_reply_feeling_string;
                        else
                            results_comment_reply_reply_data.user_reaction_string = '';
                        results_comment_reply_reply_data.is_friend = (res.totalfriendsList.includes(results_comment_reply_reply_data.comment_reply_reply_user_id)) ? "1" : "0";
                        if (results_comment_reply_reply_data.created_date != '0000-00-00 00:00:00')
                            results_comment_reply_reply_data.comment_reply_reply_ago = timeAgo(new Date(results_comment_reply_reply_data.created_date).toISOString());
                        else
                            results_comment_reply_reply_data.comment_reply_reply_ago = 'just now';
                        comment_re.push(results_comment_reply_reply_data);
                        if (idx_re === array_re.length - 1) {
                            return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                commentReplyReplyListCount: comment_re.length,
                                commentReplyReplyList: comment_re
                            });
                        }

                    });
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                     commentReplyReplyListCount: 0,
                                commentReplyReplyList: []
                });
            }
        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
                 commentReplyReplyListCount: 0,
                                commentReplyReplyList: []
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.comment_reply_count = async (req, res) => {
	try {
    if (req.query.comment_reply_id) {
        var comment_re = [];
        db.query(`SELECT comment_reply_feeling_string, COUNT(*) as count FROM tbl_comment_reply_reaction WHERE reaction_comment_reply_id = ? GROUP BY comment_reply_feeling_string`, [req.query.comment_reply_id], function(error, results_comment_re, fields) {
            if (error) throw error;
            if (results_comment_re.length > 0) {
                var c = 0;
                //// //////console.log(results_comment_re);
                Object.keys(results_comment_re).forEach(function(key_re, idx_re, array_re) {
                    var results_comment_reply_data = results_comment_re[key_re];
                    var comment_re1 = [];
                    c = c + results_comment_reply_data.count;
                    db.query(`SELECT * FROM tbl_comment_reply_reaction WHERE reaction_comment_reply_id = ? and comment_reply_feeling_string=?`, [req.query.comment_reply_id, results_comment_reply_data.comment_reply_feeling_string], function(error, results_comment_reply, fields) {
                        if (error) {} else {
                            if (results_comment_reply.length > 0) {
                                //// //////console.log(results_comment_reply);
                                Object.keys(results_comment_reply).forEach(function(key_re12, idx_re12, array_re12) {
                                    var results_comment_reply_data1 = results_comment_reply[key_re12];
                                    db.query(`SELECT * FROM tbl_user_profile WHERE user_id = ?;SELECT * FROM tbl_friend_request WHERE (receiver_user_id = ? or sender_user_id = ?) AND request_status = ?`, [results_comment_reply_data1.reaction_user_id, results_comment_reply_data1.reaction_user_id, results_comment_reply_data1.reaction_user_id, '1'], function(error, results_comment_reply12, fields) {
                                        if (error) {} else {
                                            if (results_comment_reply12[0].length > 0)
                                                comment_re1.push({
                                                    user_id: results_comment_reply12[0][0].user_id,
                                                    user_name: results_comment_reply12[0][0].user_name,
                                                    user_profile_img: results_comment_reply12[0][0].user_profile_img,
                                                    user_phone: results_comment_reply12[0][0].user_phone,
                                                    friendCount: results_comment_reply12[1].length
                                                });
                                            if (idx_re12 === array_re12.length - 1) {
                                                results_comment_reply_data.user = comment_re1;
                                                comment_re.push(results_comment_reply_data);
                                                if (idx_re === array_re.length - 1) {
                                                    return res.status(200).send({
                                                        status: 200,
                                                        msg: "Success",
                                                        commentReplyCountListCount: c,
                                                        commentReplyCountList: comment_re
                                                    });
                                                }
                                            }
                                        }
                                    });
                                });
                            } else {
                                results_comment_reply_data.user = comment_re1;
                                comment_re.push(results_comment_reply_data);
                                if (idx_re === array_re.length - 1) {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        commentReplyCountListCount: c,
                                        commentReplyCountList: comment_re
                                    });
                                }
                            }

                        }
                    });
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                         commentReplyCountListCount: 0,
                                commentReplyCountList: []
                });
            }
        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
             commentReplyCountListCount: 0,
                                commentReplyCountList: []
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.comment_reply_reply_count = async (req, res) => {
	try {
    if (req.query.comment_reply_reply_id) {
        var comment_re = [];
        db.query(`SELECT comment_reply_reply_feeling_string, COUNT(*) as count FROM tbl_comment_reply_reply_reaction WHERE reaction_comment_reply_reply_id = ? GROUP BY comment_reply_reply_feeling_string`, [req.query.comment_reply_reply_id], function(error, results_comment_re, fields) {
            if (error) throw error;
            if (results_comment_re.length > 0) {
                var c = 0;
                //// //////console.log(results_comment_re);
                Object.keys(results_comment_re).forEach(function(key_re, idx_re, array_re) {
                    var results_comment_reply_reply_data = results_comment_re[key_re];
                    var comment_re1 = [];
                    c = c + results_comment_reply_reply_data.count;
                    db.query(`SELECT * FROM tbl_comment_reply_reply_reaction WHERE reaction_comment_reply_reply_id = ? and comment_reply_reply_feeling_string=?`, [req.query.comment_reply_reply_id, results_comment_reply_reply_data.comment_reply_reply_feeling_string], function(error, results_comment_reply_reply, fields) {
                        if (error) {} else {
                            if (results_comment_reply_reply.length > 0) {
                                //// //////console.log(results_comment_reply_reply);
                                Object.keys(results_comment_reply_reply).forEach(function(key_re12, idx_re12, array_re12) {
                                    var results_comment_reply_reply_data1 = results_comment_reply_reply[key_re12];
                                    db.query(`SELECT * FROM tbl_user_profile WHERE user_id = ?;SELECT * FROM tbl_friend_request WHERE (receiver_user_id = ? or sender_user_id = ?) AND request_status = ?`, [results_comment_reply_reply_data1.reaction_user_id, results_comment_reply_reply_data1.reaction_user_id, results_comment_reply_reply_data1.reaction_user_id, '1'], function(error, results_comment_reply_reply12, fields) {
                                        if (error) {} else {
                                            if (results_comment_reply_reply12[0].length > 0)
                                                comment_re1.push({
                                                    user_id: results_comment_reply_reply12[0][0].user_id,
                                                    user_name: results_comment_reply_reply12[0][0].user_name,
                                                    user_profile_img: results_comment_reply_reply12[0][0].user_profile_img,
                                                    user_phone: results_comment_reply_reply12[0][0].user_phone,
                                                    friendCount: results_comment_reply_reply12[1].length
                                                });
                                            if (idx_re12 === array_re12.length - 1) {
                                                results_comment_reply_reply_data.user = comment_re1;
                                                comment_re.push(results_comment_reply_reply_data);
                                                if (idx_re === array_re.length - 1) {
                                                    return res.status(200).send({
                                                        status: 200,
                                                        msg: "Success",
                                                        commentReplyReplyCountListCount: c,
                                                        commentReplyReplyCountList: comment_re
                                                    });
                                                }
                                            }
                                        }
                                    });
                                });
                            } else {
                                results_comment_reply_reply_data.user = comment_re1;
                                comment_re.push(results_comment_reply_reply_data);
                                if (idx_re === array_re.length - 1) {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        commentReplyReplyCountListCount: c,
                                        commentReplyReplyCountList: comment_re
                                    });
                                }
                            }

                        }
                    });
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                     commentReplyReplyCountListCount: 0,
                                commentReplyReplyCountList: []
                });
            }
        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
             commentReplyReplyCountListCount: 0,
                                commentReplyReplyCountList: []
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.view_count = async (req, res) => {
	try {
    if (req.query.feed_id) {
        db.query(` select * From tbl_feed where feed_id= ?`, [req.query.feed_id], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            } else {
                if (results.length > 0) {
                    var count = results[0].feed_view_count + 1;
                    var d = {
                        feed_view_count: count
                    };
                    db.query(`UPDATE tbl_feed SET ? where feed_id= ?`, [d, req.query.feed_id], function(error, results_update, fields) {
                        if (error) {
                            return res.status(400).send({
                                status: 400,
                                msg: "fail"
                            });
                        } else {
                            return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                viewCount: count
                            });
                        }
                    });
                } else {
                    return res.status(200).send({
                        status: 200,
                        msg: "Success",
                        viewCount: (results.length > 0) ? results[0].feed_view_count : 0
                    });
                }
            }
        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            viewCount:0
        });
    }

	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.notification_data = async (req, res) => {
	try {
    if (req.query.feed_id && req.query.user_id) {
        var ke = [];
        db.query(`select * From tbl_feed where feed_id= ?;select count(*) as total From tbl_feed_comment where comment_feed_id= ? and comment_operation=?;select * From tbl_like_details where like_details_feed_id= ? and like_details_liked_user_id=?;`, [req.query.feed_id, req.query.feed_id, '0', req.query.feed_id, req.query.user_id], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            } else {
                ke.push({
                    "feed_id": (results[0].length > 0) ? results[0][0].feed_id : '',
                    "feed_user_id": (results[0].length > 0) ? results[0][0].feed_user_id : '',
                    "feed_user_image": (results[0].length > 0) ? results[0][0].feed_user_image : '',
                    "feed_text": (results[0].length > 0) ? results[0][0].feed_text : '',
                    "feed_user_name": (results[0].length > 0) ? results[0][0].feed_user_name : '',
                    "feed_user_register_id": (results[0].length > 0) ? results[0][0].feed_user_register_id : '',
                    "feed_media": (results[0].length > 0) ? results[0][0].feed_media : '',
                    "created_date": (results[0].length > 0) ? results[0][0].created_date : '',
                    "modified_date": (results[0].length > 0) ? results[0][0].modified_date : '',
                    "feed_fellings": (results[2].length > 0) ? results[2][0].feed_fellings : "8",
                    "feed_sharing_count": (results[0].length > 0) ? results[0][0].feed_sharing_count : '',
                    "feed_like_count": (results[0].length > 0) ? results[0][0].feed_like_count : '',
                    "feed_comment_count": results[1][0].total

                });
                return res.status(200).send({
                    status: 200,
                    msg: "Success",
                    data: ke[0]
                });

            }
        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            data:{}
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.feed_like = async (req, res) => {
	try {
    if (req.query.like_user_id && req.query.feed_id) {
        db.query(`select * From tbl_like_details where like_details_liked_user_id= ? and like_details_feed_id=?; select * From tbl_feed where feed_id= ?`, [req.query.like_user_id, req.query.feed_id, req.query.feed_id], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            } else {
                if (req.query.flag == 1) {
                    if (results[1].length > 0) {
                        if (results[0].length <= 0) {
                            var count = results[1][0].feed_like_count + 1;
                            var d = {
                                feed_like_count: count
                            };
                            db.query(`UPDATE tbl_feed SET ? where feed_id= ?`, [d, req.query.feed_id], function(error, results_update, fields) {
                                if (error) {

                                } else {}
                            });
                            delete(req.query.flag);
                            req.query.like_details_liked_user_id = req.query.like_user_id;
                            req.query.like_details_feed_id = req.query.feed_id;
                            delete(req.query.like_user_id);
                            delete(req.query.feed_id);
                            db.query(`INSERT INTO tbl_like_details SET ?`, req.query, function(error, resultsw, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        likeCount: count
                                    });
                                }
                            });
                        } else {
                            db.query(`UPDATE tbl_like_details SET ? where like_details_feed_id=? and like_details_liked_user_id = ?`, [{
                                feed_fellings: req.query.feed_fellings
                            }, req.query.feed_id, req.query.like_user_id], function(error, resultse, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: "fail1"
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        likeCount: results[1][0].feed_like_count
                                    });
                                }
                            });
                        }
                    } else {
                        return res.status(400).send({
                            status: 400,
                            msg: 'fail31'
                        });
                    }
                } else {
                    if (results[1].length > 0) {
                        if (results[0].length > 0) {
                            var count = 0;
                            if (results[1][0].feed_like_count > 0) {
                                count = results[1][0].feed_like_count - 1;
                            }
                            var d = {
                                feed_like_count: count
                            };
                            db.query(`UPDATE tbl_feed SET ? where feed_id= ?`, [d, req.query.feed_id], function(error, results_update, fields) {
                                if (error) {
                                } else {}
                            });
                            db.query(`DELETE from tbl_like_details where like_details_feed_id=? and like_details_liked_user_id = ?`, [req.query.feed_id, req.query.like_user_id], function(error, resultser, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: "fail"
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        likeCount: count
                                    });
                                }
                            });
                        } else {
                            return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                likeCount: (results[1].length > 0) ? results[1][0].feed_like_count : 0
                            });
                        }

                    } else {
                        return res.status(400).send({
                            status: 400,
                            msg: 'fail',
                            likeCount:0
                        });
                    }
                }
            }
        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            likeCount:0
        });
    }

	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_feed_details = async (req, res) => {
	try {
    if (req.query.feed_id) {
        var ke = [];
        //console.log(res.totalFriendList);
        //console.log(res.requestStatus);
        db.query(`select * From tbl_feed where feed_id= ? and feed_is_deleted=?;`, [req.query.feed_id, '0'], function(error, results12, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            } else {
                if (results12.length > 0) {
                    db.query(`select count(*) as total From tbl_feed_comment where comment_feed_id= ? and comment_operation=?;
                    select count(*) as total From tbl_followers where feed_id= ?;
                    select count(*) as total From tbl_like_details where like_details_feed_id= ? ;
                     select count(*) as total From tbl_feed_share where feed_id= ?;
                     select * From tbl_feed_hide where feed_id= ? and feed_hide_user_id=?;
                     select feed_fellings from tbl_like_details where like_details_feed_id= ? order by like_details_id desc limit 1`,
                        [req.query.feed_id, '0',
                            req.query.feed_id,
                            req.query.feed_id,
                            req.query.feed_id,
                            req.query.feed_id, results12[0].feed_user_id,
                            req.query.feed_id
                        ],
                        function(error, results, fields) {
                            if (error) {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail2"
                                });
                            } else {
                                if (results[4].length <= 0) {
                                    results12[0].feed_duration = timeAgo(new Date(results12[0].created_date).toISOString());
                                    //////console.log(results12[0]);
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                       // test: results[5][0].feed_fellings,
                                        "comment_count": results[0][0].total,
                                        "follower_count": results[1][0].total,
                                        "reaction_count": results[2][0].total,
                                        "share_count": results[3][0].total,
                                        "feed_details": results12[0],
                                        "share_list": res.feedshare,
                                        "follower_list": res.feedfollower,
                                        "reaction_list": res.feedreaction,
                                        "comment_list": res.commentList,
                                    });
                                } else {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: "Records Not Found.",
                                            "comment_count": 0,
                                        "follower_count": 0,
                                        "reaction_count": 0,
                                        "share_count": 0,
                                        "feed_details": {},
                                        "share_list": [],
                                        "follower_list": [],
                                        "reaction_list": [],
                                        "comment_list": [],
                                    });
                                }
                            }
                        });
                } else {
                    return res.status(400).send({
                        status: 400,
                        msg: "Records Not Found.",
                                     "comment_count": 0,
                                        "follower_count": 0,
                                        "reaction_count": 0,
                                        "share_count": 0,
                                        "feed_details": {},
                                        "share_list": [],
                                        "follower_list": [],
                                        "reaction_list": [],
                                        "comment_list": [],
                    });
                }
            }
        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail1",
                         "comment_count": 0,
                                        "follower_count": 0,
                                        "reaction_count": 0,
                                        "share_count": 0,
                                        "feed_details": {},
                                        "share_list": [],
                                        "follower_list": [],
                                        "reaction_list": [],
                                        "comment_list": [],
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.comment_reaction = async (req, res) => {
	try {
    //console.log("first");
    let upload = multer({
        storage: storage,
    }).single('user_profile_background');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        } else {
            if (req.body.reaction_user_id && req.body.reaction_comment_id) {
                db.query(`select * From tbl_feed_comment where comment_operation= ? and comment_id=?`, ['0', req.body.reaction_comment_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: "fail1"
                        });
                    } else {
                        if (req.body.flag == 1) {
                            if (results.length > 0) {
                                db.query(`SELECT * FROM tbl_comment_reaction where reaction_user_id=? AND reaction_comment_id= ?`, [req.body.reaction_user_id, req.body.reaction_comment_id], function(error, results_update, fields) {
                                    if (error) {
                                        return res.status(400).send({
                                            status: 400,
                                            msg: "fail2"
                                        });
                                    } else {
                                        delete(req.body.flag);
                                        if (results_update.length <= 0) {
                                            db.query(`INSERT INTO tbl_comment_reaction SET ?`, req.body, function(error, results, fields) {
                                                if (error) {
                                                    return res.status(400).send({
                                                        status: 400,
                                                        msg: error,
                                                        
                                                    });
                                                } else {
                                                    return res.status(200).send({
                                                        status: 200,
                                                        msg: "Success"
                                                    });
                                                }
                                            });
                                        } else {
                                            db.query(`UPDATE tbl_comment_reaction SET ? where reaction_user_id=? AND reaction_comment_id= ? `, [{
                                                comment_feeling_string: req.body.comment_feeling_string
                                            }, req.body.reaction_user_id, req.body.reaction_comment_id], function(error, results, fields) {
                                                if (error) {
                                                    return res.status(400).send({
                                                        status: 400,
                                                        msg: "fail4"
                                                    });
                                                } else {
                                                    return res.status(200).send({
                                                        status: 200,
                                                        msg: "Success"
                                                    });
                                                }
                                            });
                                        }
                                    }
                                });
                            } else {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Record Not Found1."
                                });
                            }
                        } else {
                            if (results.length > 0) {

                                db.query(`DELETE from tbl_comment_reaction where reaction_comment_id=? and reaction_user_id = ?`, [req.body.reaction_comment_id, req.body.reaction_user_id], function(error, results, fields) {
                                    if (error) {
                                        return res.status(400).send({
                                            status: 400,
                                            msg: "fail5"
                                        });
                                    } else {
                                        return res.status(200).send({
                                            status: 200,
                                            msg: "Success"
                                        });
                                    }
                                });

                            } else {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Record Not Found2."
                                });
                            }
                        }
                    }
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail6"
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.comment_reply_reaction = async (req, res) => {
	try {
    let upload = multer({
        storage: storage,
    }).single('user_profile_background');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        } else {
            if (req.body.reaction_user_id && req.body.comment_reply_id) {
                db.query(`select * From tbl_feed_comment_reply where comment_reply_id=?;`, [req.body.comment_reply_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: "fail1"
                        });
                    } else {
                        if (req.body.flag == 1) {
                            if (results.length > 0) {
                                db.query(`SELECT * FROM tbl_comment_reply_reaction where reaction_user_id=? AND reaction_comment_reply_id= ?`, [req.body.reaction_user_id, req.body.comment_reply_id], function(error, results_update, fields) {
                                    if (error) {
                                        return res.status(400).send({
                                            status: 400,
                                            msg: "fail2"
                                        });
                                    } else {
                                        delete(req.body.flag);
                                        req.body.reaction_comment_reply_id=req.body.comment_reply_id;
                                        delete(req.body.comment_reply_id);
                                        if (results_update.length <= 0) {
                                            db.query(`INSERT INTO tbl_comment_reply_reaction SET ?`, req.body, function(error, results, fields) {
                                                if (error) {
                                                    return res.status(400).send({
                                                        status: 400,
                                                        msg: error
                                                    });
                                                } else {
                                                    return res.status(200).send({
                                                        status: 200,
                                                        msg: "Success"
                                                    });
                                                }
                                            });
                                        } else {
                                            db.query(`UPDATE tbl_comment_reply_reaction SET ? where reaction_user_id=? AND reaction_comment_reply_id= ? `, [{
                                                comment_reply_feeling_string: req.body.comment_reply_feeling_string
                                            }, req.body.reaction_user_id, req.body.comment_reply_id], function(error, results, fields) {
                                                if (error) {
                                                    return res.status(400).send({
                                                        status: 400,
                                                        msg: "fail4"
                                                    });
                                                } else {
                                                    return res.status(200).send({
                                                        status: 200,
                                                        msg: "Success"
                                                    });
                                                }
                                            });
                                        }
                                    }
                                });
                            } else {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Record Not Found."
                                });
                            }
                        } else {
                            if (results.length > 0) {

                                db.query(`DELETE from tbl_comment_reply_reaction where reaction_comment_reply_id=? and reaction_user_id = ?`, [req.body.comment_reply_id, req.body.reaction_user_id], function(error, results, fields) {
                                    if (error) {
                                        return res.status(400).send({
                                            status: 400,
                                            msg: "fail5"
                                        });
                                    } else {
                                        return res.status(200).send({
                                            status: 200,
                                            msg: "Success"
                                        });
                                    }
                                });

                            } else {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Record Not Found."
                                });
                            }
                        }
                    }
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.comment_reply_reply_reaction = async (req, res) => {
	try {
    let upload = multer({
        storage: storage,
    }).single('user_profile_background');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        } else {
            if (req.body.reaction_user_id && req.body.comment_reply_reply_id) {
                db.query(`select * From tbl_feed_comment_reply_reply where comment_reply_reply_id=?;`, [req.body.comment_reply_reply_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: "fail"
                        });
                    } else {
                        if (req.body.flag == 1) {
                            if (results.length > 0) {
                                db.query(`SELECT * FROM tbl_comment_reply_reply_reaction where reaction_user_id=? AND reaction_comment_reply_reply_id= ?`, [req.body.reaction_user_id, req.body.comment_reply_reply_id], function(error, results_update, fields) {
                                    if (error) {
                                        return res.status(400).send({
                                            status: 400,
                                            msg: "fail"
                                        });
                                    } else {
                                        delete(req.body.flag);
                                        req.body.reaction_comment_reply_reply_id=req.body.comment_reply_reply_id;
                                        delete(req.body.comment_reply_reply_id);
                                        if (results_update.length <= 0) {
                                            db.query(`INSERT INTO tbl_comment_reply_reply_reaction SET ?`, req.body, function(error, results, fields) {
                                                if (error) {
                                                    return res.status(400).send({
                                                        status: 400,
                                                        msg: "fail"
                                                    });
                                                } else {
                                                    return res.status(200).send({
                                                        status: 200,
                                                        msg: "Success"
                                                    });
                                                }
                                            });
                                        } else {
                                            db.query(`UPDATE tbl_comment_reply_reply_reaction SET ? where reaction_user_id=? AND reaction_comment_reply_reply_id= ? `, [{
                                                comment_reply_reply_feeling_string: req.body.comment_reply_reply_feeling_string
                                            }, req.body.reaction_user_id, req.body.comment_reply_reply_id], function(error, results, fields) {
                                                if (error) {
                                                    return res.status(400).send({
                                                        status: 400,
                                                        msg: "fail"
                                                    });
                                                } else {
                                                    return res.status(200).send({
                                                        status: 200,
                                                        msg: "Success"
                                                    });
                                                }
                                            });
                                        }
                                    }
                                });
                            } else {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Record Not Found."
                                });
                            }
                        } else {
                            if (results.length > 0) {

                                db.query(`DELETE from tbl_comment_reply_reply_reaction where reaction_comment_reply_reply_id=? and reaction_user_id = ?`, [req.body.comment_reply_reply_id, req.body.reaction_user_id], function(error, results, fields) {
                                    if (error) {
                                        return res.status(400).send({
                                            status: 400,
                                            msg: "fail"
                                        });
                                    } else {
                                        return res.status(200).send({
                                            status: 200,
                                            msg: "Success"
                                        });
                                    }
                                });

                            } else {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Record Not Found."
                                });
                            }
                        }
                    }
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_all_comment_count = async (req, res) => {
	try {
    if (req.query.comment_id) {
        var comment_re = [];
        db.query(`SELECT comment_feeling_string, COUNT(*) as count FROM tbl_comment_reaction WHERE reaction_comment_id = ? GROUP BY comment_feeling_string`, [req.query.comment_id], function(error, results_comment_re, fields) {
            if (error) throw error;
            if (results_comment_re.length > 0) {
                var c = 0;
                //// //////console.log(results_comment_re);
                Object.keys(results_comment_re).forEach(function(key_re, idx_re, array_re) {
                    var results_comment_data = results_comment_re[key_re];
                    var comment_re1 = [];
                    c = c + results_comment_data.count;
                    db.query(`SELECT * FROM tbl_comment_reaction WHERE reaction_comment_id = ? and comment_feeling_string=?`, [req.query.comment_id, results_comment_data.comment_feeling_string], function(error, results_comment, fields) {
                        if (error) {} else {
                            if (results_comment.length > 0) {
                                //// //////console.log(results_comment);
                                Object.keys(results_comment).forEach(function(key_re12, idx_re12, array_re12) {
                                    var results_comment_data1 = results_comment[key_re12];
                                    db.query(`SELECT * FROM tbl_user_profile WHERE user_id = ?;SELECT * FROM tbl_friend_request WHERE (receiver_user_id = ? or sender_user_id = ?) AND request_status = ?`, [results_comment_data1.reaction_user_id, results_comment_data1.reaction_user_id, results_comment_data1.reaction_user_id, '1'], function(error, results_comment12, fields) {
                                        if (error) {} else {
                                            if (results_comment12[0].length > 0)
                                                comment_re1.push({
                                                    user_id: results_comment12[0][0].user_id,
                                                    user_name: results_comment12[0][0].user_name,
                                                    user_profile_img: results_comment12[0][0].user_profile_img,
                                                    user_phone: results_comment12[0][0].user_phone,
                                                    friendCount: results_comment12[1].length
                                                });
                                            if (idx_re12 === array_re12.length - 1) {
                                                results_comment_data.user = comment_re1;
                                                comment_re.push(results_comment_data);
                                                if (idx_re === array_re.length - 1) {
                                                    return res.status(200).send({
                                                        status: 200,
                                                        msg: "Success",
                                                        totalCommentReactionCount: c,
                                                        commentCountList: comment_re
                                                    });
                                                }
                                            }
                                        }
                                    });
                                });
                            } else {
                                results_comment_data.user = comment_re1;
                                comment_re.push(results_comment_data);
                                if (idx_re === array_re.length - 1) {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        totalCommentReactionCount: c,
                                        commentCountList: comment_re
                                    });
                                }
                            }

                        }
                    });
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                      totalCommentReactionCount:0,
                                                        commentCountList: []
                });
            }
        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
                   totalCommentReactionCount:0,
                                                        commentCountList: []
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_hidden_feed = async (req, res) => {
	try {
    var pagination = [];
    if (req.query.user_id && req.query.page_no) {
        var no_of_records_per_page = 10;
        var rowno = req.query.page_no;
        if (rowno != 0) {
            rowno = (rowno - 1) * no_of_records_per_page;
        }
        var comment = [];
        db.query(`SELECT tbl_feed_hide.* FROM tbl_feed_hide inner join tbl_feed on tbl_feed_hide.feed_id=tbl_feed.feed_id  where feed_hide_user_id=? LIMIT ? OFFSET ?;SELECT COUNT(*) AS numrows FROM tbl_feed_hide  inner join tbl_feed on tbl_feed_hide.feed_id=tbl_feed.feed_id   where feed_hide_user_id=?`, [req.query.user_id, no_of_records_per_page, rowno, req.query.user_id], function(error, results_comment, fields) {
            if (error) throw error;
            if (results_comment[0].length > 0) {
                Object.keys(results_comment[0]).forEach(function(key12, idx12, array12) {
                    var results_comment_data = results_comment[0][key12];
                    db.query(`SELECT * FROM tbl_feed where feed_id=?`, [results_comment_data.feed_id], function(error, results_rating, fields) {
                        if (error) throw error;
                        if (results_rating.length > 0) {
                            results_comment_data.feed_id = results_rating[0].feed_id;
                            results_comment_data.feed_user_name = results_rating[0].feed_user_name;
                            results_comment_data.feed_media = results_rating[0].feed_media;
                            results_comment_data.feed_text = results_rating[0].feed_text;
                            results_comment_data.feed_video_thumbnail = results_rating[0].feed_video_thumbnail;
                            results_comment_data.feed_hide_id = results_comment_data.feed_hide_id;
                             results_comment_data.feed_source = results_rating[0].feed_source;
                            comment.push(results_comment_data);
                            if (idx12 === array12.length - 1) {
                                let max_pages = parseInt(Math.ceil((results_comment[1][0].numrows) / no_of_records_per_page));
                                if (req.query.page_no && req.query.page_no <= max_pages) {
                                    let page_no = req.query.page_no;
                                    // PAGINATION START
                                    let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
                                    //  let sliceData = final_array.slice(offset, offset + no_of_records_per_page)
                                    var pagination = {
                                        total_rows: results_comment[1][0].numrows,
                                        total_pages: parseInt(Math.ceil((results_comment[1][0].numrows) / no_of_records_per_page)),
                                        per_page: no_of_records_per_page,
                                        offset: offset,
                                        current_page_no: page_no
                                    };
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        hiddenFeedListCount: results_comment[1][0].numrows,
                                        hiddenFeedList: comment,
                                        pagination: pagination
                                    });
                                } else {
                                    return res.status(404).send({
                                        status: 404,
                                        msg: "Page no missing or Its incorrect."
                                    });
                                }
                            }
                        } else {

                            if (idx12 === array12.length - 1) {
                                let max_pages = parseInt(Math.ceil((results_comment[1][0].numrows) / no_of_records_per_page));
                                if (req.query.page_no && req.query.page_no <= max_pages) {
                                    let page_no = req.query.page_no;
                                    // PAGINATION START
                                    let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
                                    //  let sliceData = final_array.slice(offset, offset + no_of_records_per_page)
                                    var pagination = {
                                        total_rows: results_comment[1][0].numrows,
                                        total_pages: parseInt(Math.ceil((results_comment[1][0].numrows) / no_of_records_per_page)),
                                        per_page: no_of_records_per_page,
                                        offset: offset,
                                        current_page_no: page_no
                                    };
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        hiddenFeedListCount: results_comment[1][0].numrows,
                                        hiddenFeedList: comment,
                                        pagination: pagination
                                    });
                                } else {
                                    return res.status(404).send({
                                        status: 404,
                                        msg: "Page no missing or Its incorrect.",
                                           hiddenFeedListCount: 0,
                                        hiddenFeedList: [],
 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }

                                    });
                                }
                            }

                        }

                    });
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                                            hiddenFeedListCount: 0,
                                        hiddenFeedList: [],
 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                });
            }
        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
                                    hiddenFeedListCount: 0,
                                        hiddenFeedList: [],
 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
        });
    }

	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_save_feed = async (req, res) => {
	try {
    var pagination = [];
    if (req.query.user_id && req.query.page_no) {
        var no_of_records_per_page = 10;
        var rowno = req.query.page_no;
        if (rowno != 0) {
            rowno = (rowno - 1) * no_of_records_per_page;
        }
        var comment = [];
        db.query(`SELECT tbl_save_feed.* FROM tbl_save_feed inner join tbl_feed on tbl_save_feed.feed_id=tbl_feed.feed_id where save_feed_user_id=? LIMIT ? OFFSET ?;SELECT COUNT(*) AS numrows FROM tbl_save_feed inner join tbl_feed on tbl_save_feed.feed_id=tbl_feed.feed_id where save_feed_user_id=?`, [req.query.user_id, no_of_records_per_page, rowno, req.query.user_id], function(error, results_comment, fields) {
            if (error) throw error;
              if(results_comment[0].length==0){
                results_comment[0]={
                    feed_id:''
                };
            }
            if (results_comment[0].length > 0) {
                Object.keys(results_comment[0]).forEach(function(key12, idx12, array12) {
                    var results_comment_data = results_comment[0][key12];
                    db.query(`SELECT * FROM tbl_feed where feed_id=?`, [results_comment_data.feed_id], function(error, results_rating, fields) {
                        if (error) throw error;
                        if (results_rating.length > 0) {
                            results_comment_data.feed_id = results_rating[0].feed_id;
                            results_comment_data.feed_user_name = results_rating[0].feed_user_name;
                            results_comment_data.feed_media = results_rating[0].feed_media;
                            results_comment_data.feed_text = results_rating[0].feed_text;
                            results_comment_data.feed_video_thumbnail = results_rating[0].feed_video_thumbnail;
                             results_comment_data.feed_source = results_rating[0].feed_source;
                             if(results_comment_data.feed_id!='')
                            comment.push(results_comment_data);
                            if (idx12 === array12.length - 1) {
                                let max_pages = parseInt(Math.ceil((results_comment[1][0].numrows) / no_of_records_per_page));
                                if (req.query.page_no && req.query.page_no <= max_pages) {
                                    let page_no = req.query.page_no;
                                    // PAGINATION START
                                    let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
                                    //  let sliceData = final_array.slice(offset, offset + no_of_records_per_page)
                                    var pagination = {
                                        total_rows: results_comment[1][0].numrows,
                                        total_pages: parseInt(Math.ceil((results_comment[1][0].numrows) / no_of_records_per_page)),
                                        per_page: no_of_records_per_page,
                                        offset: offset,
                                        current_page_no: page_no
                                    };
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        savedFeedListCount: results_comment[1][0].numrows,
                                        savedFeedList: comment,
                                        pagination: pagination
                                    });
                                } else {
                                    return res.status(404).send({
                                        status: 404,
                                        msg: "Page no missing or Its incorrect.",
                                                                savedFeedListCount: 0,
                                        savedFeedList: [],
 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                                    });
                                }
                            }
                        } else {

                            if (idx12 === array12.length - 1) {
                                let max_pages = parseInt(Math.ceil((results_comment[1][0].numrows) / no_of_records_per_page));
                                if (req.query.page_no && req.query.page_no <= max_pages) {
                                    let page_no = req.query.page_no;
                                    // PAGINATION START
                                    let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
                                    //  let sliceData = final_array.slice(offset, offset + no_of_records_per_page)
                                    var pagination = {
                                        total_rows: results_comment[1][0].numrows,
                                        total_pages: parseInt(Math.ceil((results_comment[1][0].numrows) / no_of_records_per_page)),
                                        per_page: no_of_records_per_page,
                                        offset: offset,
                                        current_page_no: page_no
                                    };
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        savedFeedListCount: results_comment[1][0].numrows,
                                        savedFeedList1: comment,
                                        pagination: pagination
                                    });
                                } else {
                                    return res.status(404).send({
                                        status: 404,
                                        msg: "Page no missing or Its incorrect.",
                                                                                                      savedFeedListCount: 0,
                                        savedFeedList: [],
 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                                    });
                                }
                            }

                        }

                    });
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                                                                                  savedFeedListCount: 0,
                                        savedFeedList: [],
 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                });
            }
        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
                                                                          savedFeedListCount: 0,
                                        savedFeedList: [],
 pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
        });
    }

	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.feed_share = async (req, res) => {
	try {
    if (req.body.feed_share_user_id && req.body.feed_id) {
        var msg = 'Shared post.';
        db.query(`select * From tbl_feed_share where feed_share_user_id= ? and feed_id=?; select * From tbl_feed where feed_id= ? and feed_is_deleted=?`, [req.body.feed_share_user_id, req.body.feed_id, req.body.feed_id, '0'], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            } else {
                if (results[1].length > 0) {
                    if (results[0].length <= 0) {
                        var count = results[1][0].feed_sharing_count + 1;
                        var d = {
                            feed_sharing_count: count
                        };
                        db.query(`UPDATE tbl_feed SET ? where feed_id= ?`, [d, req.body.feed_id], function(error, results_update, fields) {
                            if (error) {

                            } else {}
                        });
                        db.query(`INSERT INTO tbl_feed_share SET ?`, req.body, function(error, results, fields) {
                            if (error) {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail"
                                });
                            } else {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Shared post.",
                                    feed_sharing_count: count
                                });
                            }
                        });
                    } else {
                        return res.status(200).send({
                            status: 200,
                            msg: "Already shared post.",
                            feed_sharing_count: (results[1].length > 0) ? results[1][0].feed_sharing_count : 0
                        });
                    }
                } else {
                    return res.status(400).send({
                        status: 400,
                        msg: "Record not found.",
                        feed_sharing_count:0
                    });
                }
            }

        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            feed_sharing_count:0
        });
    }

	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.restore_hidden_feed = async (req, res) => {
	try {
    if (req.query.feed_hide_id) {
        db.query(`DELETE from tbl_feed_hide where feed_hide_id=?`, [req.query.feed_hide_id], function(error, results1, fields) {
            if (error) throw error;
            return res.status(200).send({
                status: 200,
                msg: "Success"
            });
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail"
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.remove_feed_from_save_list = async (req, res) => {
	try {
    if (req.query.save_feed_id) {
        db.query(`DELETE from tbl_save_feed where save_feed_id=?`, [req.query.save_feed_id], function(error, results1, fields) {
            if (error) throw error;
            return res.status(200).send({
                status: 200,
                msg: "Success"
            });
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail"
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.delete_feed = async (req, res) => {
	try {
    if (req.query.feed_user_id && req.query.feed_id) {
        db.query(`select * From tbl_events where event_user_id= ? and feed_id=? and event_status=?; select * From tbl_feed where feed_id= ? and feed_is_deleted=?`, [req.query.feed_user_id, req.query.feed_id, '0', req.query.feed_id, '0'], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            } else {
                if (results[1].length > 0) {
                    var d = {
                        feed_is_deleted: '1'
                    };
                    db.query(`UPDATE tbl_feed SET ? where feed_id= ?`, [d, req.query.feed_id], function(error, results_update, fields) {
                        if (error) {

                        } else {
                            if (results[0].length > 0) {
                                db.query(`UPDATE tbl_events SET ? where event_user_id= ? and feed_id=?`, [{
                                    event_status: '1'
                                }, req.query.feed_user_id, req.query.feed_id], function(error, results, fields) {
                                    if (error) {
                                        return res.status(400).send({
                                            status: 400,
                                            msg: "fail"
                                        });
                                    } else {
                                        return res.status(200).send({
                                            status: 200,
                                            msg: "Success"
                                        });
                                    }
                                });
                            } else {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Success"
                                });
                            }
                        }
                    });
                } else {
                         if (results[0].length > 0) {
                                db.query(`UPDATE tbl_events SET ? where event_user_id= ? and feed_id=?`, [{
                                    event_status: '1'
                                }, req.query.feed_user_id, req.query.feed_id], function(error, results, fields) {
                                    if (error) {
                                        return res.status(400).send({
                                            status: 400,
                                            msg: "fail"
                                        });
                                    } else {
                                        return res.status(200).send({
                                            status: 200,
                                            msg: "Success"
                                        });
                                    }
                                });
                            } else {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Success"
                                });
                            }
                }
            }
        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail"
        });
    }

	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.unfollow = async (req, res) => {
	try {
    if (req.query.feed_user_id && req.query.user_id) {
        db.query(`SELECT * FROM tbl_friend_request WHERE receiver_user_id = ? and sender_user_id = ? AND request_status = ?;SELECT * FROM tbl_friend_request WHERE receiver_user_id = ? and sender_user_id = ? AND request_status = ?`, [req.query.feed_user_id, req.query.user_id, '1', req.query.user_id, req.query.feed_user_id, '1'], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            } else {
                var d = {
                    request_status: '6',
                    request_msg: 'Unfollow'
                };
                if (results[0].length > 0) {
                    db.query(`UPDATE tbl_friend_request SET ? where receiver_user_id= ? and sender_user_id=?`, [d, req.query.feed_user_id, req.query.user_id], function(error, results, fields) {
                        if (error) {
                            return res.status(400).send({
                                status: 400,
                                msg: "fail"
                            });
                        } else {
                            return res.status(200).send({
                                status: 200,
                                msg: "Success"
                            });
                        }
                    });
                } else {
                    if (results[1].length > 0) {
                        db.query(`UPDATE tbl_friend_request SET ? where receiver_user_id= ? and sender_user_id=?`, [d, req.query.user_id, req.query.feed_user_id], function(error, results, fields) {
                            if (error) {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail"
                                });
                            } else {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Success"
                                });
                            }
                        });
                    } else {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success"
                        });
                    }
                }
            }
        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail"
        });
    }

	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.block = async (req, res) => {
	try {
    if (req.query.feed_user_id && req.query.user_id) {
        db.query(`SELECT * FROM tbl_friend_request WHERE receiver_user_id = ? and sender_user_id = ? AND request_status = ?;SELECT * FROM tbl_friend_request WHERE receiver_user_id = ? and sender_user_id = ? AND request_status = ?`, [req.query.feed_user_id, req.query.user_id, '1', req.query.user_id, req.query.feed_user_id, '1'], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            } else {
                var d = {
                    request_status: '4',
                    request_msg: 'Blocked'
                };
                if (results[0].length > 0) {

                    db.query(`UPDATE tbl_friend_request SET ? where receiver_user_id= ? and sender_user_id=?`, [d, req.query.feed_user_id, req.query.user_id], function(error, results, fields) {
                        if (error) {
                            return res.status(400).send({
                                status: 400,
                                msg: "fail"
                            });
                        } else {
                            return res.status(200).send({
                                status: 200,
                                msg: "Success"
                            });
                        }
                    });
                } else {
                    if (results[1].length > 0) {
                        db.query(`UPDATE tbl_friend_request SET ? where receiver_user_id= ? and sender_user_id=?`, [d, req.query.user_id, req.query.feed_user_id], function(error, results, fields) {
                            if (error) {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail"
                                });
                            } else {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Success"
                                });
                            }
                        });
                    } else {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success"
                        });
                    }
                }
            }
        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail"
        });
    }

	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
