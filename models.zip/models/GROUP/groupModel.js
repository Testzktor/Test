const fs = require('fs');
const db = require("../../config/connection");
const middleware = require("../../middleware/authentication");
var timeAgo = require('node-time-ago');
const {
    getVideoDurationInSeconds
} = require('get-video-duration')
const full = require("../USER/userFullProfile");
const multer = require('fastify-multer');
const crypto = require("crypto");
const {
    exec
} = require("child_process");
var path = require('path')
var storage = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, '../uploads/video/');
    },
    filename: function(req, file, cb) {
        cb(null, "video_" +crypto.createHash('md5').update('abcdefgh').digest('hex') + Date.now() + path.extname(file.originalname));
    }
});
var photo = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, '../uploads/group/');
    },
    filename: function(req, file, cb) {
        cb(null, "group_" +crypto.createHash('md5').update('abcdefgh').digest('hex') + Date.now() + path.extname(file.originalname));
    }
});

exports.update_feed_group_status = async (req, res) => {
	try {
    if (req.query.feed_group_status && req.query.group_ids) {
        var final_array = [];
        var array = (req.query.group_ids).split(",");
        console.log(array.length);
        let i = 0
        while (i < array.length) {
            db.query(`UPDATE tbl_feed SET feed_group_status = ? where feed_type = ?`, [req.query.feed_group_status, array[i]], function(error, results, fields) {
                if (error) {
                    return res.status(400).send({
                        status: 400,
                        msg: error
                    });
                } else {
                    if (i == array.length) {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success"
                        });
                    }
                }
            });
            i++;
        }
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail1"
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.update_group = async (req, res) => {
	try {
    let upload = multer({
        storage: photo,
    }).single('group_cover_page_image');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        } else {
            if (req.body.group_id) {
                   if (req.file && typeof req.file !== 'undefined') {
                                        req.body.group_cover_page_image = define.BASE_URL+"group/"+req.file.filename;
                                    }
                                    if(req.body.group_cover_page_image_url && req.body.group_cover_page_image_url!=''){
                                        req.body.group_cover_page_image =req.body.group_cover_page_image_url;
                                    }
                                    delete(req.body.group_cover_page_image_url);
                db.query(`Update tbl_group SET ? where group_id=?`, [req.body, req.body.group_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: "fail"
                        });
                    } else {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success"
                        });
                    }
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.accept_reject_request = async (req, res) => {
	try {
            if (req.query.group_id) {
                var id=req.query.group_id;
                delete(req.query.group_id);
                if(req.query.flag && req.query.flag==1){
                db.query(`SELECT group_id,group_member_user_id from  tbl_group_request_member where group_id=? and request_status_flag=?`, [id,'1'], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: "fail"
                        });
                    } else {
                        if(results.length>0){
                    Object.keys(results).forEach(function(key, idx1, array1) {
                       var result_file = results[key];
                    db.query(`Update tbl_group_request_member SET ? where group_id=?`, [{request_status_flag:'0'}, id], function(error, results, fields) {
                    if (error) {
                    } else {
                    }
                    });
                     db.query(`Update tbl_group_request_member SET ? where group_id=? and group_member_user_id=?`, [{request_status_flag:'0'}, result_file.group_id,result_file.group_member_user_id], function(error, results, fields) {
                    if (error) {
                    } else {
                    }
                    });
                    });
                        return res.status(200).send({
                            status: 200,
                            msg: "Success"
                        });
                        }else{
                             return res.status(400).send({
                            status: 400,
                            msg: "fail"
                        });
                        }
                    }
                });
                }else{
                db.query(`Update tbl_group_request_member SET ? where group_id=?`, [{request_status_flag:'0'}, id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: "fail"
                        });
                    } else {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success"
                        });
                    }
                });

                }
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.update_group_request_status = async (req, res) => {
	try {
            if (req.query.group_id) {
                var id=req.query.group_id;
                delete(req.query.group_id);
                db.query(`Update tbl_group_request_member SET ? where group_id=?`, [req.query, id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: "fail"
                        });
                    } else {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success"
                        });
                    }
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.update_group_invite_status = async (req, res) => {
	try {
            if (req.query.group_id) {
                var id=req.query.group_id;
                delete(req.query.group_id);
                db.query(`Update tbl_group_invite_member SET ? where group_id=?`, [req.query, id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: "fail"
                        });
                    } else {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success"
                        });
                    }
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_group = async (req, res) => {
	try {
    let upload = multer({
        storage: photo,
    }).single('group_cover_page_image');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        } else {
            if (req.body.group_name) {
                console.log( req.file);
                if (typeof req.file.filename !== 'undefined') {
                                        req.body.group_cover_page_image = define.BASE_URL+"group/"+req.file.filename;
                                    }
                                    if(req.body.group_cover_page_image_url && req.body.group_cover_page_image_url!=''){
                                        req.body.group_cover_page_image =req.body.group_cover_page_image_url;
                                    }
                                    delete(req.body.group_cover_page_image_url);
                db.query(`INSERT INTO tbl_group SET ?`, req.body, function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: "fail"
                        });
                    } else {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success",
                            group_id: results.insertId
                        });
                    }
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                    group_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_group_friend = async (req, res) => {
	try {
    if (req.query.user_id && req.query.group_id) {
        var final_array = [];
        var array = [];
        array = res.totalfriendsList;
        console.log(res.totalfriendsList);
        console.log(array.length);
        let i = 0
        if (array.length > 0) {
            array.forEach(function(element, index) {
                var sq = db.query(`SELECT * from tbl_group_member where group_id= ? and is_deleted =? and group_member_user_id=?;SELECT user_id,user_name,user_profile_img,user_register_id from tbl_user_profile where user_id= ?; SELECT * from tbl_group_invite_member where group_id= ? and group_member_user_id=?;SELECT * from tbl_group_request_member where group_id= ? and group_member_user_id=?`, [req.query.group_id, '0', element, element, req.query.group_id, element, req.query.group_id, element], function(error, results, fields) {
                    if (error) {

                    } else {
                        if(results[1].length<=0){
                            results[1][0]={
                                user_id:''
                            };
                        }
                        if(results[0].length <=0){
                           results[0][0]={group_id:''} ;
                        }
                        if (results[0].length > 0 && results[1].length) {
                            if (results[2].length > 0)
                                results[1][0].invitation_flag = results[2][0].invite_status_flag == 1 ? 1 : 2;
                            else
                                results[1][0].invitation_flag = 0;

                            if (results[3].length > 0)
                                results[1][0].request_flag = results[3].request_status_flag == 1 ? 1 : 2;
                            else
                                results[1][0].request_flag = 0;
                                if(results[1][0].user_id!='' && results[0][0].group_id==''){
                            final_array.push(results[1][0]);
                                }
                            if (index == array.length - 1) {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Success",
                                    friendGroupListCount: final_array.length,
                                    friendGroupList: final_array
                                });
                            }
                        } else {
                            if (index == array.length - 1) {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Success",
                                    friendGroupListCount: final_array.length,
                                    friendGroupList: final_array
                                });
                            }
                        }
                    }
                });
            });
        } else {
            return res.status(400).send({
                status: 400,
                msg: "fail",
                friendGroupListCount: 0,
                                    friendGroupList: []
            });
        }
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail1",
              friendGroupListCount: 0,
                                    friendGroupList: []
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_group_request = async (req, res) => {
	try {
    let upload = multer({
        storage: storage,
    }).single('group_cover_page_image');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        } else {
            if (req.body.group_id && req.body.group_member_user_id) {
                db.query(`SELECT *  from tbl_group_request_member where group_id = ? AND group_member_user_id = ?;select * from tbl_user_profile inner join tbl_group ON user_id=group_admin_user_id where tbl_group.group_id=?;select * from tbl_user_profile where user_id=?`, [req.body.group_id, req.body.group_member_user_id,req.body.group_id,req.body.group_member_user_id], function(error, results1, fields) {
                    if (error) throw error;
                    if (results1[0].length <= 0) {
                        db.query(`INSERT INTO tbl_group_request_member SET ?`, [req.body, req.body.group_id], function(error, results, fields) {
                            if (error) {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail"
                                });
                            } else {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Success",
                                    user_register_id:(results1[1][0]) ? results1[1][0].user_register_id : '',
                                    member_register_id:(results1[2][0]) ? results1[2][0].user_register_id : ''

                                });
                            }
                        });
                    } else {
                           db.query(`UPDATE tbl_group_request_member SET ? where group_id = ? AND group_member_user_id = ?`, [req.body, req.body.group_id,req.body.group_member_user_id], function(error, results, fields) {
                            if (error) {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail"
                                });
                            } else {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Success",
                                    user_register_id:(results1[1][0]) ? results1[1][0].user_register_id : '',
                                    member_register_id:(results1[2][0]) ? results1[2][0].user_register_id : ''

                                });
                            }
                        });
                    }
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                     user_register_id: '',
                                    member_register_id: ''
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_group_ignore_request = async (req, res) => {
	try {
    let upload = multer({
        storage: storage,
    }).single('group_cover_page_image');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        } else {
            if (req.body.group_ignore_group_id && req.body.group_ignore_user_id) {
                db.query(`SELECT *  from tbl_group_ignore where group_ignore_group_id = ? AND group_ignore_user_id = ?`, [req.body.group_ignore_group_id, req.body.group_ignore_user_id], function(error, results1, fields) {
                    if (error) throw error;
                    if (results1.length <= 0) {
                        db.query(`INSERT INTO tbl_group_ignore SET ?`, [req.body, req.body.group_id], function(error, results, fields) {
                            if (error) {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail"
                                });
                            } else {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Success"

                                });
                            }
                        });
                    } else {
                        return res.status(422).send({
                            status: 422,
                            msg: "Record already exists"
                        });
                    }
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_group_photo = async (req, res) => {
	try {
    let upload = multer({
        storage: photo,
    }).fields([{
        name: 'images',
        maxCount: 10
    }]);
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.group_id) {
                //console.log(req.files);
                var i = 0;
                var images = [];
                var id=[];
                var images_type = '';
                if (typeof req.files.images !== 'undefined') {
                    Object.keys(req.files.images).forEach(function(key, idx1, array1) {
                       var result_file = req.files.images[key];
                       images.push(define.BASE_URL+"group/"+result_file.filename);
                    req.body.group_photo_url=define.BASE_URL+"group/"+result_file.filename;
                      db.query(`INSERT INTO tbl_group_photo SET ?`, req.body, function(error, results, fields) {
                        if (error) {
                            return res.status(400).send({
                                status: 400,
                                msg: error
                            });
                        } else {
                            id.push({group_photo_id:results.insertId,group_photo_url:define.BASE_URL+"group/"+result_file.filename});
                              if (idx1 === array1.length - 1) {
                            return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                imageList:id
                            });
                              }
                        }
                    });
                    });
                } else {
                    return res.status(400).send({
                    status: 400,
                    msg: "fail",
                    imageList:[]
                });
                }
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                     imageList:[]
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_group_invite = async (req, res) => {
	try {
    let upload = multer({
        storage: storage,
    }).single('group_cover_page_image');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        } else {
            if (req.body.group_id && req.body.group_member_user_id) {
                db.query(`SELECT *  from tbl_group_invite_member where group_id = ? AND group_member_user_id = ?`, [req.body.group_id, req.body.group_member_user_id], function(error, results1, fields) {
                    if (error) throw error;
                    if (results1.length <= 0) {
                        db.query(`INSERT INTO tbl_group_invite_member SET ?;SELECT * FROM tbl_group where group_id = ?`, [req.body, req.body.group_id], function(error, results, fields) {
                            if (error) {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail"
                                });
                            } else {
                                if (results[1].length > 0) {
                                    db.query(`SELECT * FROM tbl_user_profile where user_id = ?`, [results[1][0].group_admin_user_id], function(error, results11, fields) {
                                        if (error) {
                                            return res.status(400).send({
                                                status: 400,
                                                msg: "fail"
                                            });
                                        } else {
                                            if (results11.length > 0) {
                                                return res.status(200).send({
                                                    status: 200,
                                                    msg: "Success",
                                                    user_register_id: results11[0].user_register_id
                                                });
                                            } else {
                                                return res.status(200).send({
                                                    status: 200,
                                                    msg: "Success",
                                                    user_register_id: ''
                                                });
                                            }
                                        }
                                    });

                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        user_register_id: ''
                                    });
                                }
                            }
                        });
                    } else {
                            db.query(`UPDATE tbl_group_invite_member SET ? where group_member_user_id=? and group_id=?;SELECT * FROM tbl_group where group_id = ?`, [req.body,req.body.group_member_user_id,req.body.group_id, req.body.group_id], function(error, results, fields) {
                            if (error) {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail"
                                });
                            } else {
                                if (results[1].length > 0) {
                                    db.query(`SELECT * FROM tbl_user_profile where user_id = ?`, [results[1][0].group_admin_user_id], function(error, results11, fields) {
                                        if (error) {
                                            return res.status(400).send({
                                                status: 400,
                                                msg: "fail"
                                            });
                                        } else {
                                            if (results11.length > 0) {
                                                return res.status(200).send({
                                                    status: 200,
                                                    msg: "Success",
                                                    user_register_id: results11[0].user_register_id
                                                });
                                            } else {
                                                return res.status(200).send({
                                                    status: 200,
                                                    msg: "Success",
                                                    user_register_id: ''
                                                });
                                            }
                                        }
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        user_register_id: ''
                                    });
                                }
                            }
                        });
                    }
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.delete_group = async (req, res) => {
	try {
    if (!req.query.group_id) {
        return res.status(400).send({
            status: 400,
            msg: "fail"
        });
    } else {
        db.query(`DELETE FROM tbl_group_photo WHERE group_id = ?;DELETE FROM tbl_group_query WHERE group_id = ?;DELETE FROM tbl_group_request_member WHERE group_id = ?;DELETE FROM tbl_group_invite_member WHERE group_id = ?;DELETE FROM tbl_user_group_media WHERE group_id = ?;DELETE FROM tbl_group_member WHERE group_id = ?;DELETE FROM tbl_group WHERE group_id = ?;`, [req.query.group_id, req.query.group_id, req.query.group_id, req.query.group_id, req.query.group_id, req.query.group_id, req.query.group_id], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: error
                });
            } else {
                return res.status(200).send({
                    status: 200,
                    msg: "Success"
                });
            }
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.delete_group_notice = async (req, res) => {
	try {
    if (!req.query.notice_board_id) {
        return res.status(400).send({
            status: 400,
            msg: "fail"
        });
    } else {
        db.query(`DELETE FROM tbl_group_notice_board WHERE notice_board_id = ?`, [req.query.notice_board_id], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: error
                });
            } else {
                return res.status(200).send({
                    status: 200,
                    msg: "Success"
                });
            }
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.delete_group_photo = async (req, res) => {
	try {
    if (!req.query.group_photo_id) {
        return res.status(400).send({
            status: 400,
            msg: "fail"
        });
    } else {
        db.query(`DELETE FROM tbl_group_photo WHERE group_photo_id = ?`, [req.query.group_photo_id], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: error
                });
            } else {
                return res.status(200).send({
                    status: 200,
                    msg: "Success"
                });
            }
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_group_query = async (req, res) => {
	try {
    if (!req.query.group_id) {
        return res.status(400).send({
            status: 400,
            msg: "fail"
        });
    } else {
        db.query(`SELECT * FROM tbl_group_query WHERE group_id = ? AND group_query_status = ? `, [req.query.group_id, '1'], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: error
                });
            } else {
                if (results.length > 0) {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        groupQueryListCount: results.length,
                                        groupQueryList: results[0]
                                    });
                } else {
                    return res.status(404).send({
                        status: 404,
                        msg: "No Record Found",
                         groupQueryListCount: 0,
                                        groupQueryList: []
                    });
                }
            }
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_group_query_reply = async (req, res) => {
	try {
    let upload = multer({
        storage: photo,
    }).fields([{
        name: 'images',
        maxCount: 10
    }]);
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.group_query_id && req.body.group_user_id) {
                      db.query(`INSERT INTO tbl_group_query_reply SET ?`, req.body, function(error, results, fields) {
                        if (error) {
                            return res.status(400).send({
                                status: 400,
                                msg: error
                            });
                        } else {
                            return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                group_query_reply_id:results.insertId
                            });
                        }
                    });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                    group_query_reply_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_group_request = async (req, res) => {
	try {
    if (!req.query.group_id) {
        return res.status(400).send({
            status: 400,
            msg: "fail"
        });
    } else {
        db.query(`SELECT * FROM tbl_group_request_member WHERE group_id = ? AND request_status_flag = ? `, [req.query.group_id, '1'], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: error
                });
            } else {
                if (results.length > 0) {
                    var final_array1 = [];
                    var cc = 0;
                    Object.keys(results).forEach(function(key, idx, array) {
                        var result_data = results[key];
                        db.query(`SELECT * FROM tbl_user_profile WHERE user_id = ? `, [result_data.group_member_user_id], function(err, rows_user, fields) {
                            if (err) {} else {
                                if (rows_user.length > 0) {
                                    result_data.user_id = rows_user[0].user_id;
                                    result_data.user_name = rows_user[0].user_name;
                                    result_data.user_profile_img = rows_user[0].user_profile_img;
                                } else {
                                    result_data.user_id = '';
                                    result_data.user_name = '';
                                    result_data.user_profile_img = '';
                                }


                                final_array1.push(result_data);
                                if (idx === array.length - 1) {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        userGroupRequestDetailsCount: final_array1.length,
                                        userGroupRequestDetails: final_array1
                                    });
                                }


                            }
                        });
                    });
                } else {
                    return res.status(404).send({
                        status: 404,
                        msg: "No Record Found",
                           userGroupRequestDetailsCount: 0,
                                        userGroupRequestDetails: []
                    });
                }
            }
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_group_query_reply = async (req, res) => {
	try {
    if (!req.query.group_query_id) {
        return res.status(400).send({
            status: 400,
            msg: "fail"
        });
    } else {
        db.query(`SELECT * FROM tbl_group_query_reply WHERE group_query_id != ? `, [req.query.group_query_id], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: error
                });
            } else {
                if (results.length > 0) {
                    var final_array1 = [];
                    var cc = 0;
                    Object.keys(results).forEach(function(key, idx, array) {
                        var result_data = results[key];
                        db.query(`SELECT * FROM tbl_user_profile WHERE user_id = ? `, [result_data.group_member_user_id], function(err, rows_user, fields) {
                            if (err) {} else {
                                if (rows_user.length > 0) {
                                    result_data.user_name = rows_user[0].user_name;
                                    result_data.user_profile_img = rows_user[0].user_profile_img;
                                } else {
                                    result_data.user_name = '';
                                    result_data.user_profile_img = '';
                                }
                                final_array1.push(result_data);
                                if (idx === array.length - 1) {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        groupReplyListCount: final_array1.length,
                                        groupReplyList: final_array1
                                    });
                                }


                            }
                        });
                    });
                } else {
                    return res.status(404).send({
                        status: 404,
                        msg: "No Record Found",
                        groupReplyListCount: 0,
                                        groupReplyList: []
                    });
                }
            }
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_group_request_for_user = async (req, res) => {
	try {
    if (!req.query.user_id) {
        return res.status(400).send({
            status: 400,
            msg: "fail"
        });
    } else {
        db.query(`SELECT tr.*,tg.group_name,tg.group_cover_page_image FROM tbl_group_request_member tr inner join tbl_group tg ON tr.group_id=tg.group_id WHERE group_member_user_id = ? and tr.request_status_flag=?`, [req.query.user_id,'1'], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: error
                });
            } else {
                if (results.length > 0) {
                    var final_array1 = [];
                    var cc = 0;
                    Object.keys(results).forEach(function(key, idx, array) {
                        var result_data = results[key];
                     
                                db.query(`SELECT * FROM tbl_user_profile WHERE user_id = ?;SELECT count(*) as total FROM tbl_group_member WHERE group_id = ? AND group_member_status_flag=? and is_deleted=? `, [result_data.group_admin_user_id,result_data.group_id, '1', '0'], function(err, rows_user, fields) {
                                    if (err) {} else {
                                        if (rows_user[0].length > 0) {
                                           result_data.user_id = rows_user[0][0].user_id;
                                           result_data.user_name = rows_user[0][0].user_name;
                                            result_data.user_profile_img = rows_user[0][0].user_profile_img;
                                        } else {
                                            result_data.user_id = '';
                                           result_data.user_name = '';
                                            result_data.user_profile_img = '';
                                        }
                                        result_data.member_count = rows_user[1][0].total;
                                         result_data.group_request_duration = timeAgo(new Date(result_data.created_date).toISOString());
                                        final_array1.push(result_data);
                                        if (idx === array.length - 1) {
                                            return res.status(200).send({
                                                status: 200,
                                                msg: "Success",
                                                groupRequestDetailsCount: final_array1.length,
                                                groupRequestDetails: final_array1
                                            });
                                        }
                                    }
                                });
                    });
                } else {
                    return res.status(404).send({
                        status: 404,
                        msg: "No Record Found",
                             groupRequestDetailsCount: 0,
                                        groupRequestDetails: []
                    });
                }
            }
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_group_random = async (req, res) => {
	try {
    if (!req.query.user_id) {
        return res.status(400).send({
            status: 400,
            msg: "fail"
        });
    } else {
        db.query(`SELECT * FROM tbl_group WHERE group_privacy != ? AND group_status = ? AND group_admin_user_id != ? ORDER BY rand() LIMIT 15`, ['Private', '1', req.query.user_id], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: error
                });
            } else {
                if (results.length > 0) {
                    var final_array1 = [];
                    var cc = 0;
                    Object.keys(results).forEach(function(key, idx, array) {
                        var result_data = results[key];
                        db.query(`SELECT * FROM tbl_user_profile WHERE user_id = ?;
                        Select count(*) as total from tbl_group_member where group_member_status_flag=? and group_id=? and group_member_user_id=? and is_deleted=?;
                        Select count(*)  as total from tbl_group_request_member where  group_id=? and group_member_user_id=?;
                        Select count(*)  as total from tbl_group_ignore where  group_ignore_group_id=? and group_ignore_user_id=?;`, [
                            result_data.group_admin_user_id,
                            '1',result_data.group_id,req.query.user_id,'0',
                            result_data.group_id,req.query.user_id,
                             result_data.group_id,req.query.user_id], function(err, rows_user, fields) {
                            if (err) {} else {
                                if (rows_user[0].length > 0) {
                                    result_data.user_id = rows_user[0][0].user_id;
                                    result_data.user_name = rows_user[0][0].user_name;
                                    result_data.user_profile_img = rows_user[0][0].user_profile_img;
                                } else {
                                    result_data.user_id = '';
                                    result_data.user_name = '';
                                    result_data.user_profile_img = '';
                                }


                                db.query(`SELECT * FROM tbl_group_member WHERE group_id = ? AND group_member_status_flag=? and is_deleted=?`, [result_data.group_id, '1', '0'], function(error, results1, fields) {
                                    if (error) {} else {
                                        result_data.member_count = results1.length;
                                        if(rows_user[1][0].total <= 0 && rows_user[2][0].total <= 0 && rows_user[3][0].total <= 0){
                                        final_array1.push(result_data);
                                        }
                                        if (idx === array.length - 1) {
                                            return res.status(200).send({
                                                status: 200,
                                                msg: "Success",
                                                userGroupRandomListCount: final_array1.length,
                                                userGroupRandomList: final_array1
                                            });
                                        }
                                    }
                                });

                            }
                        });
                    });
                } else {
                    return res.status(404).send({
                        status: 404,
                        msg: "No Record Found",
                              userGroupRandomListCount: 0,
                                        userGroupRandomList: []
                    });
                }
            }
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_group_details = async (req, res) => {
	try {
    if (!req.query.group_id ) {
        return res.status(400).send({
            status: 400,
            msg: "fail"
        });
    } else {
        if(!req.query.user_id)
        req.query.user_id=0;
        db.query(`SELECT * FROM tbl_group WHERE group_id = ? AND group_status=?`, [req.query.group_id, '1'], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: error
                });
            } else {
                if (results.length > 0) {
                    var final_array1 = [];
                    var cc = 0;
                    var result_data = results[0];
                    db.query(`SELECT * FROM tbl_user_profile WHERE user_id = ? `, [result_data.group_admin_user_id], function(err, rows_user, fields) {
                        if (err) {} else {
                            if (rows_user.length > 0) {
                                result_data.user_id = rows_user[0].user_id;
                                result_data.user_name = rows_user[0].user_name;
                                result_data.user_profile_img = rows_user[0].user_profile_img;
                            } else {
                                result_data.user_id = '';
                                result_data.user_name = '';
                                result_data.user_profile_img = '';
                            }

                            db.query(`SELECT * FROM tbl_group_member WHERE group_id = ? AND group_member_status_flag=? and is_deleted=?;SELECT * FROM tbl_group_request_member WHERE group_id = ? AND group_member_user_id=? `, [req.query.group_id, '1', '0',req.query.group_id,req.query.user_id], function(error, results1, fields) {
                                if (error) {} else {
                                    result_data.member_count = results1[0].length;
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        request_status: (results1[1].length>0)?results1[1][0].request_status_flag : '',
                                        groupDetails: result_data
                                    });
                                }
                            });

                        }
                    });

                } else {
                    return res.status(404).send({
                        status: 404,
                        msg: "No Record Found",
                        groupDetails:[]
                    });
                }
            }
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_user_group_details = async (req, res) => {
	try {
    if (!req.query.user_id) {
        return res.status(400).send({
            status: 400,
            msg: "fail"
        });
    } else {
        db.query(`SELECT * FROM tbl_group WHERE group_admin_user_id = ? AND group_status=? union SELECT tg.* from tbl_group tg inner join tbl_group_member tm ON tg.group_id=tm.group_id where tm.group_member_status_flag="1" and tm.is_deleted="0" and tm.group_member_user_id=?`, [req.query.user_id, '1',req.query.user_id], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: error
                });
            } else {
                if (results.length > 0) {
                    var final_array1 = [];
                    var cc = 0;
                    Object.keys(results).forEach(function(key, idx, array) {
                        var result_data = results[key];
                        db.query(`SELECT * FROM tbl_user_profile WHERE user_id = ?;SELECT count(*) as total FROM tbl_group_member WHERE group_id = ? AND group_member_status_flag=? and is_deleted=? `, [result_data.group_admin_user_id,result_data.group_id, '1', '0'], function(err, rows_user, fields) {
                            if (err) {} else {
                                if (rows_user[0].length > 0) {
                                    result_data.user_id = rows_user[0][0].user_id;
                                    result_data.user_name = rows_user[0][0].user_name;
                                    result_data.user_profile_img = rows_user[0][0].user_profile_img;
                                } else {
                                    result_data.user_id = '';
                                    result_data.user_name = '';
                                    result_data.user_profile_img = '';
                                }
                                  result_data.member_count =rows_user[1][0].total+1;
                                final_array1.push(result_data);
                                if (idx === array.length - 1) {
                                  
                                            return res.status(200).send({
                                                status: 200,
                                                msg: "Success",
                                                userGroupDetailsCount: final_array1.length,
                                                userGroupDetails: final_array1
                                            });
                                        }
                                   
                                }
                            
                        });
                    });
                } else {
                    return res.status(404).send({
                        status: 404,
                        msg: "No Record Found",
                           userGroupDetailsCount: 0,
                                                userGroupDetails: []
                    });
                }
            }
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_group_member = async (req, res) => {
	try {
    let upload = multer({
        storage: storage,
    }).single('group_cover_page_image');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        } else {

            if (req.body.group_id && req.body.group_member_user_id) {
                var getd = req.body;
                delete(getd.invite_status_flag);
                if (req.body.invite_status_flag) {
                    $k = req.body.invite_status_flag;
                    delete(req.body.invite_status_flag);
                }
                db.query(`SELECT * from tbl_group_member where group_id = ? AND group_member_user_id = ? and is_deleted=?`, [req.body.group_id, req.body.group_member_user_id, '0'], function(error, results1, fields) {
                    if (error) throw error;
                    if (results1.length <= 0) {
                        db.query(`INSERT INTO tbl_group_member SET ?;SELECT * FROM tbl_group where group_id = ?;UPDATE tbl_group_request_member SET request_status_flag=? where group_id=? and group_member_user_id=?;UPDATE tbl_group_invite_member SET invite_status_flag=? where group_id=? and group_member_user_id=?`, [getd, req.body.group_id, '0', req.body.group_id, req.body.group_member_user_id, '0', req.body.group_id, req.body.group_member_user_id], function(error, results, fields) {
                            if (error) {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail1"
                                });
                            } else {
                                if (results[1].length > 0) {
                                    db.query(`SELECT * FROM tbl_user_profile where user_id = ?`, [results[1][0].group_admin_user_id], function(error, results11, fields) {
                                        if (error) {
                                            return res.status(400).send({
                                                status: 400,
                                                msg: "fail2"
                                            });
                                        } else {
                                            if (results11.length > 0) {
                                                return res.status(200).send({
                                                    status: 200,
                                                    msg: "Success",
                                                    user_register_id: results11[0].user_register_id
                                                });
                                            } else {
                                                return res.status(200).send({
                                                    status: 200,
                                                    msg: "Success",
                                                    user_register_id: ''
                                                });
                                            }
                                        }
                                    });

                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        user_register_id: ''
                                    });
                                }
                            }
                        });
                    } else {
                        return res.status(422).send({
                            status: 422,
                            msg: "Record already exists",
                                 user_register_id: ''
                        });
                    }
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail3",
                         user_register_id: ''
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_group_notice = async (req, res) => {
	try {
    let upload = multer({
        storage: photo,
    }).single('notice_board_image');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        } else {

            if (req.body.notice_board_title) {
                console.log(req.file.filename);
           req.body.notice_board_image=define.BASE_URL+"group/"+req.file.filename;
                        db.query(`INSERT INTO tbl_group_notice_board SET ?;`, [req.body], function(error, results, fields) {
                            if (error) {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail1"
                                });
                            } else {
                               return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        notice_board_id:results.insertId
                                    });
                            }
                        });
                    } else {
                        return res.status(422).send({
                            status: 422,
                            msg: "Record already exists",
                            notice_board_id:0
                        });
                    }

        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_group_query = async (req, res) => {
	try {
    let upload = multer({
        storage: photo,
    }).single('group_query_media');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        } else {

            if (req.body.group_id) {
                console.log(req.file.filename);
           req.body.group_query_media=define.BASE_URL+"group/"+req.file.filename;
                        db.query(`INSERT INTO tbl_group_query SET ?;`, [req.body], function(error, results, fields) {
                            if (error) {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail1"
                                });
                            } else {
                               return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        group_query_id:results.insertId
                                    });
                            }
                        });
                    } else {
                        return res.status(422).send({
                            status: 422,
                            msg: "Record already exists",
                            group_query_id:0
                        });
                    }

        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.edit_group_notice = async (req, res) => {
	try {
    let upload = multer({
        storage: photo,
    }).single('notice_board_image');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        } else {

            if (req.body.notice_board_id) {
                var notice_board_id=req.body.notice_board_id;
                delete(req.body.notice_board_id);
                console.log(notice_board_id);
                if(req.file)
           req.body.notice_board_image=define.BASE_URL+"group/"+req.file.filename;
                        db.query(`UPDATE tbl_group_notice_board SET ? where notice_board_id=?`, [req.body,notice_board_id], function(error, results, fields) {
                            if (error) {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail"
                                });
                            } else {
                               return res.status(200).send({
                                        status: 200,
                                        msg: "Success"
                                    });
                            }
                        });
                    } else {
                        return res.status(422).send({
                            status: 422,
                            msg: "Record already exists"
                        });
                    }

        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_group_members = async (req, res) => {
	try {
    if (!req.query.group_id) {
        return res.status(400).send({
            status: 400,
            msg: "fail"
        });
    } else {
        db.query(`SELECT * FROM tbl_group_member WHERE group_id = ? AND group_member_status_flag=? AND is_deleted=?`, [req.query.group_id, '1', '0'], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: error
                });
            } else {
                if (results.length > 0) {
                    var final_array1 = [];
                    var cc = 0;
                    Object.keys(results).forEach(function(key, idx, array) {
                        var result_data = results[key];
                        db.query(`SELECT * FROM tbl_user_profile WHERE user_id = ? `, [result_data.group_member_user_id], function(err, rows_user, fields) {
                            if (err) {

                            } else {
                                if (rows_user.length > 0) {

                                    result_data.user_id = rows_user[0].user_id;
                                    result_data.user_name = rows_user[0].user_name;
                                    result_data.user_profile_img = rows_user[0].user_profile_img;

                                } else {
                                    result_data.user_id = '';
                                    result_data.user_name = '';
                                    result_data.user_profile_img = '';
                                }
                                final_array1.push(result_data);
                                if (idx === array.length - 1) {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        groupMemberListCount: final_array1.length,
                                        groupMemberList: final_array1
                                    });
                                }
                            }
                        });
                    });
                } else {
                    return res.status(404).send({
                        status: 404,
                        msg: "No Record Found",
                         groupMemberListCount: 0,
                                        groupMemberList: []
                    });
                }
            }
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.exit_group = async (req, res) => {
	try {
    let upload = multer({
        storage: storage,
    }).single('group_cover_page_image');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        } else {
            if (req.body.group_id && req.body.group_member_user_id) {
                db.query(`SELECT *  from tbl_group_member where group_id = ? AND group_member_user_id = ? AND is_deleted = ?`, [req.body.group_id, req.body.group_member_user_id, '0'], function(error, results1, fields) {
                    if (error) throw error;
                    if (results1.length > 0) {
                        db.query(`UPDATE tbl_group_member SET ? where group_id = ? AND group_member_user_id = ?`, [{
                            is_deleted: '1',
                            deleted_by_who: req.body.deleted_by_who
                        }, req.body.group_id, req.body.group_member_user_id], function(error, results, fields) {
                            if (error) {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail"
                                });
                            } else {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Success"
                                });
                            }
                        });
                    } else {
                        return res.status(422).send({
                            status: 422,
                            msg: "Record already exists"
                        });
                    }
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_user_group_request = async (req, res) => {
	try {
    if (!req.query.user_id) {
        return res.status(400).send({
            status: 400,
            msg: "fail"
        });
    } else {
        db.query(`SELECT * FROM tbl_group_request_member WHERE group_member_user_id = ? AND request_status_flag=? `, [req.query.user_id, '1'], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: error
                });
            } else {
                if (results.length > 0) {
                    var final_array1 = [];
                    var cc = 0;
                    Object.keys(results).forEach(function(key, idx, array) {
                        var result_data = results[key];
                        var dm = '';
                        db.query(`SELECT * FROM tbl_group WHERE group_id = ?  `, [result_data.group_id], function(error, group_results, fields) {
                            if (error) {} else {
                                if (group_results.length > 0) {
                                    db.query(`SELECT * FROM tbl_user_profile WHERE user_id = ?;
                                    select count(*) as total from tbl_group_member where group_id=? and group_member_status_flag=? and is_deleted=?`, [
                                        group_results.group_admin_user_id,
                                        result_data.group_id,'1','0'], function(err, rows_user, fields) {
                                        if (err) {

                                        } else {
                                            if (rows_user[0].length > 0) {

                                                group_results[0].user_id = rows_user[0][0].user_id;
                                                group_results[0].user_name = rows_user[0][0].user_name;
                                                group_results[0].user_profile_img = rows_user[0][0].user_profile_img;

                                            } else {
                                                group_results[0].user_id = '';
                                                group_results[0].user_name = '';
                                                group_results[0].user_profile_img = '';
                                            }
                                             group_results[0].member_count=rows_user[1][0].total+1;
                                            group_results[0].group_duration = timeAgo(new Date(result_data.created_date).toISOString());
                                            final_array1.push(group_results[0]);
                                            if (idx === array.length - 1) {
                                                return res.status(200).send({
                                                    status: 200,
                                                    msg: "Success",
                                                    userGroupRequestDetailsCount: final_array1.length,
                                                    userGroupRequestDetails: final_array1
                                                });
                                            }
                                        }
                                    });

                                }
                            }
                        });
                    });
                } else {
                    return res.status(404).send({
                        status: 404,
                        msg: "No Record Found",
                          userGroupRequestDetailsCount: 0,
                                        userGroupRequestDetails: []
                    });
                }
            }
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_user_group_invite = async (req, res) => {
	try {
    if (!req.query.user_id) {
        return res.status(400).send({
            status: 400,
            msg: "fail"
        });
    } else {
        db.query(`SELECT * FROM tbl_group_invite_member WHERE group_member_user_id = ? AND invite_status_flag=? `, [req.query.user_id, '1'], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: error
                });
            } else {
                if (results.length > 0) {
                    var final_array1 = [];
                    var cc = 0;
                    Object.keys(results).forEach(function(key, idx, array) {
                        var result_data = results[key];
                        var dm = '';
                        db.query(`SELECT * FROM tbl_group WHERE group_id = ?  `, [result_data.group_id], function(error, group_results, fields) {
                            if (error) {} else {
                                if (group_results.length > 0) {
                                    db.query(`SELECT * FROM tbl_user_profile WHERE user_id = ?;
                                    select count(*) as total from tbl_group_member where group_id=? and group_member_status_flag=? and is_deleted=?`, [
                                        group_results.group_admin_user_id,
                                        result_data.group_id,'1','0'], function(err, rows_user, fields) {
                                        if (err) {

                                        } else {
                                            if (rows_user[0].length > 0) {

                                                group_results[0].user_id = rows_user[0][0].user_id;
                                                group_results[0].user_name = rows_user[0][0].user_name;
                                                group_results[0].user_profile_img = rows_user[0][0].user_profile_img;

                                            } else {
                                                group_results[0].user_id = '';
                                                group_results[0].user_name = '';
                                                group_results[0].user_profile_img = '';
                                            }
                                             group_results[0].member_count=rows_user[1][0].total+1;
                                            group_results[0].group_duration = timeAgo(new Date(result_data.created_date).toISOString());
                                            final_array1.push(group_results[0]);
                                            if (idx === array.length - 1) {
                                                return res.status(200).send({
                                                    status: 200,
                                                    msg: "Success",
                                                    userGroupInviteDetailsCount: final_array1.length,
                                                    userGroupInviteDetails: final_array1
                                                });
                                            }
                                        }
                                    });

                                }
                            }
                        });
                    });
                } else {
                    return res.status(404).send({
                        status: 404,
                        msg: "No Record Found",
                             userGroupInviteDetailsCount: 0,
                                        userGroupInviteDetails: []
                    });
                }
            }
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_group_notice = async (req, res) => {
	try {
            var pagination = [];

                if (req.query.group_id) {
                   if(req.query.page_no){
                  var no_of_records_per_page = 5;
                  var rowno = req.query.page_no;
                if (rowno != 0)
                {
                    rowno = (rowno - 1) * no_of_records_per_page;
                }
                 var sql=   db.query(`SELECT * From tbl_group_notice_board where group_id=? ORDER BY notice_board_id DESC  LIMIT ? OFFSET ?;SELECT COUNT(*) AS numrows FROM tbl_group_notice_board where group_id=?`,[req.query.group_id,no_of_records_per_page,rowno,req.query.group_id], function(error, results, fields) {
                        if (error) {
                            console.log(sql);
                            return res.status(400).send({
                                status: 400,
                                msg: error
                            });
                        } else {

                            if (results[0].length > 0) {
                                let no_of_records_per_page = 5;
                                let max_pages = parseInt(Math.ceil((results[1][0].numrows) / no_of_records_per_page));
                                if (req.query.page_no && req.query.page_no <= max_pages) {
                                    let page_no = req.query.page_no;

                                    // PAGINATION START

                                    let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
                                   // let sliceData = results[1].slice(offset, offset + no_of_records_per_page)
                                    var pagination = {
                                        total_rows: results[1][0].numrows,
                                        total_pages: parseInt(Math.ceil((results[1][0].numrows) / no_of_records_per_page)),
                                        per_page: no_of_records_per_page,
                                        offset: offset,
                                        current_page_no: page_no
                                    };
                                    // PAGINATION END

                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        groupNoticeCount:results[1][0].numrows,
                                        groupNotice: results[0],
                                        pagination: pagination
                                    });
                                } else {
                                    return res.status(404).send({
                                        status: 404,
                                        msg: "Page no missing or Its incorrect.",
                                           groupNoticeCount:0,
                                        groupNotice: [],
                                      pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }

                                    });
                                }
                            } else {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail",
                                                     groupNoticeCount:0,
                                        groupNotice: [],
                                      pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                                });
                            }
                        }
                    });
                   }else{
                         return res.status(404).send({
                                        status: 404,
                                        msg: "Page no missing or Its incorrect.",
                                                         groupNoticeCount:0,
                                        groupNotice: [],
                                      pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                                    });
                   }
                } else {
                    return res.status(400).send({
                        status: 400,
                        msg: "fail",
                                         groupNoticeCount:0,
                                        groupNotice: [],
                                      pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                    });
                }

	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_group_photo = async (req, res) => {
	try {
            var pagination = [];

                if (req.query.group_id) {
                   if(req.query.page_no){
                  var no_of_records_per_page = 5;
                  var rowno = req.query.page_no;
                if (rowno != 0)
                {
                    rowno = (rowno - 1) * no_of_records_per_page;
                }
                 var sql=   db.query(`SELECT * From tbl_group_photo where group_id=? LIMIT ? OFFSET ?;SELECT COUNT(*) AS numrows FROM tbl_group_photo where group_id=?`,[req.query.group_id,no_of_records_per_page,rowno,req.query.group_id], function(error, results, fields) {
                        if (error) {
                            console.log(sql);
                            return res.status(400).send({
                                status: 400,
                                msg: error
                            });
                        } else {

                            if (results[0].length > 0) {
                                let no_of_records_per_page = 5;
                                let max_pages = parseInt(Math.ceil((results[1][0].numrows) / no_of_records_per_page));
                                if (req.query.page_no && req.query.page_no <= max_pages) {
                                    let page_no = req.query.page_no;

                                    // PAGINATION START

                                    let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
                                   // let sliceData = results[1].slice(offset, offset + no_of_records_per_page)
                                    var pagination = {
                                        total_rows: results[1][0].numrows,
                                        total_pages: parseInt(Math.ceil((results[1][0].numrows) / no_of_records_per_page)),
                                        per_page: no_of_records_per_page,
                                        offset: offset,
                                        current_page_no: page_no
                                    };
                                    // PAGINATION END

                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        groupPhotoCount:results[1][0].numrows,
                                        groupPhoto: results[0],
                                        pagination: pagination
                                    });
                                } else {
                                    return res.status(404).send({
                                        status: 404,
                                        msg: "Page no missing or Its incorrect.",
                                                         groupPhotoCount:0,
                                        groupPhoto: [],
                                      pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                                    });
                                }
                            } else {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail",
                                                                    groupPhotoCount:0,
                                        groupPhoto: [],
                                      pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                                });
                            }
                        }
                    });
                   }else{
                         return res.status(404).send({
                                        status: 404,
                                        msg: "Page no missing or Its incorrect.",
                                                                        groupPhotoCount:0,
                                        groupPhoto: [],
                                      pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                                    });
                   }
                } else {
                    return res.status(400).send({
                        status: 400,
                        msg: "fail",
                                                        groupPhotoCount:0,
                                        groupPhoto: [],
                                      pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                    });
                }

	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_group_image = async (req, res) => {
	try {
            var pagination = [];
                   if(req.query.page_no){
                  var no_of_records_per_page = 10;
                  var rowno = req.query.page_no;
                if (rowno != 0)
                {
                    rowno = (rowno - 1) * no_of_records_per_page;
                }
                 var sql=   db.query(`SELECT group_image_url From tbl_group_image where group_image_status=? LIMIT ? OFFSET ?;SELECT COUNT(*) AS numrows FROM tbl_group_image where group_image_status=?`,['1',no_of_records_per_page,rowno,'1'], function(error, results, fields) {
                        if (error) {
                            console.log(sql);
                            return res.status(400).send({
                                status: 400,
                                msg: error
                            });
                        } else {
                              var final_array1 = [];
                            if (results[0].length > 0) {
                                let max_pages = parseInt(Math.ceil((results[1][0].numrows) / no_of_records_per_page));
                                if (req.query.page_no && req.query.page_no <= max_pages) {
                                    let page_no = req.query.page_no;

                                    // PAGINATION START

                                    let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
                                   // let sliceData = results[1].slice(offset, offset + no_of_records_per_page)
                                    var pagination = {
                                        total_rows: results[1][0].numrows,
                                        total_pages: parseInt(Math.ceil((results[1][0].numrows) / no_of_records_per_page)),
                                        per_page: no_of_records_per_page,
                                        offset: offset,
                                        current_page_no: page_no
                                    };
                                    // PAGINATION END
                                    Object.keys(results[0]).forEach(function(key, idx, array) {
                                    var result_data = results[0][key];
                                     final_array1.push(result_data.group_image_url);
                                            if (idx === array.length - 1) {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        groupImageCount:results[1][0].numrows,
                                        groupImage: final_array1,
                                        pagination: pagination
                                    });
                                            }
                                    });
                                } else {
                                    return res.status(404).send({
                                        status: 404,
                                        msg: "Page no missing or Its incorrect.",
                                                                        groupImageCount:0,
                                        groupImage: [],
                                      pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                                    });
                                }
                            } else {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail",
                                                                                       groupImageCount:0,
                                        groupImage: [],
                                      pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                                });
                            }
                        }
                    });
                   }else{
                         return res.status(404).send({
                                        status: 404,
                                        msg: "Page no missing or Its incorrect.",
                                                                                           groupImageCount:0,
                                        groupImage: [],
                                      pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                                    });
                   }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
