const db = require("../../config/connection");
const merge = require('deepmerge');
exports.get_all_business = async (req, res) => {
	try {
     if (req.query.user_id) {
        if (res.cook.length > 0 || res.contructor.length > 0 || res.tour_travel.length > 0 || res.vehicle_rental.length > 0 || res.health_care.length > 0  || res.medicals.length > 0 || res.doctors.length > 0 || res.self_employee.length > 0 || res.school_college.length > 0 || res.hotel_stay.length > 0 ||  res.restaurants.length > 0 || res.labour.length > 0 || res.play_school.length > 0 || res.rent.length > 0) {
            var final_array = [];
               if (res.medicals.length > 0) {
                final_array = merge(final_array, res.medicals);
            }
              if (res.doctors.length > 0) {
                final_array = merge(final_array, res.doctors);
            }
              if (res.self_employee.length > 0) {
                final_array = merge(final_array, res.self_employee);
            }
             if (res.school_college.length > 0) {
                final_array = merge(final_array, res.school_college);
            }
               if (res.restaurants.length > 0) {
                final_array = merge(final_array, res.restaurants);
            }
            if (res.cook.length > 0) {
                final_array = merge(final_array, res.cook);
               //console.log(res.cook);
            }

            if (res.contructor.length > 0) {
                final_array = merge(final_array, res.contructor);
               //console.log(res.contructor);
            }
             if (res.health_care.length > 0) {
                final_array = merge(final_array, res.health_care);
               //console.log(res.health_care);
            }
              if (res.hotel_stay.length > 0) {
                final_array = merge(final_array, res.hotel_stay);
               //console.log(res.hotel_stay);
            }
              if (res.labour.length > 0) {
                final_array = merge(final_array, res.labour);
               //console.log(res.labour);
            }
              if (res.play_school.length > 0) {
                final_array = merge(final_array, res.play_school);
               //console.log(res.play_school);
            }
             if (res.rent.length > 0) {
                final_array = merge(final_array, res.rent);
               //console.log(res.rent);
            }
              if (res.tour_travel.length > 0) {
                final_array = merge(final_array, res.tour_travel);
                //console.log(res.tour_travel);
            }
             if (res.vehicle_rental.length > 0) {
                final_array = merge(final_array, res.vehicle_rental);
                //console.log(res.tour_travel);
            }
            db.query(`SELECT * FROM tbl_personal_page where user_id=?;SELECT * FROM tbl_user_profile where user_id=?;`, [req.query.user_id, req.query.user_id], function(error, results_rating, fields) {
                if (error) throw error;
   setTimeout(function() {
             
                return res.status(200).send({
                    status: 200,
                    msg: "Success",
                    allBusinessListSellCount: res.common_product.length,
                    allBusinessListSeriveCount: final_array.length,
                    allBusinessListSerive: final_array,
                    userDetails: (results_rating[1].length > 0) ? results_rating[1][0] : {},
                    businessDetails: (results_rating[0].length > 0) ? results_rating[0][0] : {},
                    allBusinessListSell: res.common_product
                });
}, 100);
            });

        } else {
            return res.status(404).send({
                status: 404,
                msg: "Record not found",
                  allBusinessListSellCount: 0,
                    allBusinessListSeriveCount: 0,
                    allBusinessListSerive: [],
                    userDetails:  {},
                    businessDetails: {},
                    allBusinessListSell: []
            });
        }
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
                    allBusinessListSellCount: 0,
                    allBusinessListSeriveCount: 0,
                    allBusinessListSerive: [],
                    userDetails:  {},
                    businessDetails: {},
                    allBusinessListSell: []
        });
    }

	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};