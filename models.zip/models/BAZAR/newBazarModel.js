const db = require("../../config/connection");
const middleware = require("../../middleware/authentication");
const multer = require('fastify-multer');
const crypto = require("crypto");
var bazar = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, '../uploads/bazar/');
    },
    filename: function(req, file, cb) {
        cb(null, "common_product_" + crypto.createHash('md5').update('abcdefgh').digest('hex') + Date.now() + path.extname(file.originalname));
    }
});
exports.add_school_college_facility = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.school_college_facility_name) {
                db.query(`SELECT * FROM tbl_bazar_school_college_facility WHERE school_college_facility_name = ?`, [req.body.school_college_facility_name], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_school_college_facility SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        school_college_facility_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                school_college_facility_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                     school_college_facility_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_school_college_facility = async (req, res) => {
	try {
        db.query(`SELECT * FROM tbl_bazar_school_college_facility `, function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                schoolCollegeList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    schoolCollegeList:[]
                });
            }
        });

	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_school_college_activites = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.school_college_activites_name) {
                db.query(`SELECT * FROM tbl_bazar_school_college_activites WHERE school_college_activites_name = ?`, [req.body.school_college_activites_name], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_school_college_activites SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        school_college_activites_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                school_college_activites_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                      school_college_activites_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_school_college_activites = async (req, res) => {
	try {
        db.query(`SELECT * FROM tbl_bazar_school_college_activites `, function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                schoolCollegeActivitesList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    schoolCollegeActivitesList:[]
                });
            }
        });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_vehicle_rental_type = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.vehicle_rental_type_name) {
                db.query(`SELECT * FROM tbl_bazar_vehicle_rental_type WHERE vehicle_rental_type_name = ?`, [req.body.vehicle_rental_type_name], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_vehicle_rental_type SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        vehicle_rental_type_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                vehicle_rental_type_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                    vehicle_rental_type_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_vehicle_rental_type = async (req, res) => {
	try {
        db.query(`SELECT * FROM tbl_bazar_vehicle_rental_type `, function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                vehicleRentalTypeList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    vehicleRentalTypeList:[]
                });
            }
        });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_play_school_activites = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.play_school_activites_name) {
                db.query(`SELECT * FROM tbl_bazar_play_school_activites WHERE play_school_activites_name = ?`, [req.body.play_school_activites_name], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_play_school_activites SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        play_school_activites_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                play_school_activites_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_play_school_activites = async (req, res) => {
	try {
        db.query(`SELECT * FROM tbl_bazar_play_school_activites `, function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                playSchoolActivitesList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    playSchoolActivitesList:[]
                });
            }
        });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_play_school_facility = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.play_school_facility_name) {
                db.query(`SELECT * FROM tbl_bazar_play_school_facility WHERE play_school_facility_name = ?`, [req.body.play_school_facility_name], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_play_school_facility SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        play_school_facility_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                play_school_facility_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                    play_school_facility_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_play_school_facility = async (req, res) => {
	try {
        db.query(`SELECT * FROM tbl_bazar_play_school_facility `, function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                playSchoolFacilityList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    playSchoolFacilityList:[]
                });
            }
        });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_rent_type = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.rent_type_name) {
                db.query(`SELECT * FROM tbl_bazar_rent_type WHERE rent_type_name = ?`, [req.body.rent_type_name], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_rent_type SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        rent_type_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                rent_type_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                    rent_type_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_rent_type = async (req, res) => {
	try {
        db.query(`SELECT * FROM tbl_bazar_rent_type `, function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                rentTypeList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    rentTypeList:[]
                });
            }
        });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_events_suggestions = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.events_suggestion_name) {
                db.query(`SELECT * FROM tbl_events_suggestions WHERE events_suggestion_name = ?`, [req.body.events_suggestion_name], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_events_suggestions SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        events_suggestion_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                events_suggestion_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                     events_suggestion_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_events_suggestions = async (req, res) => {
	try {
        db.query(`SELECT * FROM tbl_events_suggestions `, function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                eventsSuggestionsList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    eventsSuggestionsList:[]
                });
            }
        });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_rent_amenities = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.rent_amenities_name) {
                db.query(`SELECT * FROM tbl_bazar_rent_amenities WHERE rent_amenities_name = ?`, [req.body.rent_amenities_name], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_rent_amenities SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        rent_amenities_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                rent_amenities_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                     rent_amenities_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_rent_amenities = async (req, res) => {
	try {
        db.query(`SELECT * FROM tbl_bazar_rent_amenities `, function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                rentAmenitiesList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    rentAmenitiesList:[]
                });
            }
        });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_rent_property_bhk = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.rent_property_bhk_name) {
                db.query(`SELECT * FROM tbl_bazar_rent_property_bhk WHERE rent_property_bhk_name = ?`, [req.body.rent_property_bhk_name], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_rent_property_bhk SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        rent_property_bhk_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                rent_property_bhk_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                    rent_property_bhk_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_rent_property_bhk = async (req, res) => {
	try {
        db.query(`SELECT * FROM tbl_bazar_rent_property_bhk `, function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                rentPropertyBhkList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    rentPropertyBhkList:[]
                });
            }
        });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_hotel_stay_features = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.hotel_stay_features_name) {
                db.query(`SELECT * FROM tbl_bazar_hotel_stay_features WHERE hotel_stay_features_name = ?`, [req.body.hotel_stay_features_name], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_hotel_stay_features SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        hotel_stay_features_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                hotel_stay_features_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                     hotel_stay_features_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_hotel_stay_features = async (req, res) => {
	try {
        db.query(`SELECT * FROM tbl_bazar_hotel_stay_features `, function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                hotelStayFeaturesList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    hotelStayFeaturesList:[]
                });
            }
        });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_tour_travel_service = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.tour_travel_service_name) {
                db.query(`SELECT * FROM tbl_bazar_tour_travel_service WHERE tour_travel_service_name = ?`, [req.body.tour_travel_service_name], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_tour_travel_service SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        tour_travel_service_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                tour_travel_service_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                      tour_travel_service_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_tour_travel_service = async (req, res) => {
	try {
        db.query(`SELECT * FROM tbl_bazar_tour_travel_service `, function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                tourTravelServiceList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    tourTravelServiceList:[]
                });
            }
        });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_restaurants_specialist = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.restaurants_specialist_name) {
                db.query(`SELECT * FROM tbl_bazar_restaurants_specialist WHERE restaurants_specialist_name = ?`, [req.body.restaurants_specialist_name], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_restaurants_specialist SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        restaurants_specialist_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                restaurants_specialist_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                     restaurants_specialist_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_rent_number = async (req, res) => {
	try {
        db.query(`SELECT * FROM tbl_bazar_rent_number `, function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                rentNumberList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    rentNumberList:[]
                });
            }
        });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_category = async (req, res) => {
	try {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productCategoryListCount: results.length,
                                productCategoryList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                      productCategoryListCount: 0,
                                productCategoryList: []
                });
            }
      
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_wishlist = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.user_id && req.body.common_product_id) {
                db.query(`SELECT * FROM tbl_bazar_product_buy_sell_wishlist WHERE user_id = ? and common_product_id=?`, [req.body.user_id, req.body.common_product_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_buy_sell_wishlist SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        wishlist_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                wishlist_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_wishlist = async (req, res) => {
	try {
    if (req.query.user_id) {
        var final_array = [];
        db.query(`SELECT * FROM tbl_bazar_product_buy_sell_wishlist where user_id=?`, [req.query.user_id], function(error, results, fields) {
            if (error) throw error;
            else {
                if (results.length > 0) {
                    Object.keys(results).forEach(function(key, idx, array) {
                        var result_data = results[key];
                        db.query(`SELECT * FROM tbl_bazar_product_buy_sell where common_product_id=?`, [result_data.common_product_id], function(error, results_comment1, fields) {
                            if (error) throw error;
                            else {
                                if (results_comment1.length > 0) {
                                    final_array.push(results_comment1);
                                }
                                
                                if (idx === array.length - 1) {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        productWishlistCount: final_array.length,
                                        productWishlist: final_array
                                    });
                                }
                            }
                        });
                    });
                } else {
                    return res.status(400).send({
                        status: 400,
                        msg: "fail",
                           productWishlistCount: 0,
                                        productWishlist: []
                    });
                }
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
             productWishlistCount: 0,
                                        productWishlist: []
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_brand = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_brand_name) {
                db.query(`SELECT * FROM tbl_bazar_product_brand WHERE product_brand_name = ?`, [req.body.product_brand_name], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_brand SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_brand_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_brand_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                     product_brand_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_brand = async (req, res) => {
	try {
    if(req.query.product_category_id){
        db.query(`SELECT * FROM tbl_bazar_product_brand where product_category_id=? `,[req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productBrandList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productBrandList:[]
                });
            }
        });
    }else{
        return res.status(400).send({
                    status: 400,
                    msg: "fail",
                     productBrandList:[]
                });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
