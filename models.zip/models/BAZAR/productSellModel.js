const db = require("../../config/connection");
const multer = require('fastify-multer');
const crypto = require("crypto");
var bazar = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, '../uploads/bazar/');
    },
    filename: function(req, file, cb) {
        cb(null, "common_product_" + crypto.createHash('md5').update('abcdefgh').digest('hex') + Date.now() + path.extname(file.originalname));
    }
});

exports.get_common_product_images = async (req, res) => {
	try {
    if(req.query.common_product_id){
    db.query(`SELECT *  from tbl_bazar_product_buy_sell where common_product_id=?`,[req.query.common_product_id], function(error, results1, fields) {
        if (error) throw error;
        if (results1.length > 0 && results1[0].common_product_images!='') {
            var string = results1[0].common_product_images;
                                var myArray = string.split(",");
            return res.status(200).send({
                status: 200,
                msg: "Success",
                imageListCount: myArray.length,
                imageList: myArray
            });
        } else {

            return res.status(404).send({
                status: 404,
                msg: "Record not found",
                imageListCount:0,
                imageList: []
            });
        }
    });
    }else{
         return res.status(404).send({
                status: 404,
                msg: "Record not found",
                imageListCount:0,
                imageList: []
         });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.common_product_update_images = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).fields([{
        name: 'common_product_images',
        maxCount: 10
    }]);
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        } else {
            if (req.body.common_product_id) {
                var common_product_id = req.body.common_product_id;
                db.query(`SELECT * FROM tbl_bazar_product_buy_sell where common_product_id= ?`, [common_product_id], function(error, results_f, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: "fail"
                        });
                    } else {
                        if (results_f.length > 0) {
                            if (req.body.flag == 1) {
                                var common_product_images = [];
                                delete(req.body.common_product_id);
                                if (typeof req.files.common_product_images !== 'undefined') {
                                    Object.keys(req.files.common_product_images).forEach(function(key, idx1, array1) {
                                        var result_file = req.files.common_product_images[key];
                                        common_product_images.push(define.BASE_URL + "bazar/" + result_file.filename);
                                        if (idx1 === array1.length - 1) {
                                            delete(req.body.urltoremove);
                                             delete(req.body.flag);
                                            if(results_f[0].common_product_images!='')
                                            req.body.common_product_images = results_f[0].common_product_images+","+common_product_images.toString();
                                            else
                                             req.body.common_product_images =common_product_images.toString();
                                            db.query(`UPDATE tbl_bazar_product_buy_sell SET ? where common_product_id= ?`, [req.body, common_product_id], function(error, results, fields) {
                                                if (error) {
                                                    return res.status(400).send({
                                                        status: 400,
                                                        msg: "fail"
                                                    });
                                                } else {
                                                    return res.status(200).send({
                                                        status: 200,
                                                        msg: "Success"
                                                    });
                                                }
                                            });
                                        }
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success"
                                    });
                                }
                            } else {
                                var string = results_f[0].common_product_images;
                                var myArray = string.split(",");
                                if(req.body.urltoremove && req.body.urltoremove!=''){
                                    var newarray=(req.body.urltoremove).split(",");
                                    var filteredArray = myArray.filter(item => !newarray.includes(item));
                                       db.query(`UPDATE tbl_bazar_product_buy_sell SET ? where common_product_id= ?`, [{common_product_images:filteredArray.toString()}, common_product_id], function(error, results, fields) {
                                                if (error) {
                                                    return res.status(400).send({
                                                        status: 400,
                                                        msg: "fail"
                                                    });
                                                } else {
                                                    return res.status(200).send({
                                                        status: 200,
                                                        msg: "Success"
                                                    });
                                                }
                                            });
                                }else{
                                     return res.status(200).send({
                                                        status: 200,
                                                        msg: "Success"
                                                    });
                                }
                            }
                        } else {
                            return res.status(400).send({
                                status: 400,
                                msg: "Record Not found."
                            });
                        }
                    }
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_sell = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).fields([{
        name: 'common_product_images',
        maxCount: 10
    }]);
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.common_product_user_id) {
                var common_product_images = [];
                if (typeof req.files.common_product_images !== 'undefined') {
                    req.body.common_product_business_id = "common_product_" + crypto.createHash('md5').update('ABCDEFGHIJL1234567890').digest('hex');
                    Object.keys(req.files.common_product_images).forEach(function(key, idx1, array1) {
                        var result_file = req.files.common_product_images[key];
                        common_product_images.push(define.BASE_URL+"bazar/"+result_file.filename);
                        if (idx1 === array1.length - 1) {
                            req.body.common_product_images = common_product_images.toString();
                            db.query(`INSERT INTO tbl_bazar_product_buy_sell SET ?`, req.body, function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        common_product_id:results.insertId
                                    });
                                }
                            });
                        }
                    });
                } else {
                    db.query(`INSERT INTO tbl_bazar_product_buy_sell SET ?`, req.body, function(error, results, fields) {
                        if (error) {
                            return res.status(400).send({
                                status: 400,
                                msg: error
                            });
                        } else {
                            return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                common_product_id:0
                            });
                        }
                    });
                }
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    common_product_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.edit_product_sell = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).fields([{
        name: 'common_product_images',
        maxCount: 10
    }]);
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.common_product_id) {
                var common_product_images = [];
                var common_product_id = req.body.common_product_id;
                delete(req.body.common_product_id);
                if (typeof req.files.common_product_images !== 'undefined') {
                    req.body.common_product_business_id = "common_product_" + crypto.createHash('md5').update('ABCDEFGHIJL1234567890').digest('hex');
                    Object.keys(req.files.common_product_images).forEach(function(key, idx1, array1) {
                        var result_file = req.files.common_product_images[key];
                        common_product_images.push(define.BASE_URL+"bazar/"+result_file.filename);
                        if (idx1 === array1.length - 1) {
                            req.body.common_product_images = common_product_images.toString();
                            db.query(`UPDATE tbl_bazar_product_buy_sell SET ? where common_product_id= ?`, [req.body, common_product_id], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success"
                                    });
                                }
                            });
                        }
                    });
                } else {
                    db.query(`UPDATE tbl_bazar_product_buy_sell SET ? where common_product_id= ?`, [req.body, common_product_id], function(error, results, fields) {
                        if (error) {
                            return res.status(400).send({
                                status: 400,
                                msg: error
                            });
                        } else {
                            return res.status(200).send({
                                status: 200,
                                msg: "Success"
                            });
                        }
                    });
                }
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1"
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_rating = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.common_product_rating && req.body.common_product_id) {
                db.query(`INSERT INTO tbl_bazar_product_buy_sell_rating SET ?`, [req.body], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        var rating = 0;
                        var rating_count = 0;
                        db.query(`SELECT * FROM tbl_bazar_product_buy_sell_rating where common_product_id=?;`, [req.body.common_product_id], function(error, results_rating, fields) {
                            if (error) throw error;
                            if (results_rating.length > 0) {
                                var total = 0;
                                Object.keys(results_rating).forEach(function(key1, idx1, array1) {
                                    var result_data_rating = results_rating[key1];
                                    total = parseFloat(total) + parseFloat(result_data_rating.common_product_rating);
                                    if (idx1 === array1.length - 1) {
                                        var rating1 = parseFloat(total) / results_rating.length;
                                        rating = Math.round(rating1 * 100) / 100;
                                    }
                                });
                            }
                            return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                rating: rating,
                                rating_user_count: results_rating.length
                            });
                        });

                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                      rating: 0,
                                rating_user_count: 0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_comment = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.common_product_comments && req.body.common_product_id) {
                db.query(`INSERT INTO tbl_bazar_product_buy_sell_comments SET ?`, [req.body], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success",
                            id: results.insertId
                        });
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_approach = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.common_product_id) {
                db.query(`INSERT INTO tbl_bazar_product_buy_sell_approach SET ?`, [req.body], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success",
                            common_product_approach_id: results.insertId
                        });
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    common_product_approach_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_schedule = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.common_product_id) {
                db.query(`INSERT INTO tbl_bazar_product_buy_sell_schedule SET ?`, [req.body], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success",
                            common_product_schedule_id: results.insertId
                        });
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    common_product_schedule_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_sell_specialist = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.common_product_specialist_name) {
                db.query(`Select * From tbl_bazar_product_buy_sell_specialist where common_product_specialist_name= ?`, [req.body.common_product_specialist_name], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_buy_sell_specialist SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        common_product_specialist_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                common_product_specialist_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    common_product_specialist_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_sell_specialist = async (req, res) => {
	try {
    db.query(`SELECT *  from tbl_bazar_product_buy_sell_specialist`, function(error, results1, fields) {
        if (error) throw error;
        if (results1.length > 0) {
            return res.status(200).send({
                status: 200,
                msg: "Success",
                commonProductSpecialistListCount: results1.length,
                commonProductSpecialistAllList: results1
            });
        } else {

            return res.status(404).send({
                status: 404,
                msg: "Record not found",
                  commonProductSpecialistListCount:0,
                commonProductSpecialistAllList: 0
            });
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_sell_last_comment = async (req, res) => {
	try {
    if (req.query.common_product_id && req.query.common_product_comment_visiter_id) {
        db.query(`SELECT * FROM tbl_bazar_product_buy_sell_comments WHERE common_product_id = ? AND common_product_comment_visiter_id = ? ORDER BY common_product_comment_id DESC LIMIT 1;SELECT * FROM tbl_user_profile  where user_id=?`, [req.query.common_product_id, req.query.common_product_comment_visiter_id, req.query.common_product_comment_visiter_id], function(error, results1, fields) {
            if (error) throw error;
            if (results1[0].length > 0) {
                var arr = results1[0][0];

                if (results1[1].length > 0) {

                    arr.user_name = results1[1][0].user_name;
                    arr.user_profile_img = results1[1][0].user_name;

                } else {
                    arr.user_name = '';
                    arr.user_profile_img = '';
                }
                return res.status(200).send({
                    status: 200,
                    msg: "Success",
                    commonProductLastComment: arr
                });
            } else {

                return res.status(404).send({
                    status: 404,
                    msg: "Record not found",
                    commonProductLastComment:{}
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail1",
             commonProductLastComment:{}
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_sell_search = async (req, res) => {
	try {
    if (req.query.user_id && req.query.distance_range) {
        db.query(`SELECT * FROM tbl_bazar_product_buy_sell ORDER BY common_product_id DESC;SELECT * FROM tbl_user_coordinates where coordinate_user_id=?`, [req.query.user_id], function(error, results, fields) {
            if (error) throw error;
            if (results[0].length > 0) {
                var final_array = [];
                Object.keys(results[0]).forEach(function(key, idx, array) {
                    var result_data = results[0][key];
                    result_data.table_name="product_buy_sell";
                    var di = '0.0 km';
                    var ti = '0 hours 0 mins';
                    var rating = 0;
                    var rating_count = 0;
                    var flag =2;
                    if (results[1].length > 0) {
                        ////console.log(results[1]);
                        var origin = result_data.common_product_latitude + "," + result_data.common_product_longitude;
                        var destination = (results[1][0].coordinates_latitude) + "," + (results[1][0].coordinates_longitude);
                        ////console.log(destination);
                        ////console.log(origin);
                        var request = require('request');
                        var options = {
                            'method': 'GET',
                            'url': 'https://maps.googleapis.com/maps/api/distancematrix/json?units=km&origins=' + origin + '&destinations=' + destination + '&key='+define.GOOGLE_KEY,
                            'headers': {}
                        };
                    }else{
                         var origin = 00;
                         var destination = 00;
                         var request = require('request');
                         var options = {
                            'method': 'GET',
                            'url': 'https://maps.googleapis.com/maps/api/distancematrix/json?units=km&origins=' + origin + '&destinations=' + destination + '&key='+define.GOOGLE_KEY,
                            'headers': {}
                        };
                    }
                        request(options, function(error, response) {
                            if (error) {
                                result_data.distance = di;
                                result_data.time = ti;
                                flag =1;
                            } else {
                                var data_distance = JSON.parse(response.body);
                                if (data_distance.rows[0] && data_distance.rows[0].elements[0].status == "OK") {
                                 //   if (data_distance.rows[0].elements[0].status == "OK") {
                                      //  if ((Math.round(req.query.distance_range * 1000)) >= (Math.round(data_distance.rows[0].elements[0].distance.value))) {
                                            di = data_distance.rows[0].elements[0].distance.text;
                                            ti = data_distance.rows[0].elements[0].duration.text;
                                            result_data.distance = di;
                                            result_data.time = ti;
                                              flag =1;
                                      //  }
                                  //  }
                                }else{
                                     result_data.distance = di;
                                            result_data.time = ti;
                                              flag =1;
                                }
                            }
                            db.query(`SELECT * FROM tbl_bazar_product_buy_sell_rating where common_product_id=?;`, [result_data.common_product_id], function(error, results_rating, fields) {
                                if (error) throw error;
                                if (results_rating.length > 0) {
                                    var total = 0;
                                    Object.keys(results_rating).forEach(function(key1, idx1, array1) {
                                        var result_data_rating = results_rating[key1];
                                        total = parseFloat(total) + parseFloat(result_data_rating.common_product_rating);
                                        if (idx1 === array1.length - 1) {
                                            var rating1 = parseFloat(total) / results_rating.length;
                                            rating = Math.round(rating1 * 100) / 100;
                                        }
                                    });
                                }
                                result_data.distance = di;
                                result_data.time = ti;
                                result_data.rating = rating;
                                result_data.rating_user_count = results_rating.length;
                              //  if(flag ==1)
                                final_array.push(result_data);
                                if (idx === array.length - 1) {
                                     setTimeout(function() {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        commonProductAllListCount: final_array.length,
                                        commonProductAllList: final_array
                                    });
                                     }, 100);
                                }
                            });
                        });
                    // } else {
                    //     if (idx === array.length - 1) {
                    //         return res.status(200).send({
                    //             status: 200,
                    //             msg: "Success",
                    //             ProductSellCountList: final_array
                    //         });
                    //     }
                    // }
                });

            } else {
                return res.status(404).send({
                    status: 404,
                    msg: "Record not found",
                    commonProductAllListCount: 0,
                    commonProductAllList: []
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail1",
            commonProductAllListCount: 0,
            commonProductAllList: []
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_sell_random = async (req, res) => {
	try {
    if (req.query.user_id && req.query.distance_range) {
        db.query(`SELECT * FROM tbl_bazar_product_buy_sell ORDER BY rand() limit 15;SELECT * FROM tbl_user_coordinates where coordinate_user_id=?`, [req.query.user_id], function(error, results, fields) {
            if (error) throw error;
            if (results[0].length > 0) {
                var final_array = [];
                Object.keys(results[0]).forEach(function(key, idx, array) {
                    var result_data = results[0][key];
                    result_data.table_name="product_buy_sell";
                    var di = '0.0 km';
                    var ti = '0 hours 0 mins';
                    var rating = 0;
                    var rating_count = 0;
                    var flag =2;
                    if (results[1].length > 0) {
                        ////console.log(results[1]);
                        var origin = result_data.common_product_latitude + "," + result_data.common_product_longitude;
                        var destination = (results[1][0].coordinates_latitude) + "," + (results[1][0].coordinates_longitude);
                        ////console.log(destination);
                        ////console.log(origin);
                        var request = require('request');
                        var options = {
                            'method': 'GET',
                            'url': 'https://maps.googleapis.com/maps/api/distancematrix/json?units=km&origins=' + origin + '&destinations=' + destination + '&key='+define.GOOGLE_KEY,
                            'headers': {}
                        };
                    }else{
                         var origin = 00;
                         var destination = 00;
                         var request = require('request');
                         var options = {
                            'method': 'GET',
                            'url': 'https://maps.googleaps.com/maps/api/distancematrix/json?units=km&origins=' + origin + '&destinations=' + destination + '&key='+define.GOOGLE_KEY,
                            'headers': {}
                        };
                    }
                        request(options, function(error, response) {
                            if (error) {
                                result_data.distance = di;
                                result_data.time = ti;
                                flag=1;

                            } else {
                                var data_distance = JSON.parse(response.body);
                                if (data_distance.rows[0]) {
                                    if (data_distance.rows[0].elements[0].status == "OK") {
                                        if ((Math.round(req.query.distance_range * 1000)) >= (Math.round(data_distance.rows[0].elements[0].distance.value))) {
                                            di = data_distance.rows[0].elements[0].distance.text;
                                            ti = data_distance.rows[0].elements[0].duration.text;

                                             flag=1;
                                        }
                                    }
                                }
                            }
                            result_data.distance = di;
                            result_data.time = ti;
                            if(flag==1)
                            final_array.push(result_data);
                            if (idx === array.length - 1) {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Success",
                                    commonProductRandomListCount: final_array.length,
                                    commonProductRandomList: final_array
                                });
                            }

                        });
                    // } else {
                    //     if (idx === array.length - 1) {
                    //         return res.status(200).send({
                    //             status: 200,
                    //             msg: "Success",
                    //             ProductSellCountList: final_array
                    //         });
                    //     }
                    // }
                });

            } else {
                return res.status(404).send({
                    status: 404,
                    msg: "Record not found",
                      commonProductRandomListCount: 0,
                                    commonProductRandomList: []
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail1",
              commonProductRandomListCount: 0,
                                    commonProductRandomList: []
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_sell_all = async (req, res) => {
	try {
    var pagination = [];
    if (req.query.user_id && req.query.distance_range && req.query.page_no) {
                  var no_of_records_per_page = 10;
                  var rowno = req.query.page_no;
                if (rowno != 0)
                {
                    rowno = (rowno - 1) * no_of_records_per_page;
                }
        db.query(`SELECT * FROM tbl_bazar_product_buy_sell order by common_product_id desc LIMIT ? OFFSET ?;SELECT * FROM tbl_user_coordinates where coordinate_user_id=?;SELECT COUNT(*) AS numrows FROM tbl_bazar_product_buy_sell`, [no_of_records_per_page,rowno,req.query.user_id], function(error, results, fields) {
            if (error) throw error;
            if (results[0].length > 0) {
                var final_array = [];
               console.log('---------------------------');
                Object.keys(results[0]).forEach(function(key, idx, array) {
                    var result_data = results[0][key];
                    //result_data.table_name="product_buy_sell";
                    var di = '0,0 km';
                    var ti = '0 hours 0 mins';
                    var rating = 0;
                    var rating_count = 0;
                    var flag=2;
                    if (results[1].length > 0) {
                        ////console.log(results[1]);
                        var origin = result_data.common_product_latitude + "," + result_data.common_product_longitude;
                        var destination = (results[1][0].coordinates_latitude) + "," + (results[1][0].coordinates_longitude);
                        ////console.log(destination);
                        ////console.log(origin);
                        var request = require('request');
                        var options = {
                            'method': 'GET',
                            'url': 'https://maps.googleapis.com/maps/api/distancematrix/json?units=km&origins=' + origin + '&destinations=' + destination + '&key='+define.GOOGLE_KEY,
                            'headers': {}
                        };
                    }else{
                         var origin = null;
                         var destination = null;
                         var request = require('request');
                         var options = {
                            'method': 'GET',
                            'url': 'https://maps.googleapis.com/maps/api/distancematrix/json?units=km&origins=' + origin + '&destinations=' + destination + '&key='+define.GOOGLE_KEY,
                            'headers': {}
                        };
                    }
                        request(options, function(error, response) {
                            if (error) {
                              console.log(error);
                                result_data.distance = di;
                                result_data.time = ti;
                                flag =1;
                            } else {
                             //   console.log(response.body);
                                var data_distance = JSON.parse(response.body);
                                if (data_distance.rows[0] && data_distance.rows[0].elements[0].status == "OK") {
                                   // if (data_distance.rows[0].elements[0].status == "OK") {
                                     //   if ((Math.round(req.query.distance_range * 1000)) >= (Math.round(data_distance.rows[0].elements[0].distance.value))) {
                                            di = data_distance.rows[0].elements[0].distance.text;
                                            ti = data_distance.rows[0].elements[0].duration.text;
                                            result_data.distance = di;
                                            result_data.time = ti;
                                            flag=1;

                                      //  }
                                    //}
                                }else{
                                result_data.distance = di;
                                result_data.time = ti;
                                 flag=1;
                                }
                            }
                            db.query(`SELECT * FROM tbl_bazar_product_buy_sell_rating where common_product_id=?;SELECT count(*) as total FROM tbl_bazar_product_buy_sell_wishlist where common_product_id=? and user_id=?`, [result_data.common_product_id,result_data.common_product_id,req.query.user_id], function(error, results_rating, fields) {
                                if (error) throw error;
                                if (results_rating[0].length > 0) {
                                    var total = 0;
                                    Object.keys(results_rating[0]).forEach(function(key1, idx1, array1) {
                                        var result_data_rating = results_rating[0][key1];
                                        total = parseFloat(total) + parseFloat(result_data_rating.common_product_rating);
                                        if (idx1 === array1.length - 1) {
                                            var rating1 = parseFloat(total) / results_rating[0].length;
                                            rating = Math.round(rating1 * 100) / 100;
                                        }
                                    });
                                }
                                 result_data.wishlist_flag = results_rating[1][0].total > 0 ? "1" : "0";
                                result_data.rating = rating;
                             //  result_data.rating_user_count = results_rating[0].length;
                                result_data.common_product_id=result_data.common_product_id.toString();
                                result_data.like_count=result_data.like_count.toString();
                                result_data.follower_count=result_data.follower_count.toString();
                                result_data.view_count=result_data.view_count.toString();
                                result_data.rating=result_data.rating.toString();
                                //result_data.rating_user_count=result_data.rating_user_count.toString();
                                ////console.log(result_data);
                           //    if(flag==1)

                           console.log(result_data.distance);

                                final_array.push(result_data);

                               if (idx === array.length - 1) {
                                      setTimeout(function() {
                                    //let no_of_records_per_page = 5;
                                    if (final_array.length > 0) {
                                        let max_pages = parseInt(Math.ceil((results[2][0].numrows) / no_of_records_per_page));
                                        if (req.query.page_no && req.query.page_no <= max_pages) {
                                            let page_no = req.query.page_no;

                                            // PAGINATION START

                                            let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
                                          //  let sliceData = final_array.slice(offset, offset + no_of_records_per_page)
                                            var pagination = {
                                                total_rows: results[2][0].numrows,
                                                total_pages: parseInt(Math.ceil((results[2][0].numrows) / no_of_records_per_page)),
                                                per_page: no_of_records_per_page,
                                                offset: offset,
                                                current_page_no: page_no
                                            };
                                        // PAGINATION END

                                        return res.status(200).send({
                                            status: 200,
                                            msg: "Success",
                                            ProductSellAllListCount: results[2][0].numrows,
                                            ProductSellAllList: final_array,
                                            pagination: pagination
                                        });
                                    } else {
                                        return res.status(404).send({
                                            status: 404,
                                            msg: "Page no missing or Its incorrect.",
                                                ProductSellAllListCount: 0,
                                            ProductSellAllList: [],
                                             pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }

                                        });
                                    }
                                    }else{
                                        return res.status(404).send({
                                            status: 404,
                                            msg: "No matching records found.",
                                                               ProductSellAllListCount: 0,
                                            ProductSellAllList: [],
                                             pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                                        });
                                    }
                                      }, 900);
                                }

                            });
                        });
                    // } else {
                    //     if (idx === array.length - 1) {
                    //         return res.status(200).send({
                    //             status: 200,
                    //             msg: "Success",
                    //             ProductSellCountList: final_array
                    //         });
                    //     }
                    // }
                });

            } else {
                return res.status(404).send({
                    status: 404,
                    msg: "Record not found",
                                       ProductSellAllListCount: 0,
                                            ProductSellAllList: [],
                                             pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail1",
                               ProductSellAllListCount: 0,
                                            ProductSellAllList: [],
                                             pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
        });
    }

	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_sell_click = async (req, res) => {
	try {
    if (req.query.common_product_id) {
        db.query(`SELECT * FROM tbl_bazar_product_buy_sell where common_product_id= ? ; SELECT * FROM tbl_bazar_product_buy_sell where common_product_id != ? LIMIT 30`, [req.query.common_product_id, req.query.common_product_id], function(error, results, fields) {
            if (error) throw error;
            if (results[0].length > 0) {
                var final_array = [];
                var final_array_one = [];
                var comment = [];
                var rating = 0;
                var rating_count = 0;
                var flag = 2;
                if (results[1].length > 0) {
                    const merged = results[0].concat(results[1]);
                    ////console.log(merged);
                    var di = '0.0 km';
                    var ti = '0 hours 0 mins';
                    Object.keys(merged).forEach(function(key, idx, array) {
                        var result_data = merged[key];
                        //result_data.table_name="product_buy_sell";
                      db.query(`SELECT * FROM tbl_bazar_product_buy_sell_rating where common_product_id=?;SELECT count(*) as total FROM tbl_bazar_product_buy_sell_wishlist where common_product_id=? and user_id=?`, [result_data.common_product_id,result_data.common_product_id,req.query.user_id], function(error, results_rating, fields) {
                                if (error) throw error;
                            if (results_rating[0].length > 0) {
                                var total = 0;
                                Object.keys(results_rating[0]).forEach(function(key1, idx1, array1) {
                                    var result_data_rating = results_rating[0][key1];
                                    total = parseFloat(total) + parseFloat(result_data_rating.common_product_rating);
                                    if (idx1 === array1.length - 1) {
                                        var rating1 = parseFloat(total) / results_rating[0].length;
                                        rating = Math.round(rating1 * 100) / 100;
                                    }
                                });
                            }
                            result_data.wishlist_flag = results_rating[1][0].total > 0 ? "1" : "0";
                              result_data.distance = di;
                                result_data.time = ti;
                            result_data.rating = rating;
                            result_data.rating_user_count = results_rating.length;
                            if (result_data.common_product_id == req.query.common_product_id)
                                final_array.push(result_data);
                            else
                                final_array_one.push(result_data);
                            if (idx === array.length - 1) {
                                db.query(`SELECT * FROM tbl_bazar_product_buy_sell_comments where common_product_id=?;`, [req.query.common_product_id], function(error, results_comment, fields) {
                                    if (error) throw error;
                                                 if(results_comment[0]==''){
                                        results_comment[0][0]={
                                            common_product_comment_visiter_id:''
                                        }
                                    }
                                    if (results_comment.length > 0) {
                                        Object.keys(results_comment).forEach(function(key12, idx12, array12) {
                                            var results_comment_data = results_comment[key12];
                                            db.query(`SELECT * FROM tbl_user_profile where user_id=?;`, [results_comment_data.common_product_comment_visiter_id], function(error, results_comment, fields) {
                                                if (error) throw error;
                                                if (results_comment.length > 0) {
                                                    results_comment_data.user_name = results_comment[0].user_name;
                                                    results_comment_data.user_profile_img = results_comment[0].user_profile_img;
                                                } else {
                                                    results_comment_data.user_name = '';
                                                    results_comment_data.user_profile_img = '';
                                                }
                                                  if(results_comment_data.common_product_comment_visiter_id!='')
                                                comment.push(results_comment_data);
                                                if (idx12 === array12.length - 1) {
                                                     setTimeout(function() {
                                                   return res.status(200).send({
                                                        status: 200,
                                                        msg: "Success",
                                                        ProductSellClickListCount: final_array_one.length,
                                                        ProductSellClickDetails:(final_array[0]!='') ? final_array[0] : {},
                                                        comment: comment,
                                                        ProductSellClickList: final_array_one
                                                    });
                                                     }, 900);
                                                  
                                                }
                                            });
                                        });
                                    } else {
                                        return res.status(200).send({
                                            status: 200,
                                            msg: "Success",
                                            ProductSellClickListCount: final_array_one.length,
                                            ProductSellClickDetails: (final_array[0]!='') ? final_array[0] : {},
                                            comment: comment,
                                            ProductSellClickList: final_array_one
                                        });
                                    }
                                });

                            }

                        });
                    });
                } else {
                    if (idx === array.length - 1) {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success",
                            ProductSellClickListCount: 0,
                                            ProductSellClickDetails: {},
                                            comment: {},
                                            ProductSellClickList: []
                        });
                    }
                }


            } else {
                return res.status(404).send({
                    status: 404,
                    msg: "Record not found",
                       ProductSellClickListCount: 0,
                                            ProductSellClickDetails: {},
                                            comment: {},
                                            ProductSellClickList: []
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
               ProductSellClickListCount: 0,
                                            ProductSellClickDetails: {},
                                            comment: {},
                                            ProductSellClickList: []
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.product_sell_follow = async (req, res) => {
	try {
    if (req.query.follower_user_id && req.query.common_product_id) {
        db.query(`select * From tbl_bazar_product_buy_sell_followers where follower_user_id= ?; select * From tbl_bazar_product_buy_sell where common_product_id= ?`, [req.query.follower_user_id, req.query.common_product_id], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            } else {
                if (results[0].length <= 0) {
                    if (results[1].length > 0) {
                        var count = results[1][0].follower_count + 1;
                        var d = {
                            follower_count: count
                        };
                        db.query(`UPDATE tbl_bazar_product_buy_sell SET ? where common_product_id= ?`, [d, req.query.common_product_id], function(error, results_update, fields) {
                            if (error) {

                            } else {}
                        });
                        req.query.follower_status = 1;
                        db.query(`INSERT INTO tbl_bazar_product_buy_sell_followers SET ?`, req.query, function(error, results, fields) {
                            if (error) {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail"
                                });
                            } else {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Success",
                                    count: count
                                });
                            }
                        });
                    } else {
                        return res.status(400).send({
                            status: 400,
                            msg: 'fail',
                            count:0
                        });
                    }
                } else {
                    if (results[1].length > 0) {
                        var follower_status = 1;
                        var count = 0;
                        if (results[0][0].follower_status == 1) {
                            follower_status = 0;
                        }
                        if (results[1][0].follower_count > 0 && results[0][0].follower_status == 1) {
                            count = results[1][0].follower_count - 1;
                        } else {
                            count = results[1][0].follower_count + 1;
                        }
                        var d = {
                            follower_count: count
                        };
                        db.query(`UPDATE tbl_bazar_product_buy_sell SET ? where common_product_id= ?`, [d, req.query.common_product_id], function(error, results_update, fields) {
                            if (error) {

                            } else {}
                        });
                        db.query(`UPDATE tbl_bazar_product_buy_sell_followers SET ? where follower_user_id = ?`, [{
                            follower_status: follower_status
                        }, req.query.follower_user_id], function(error, results, fields) {
                            if (error) {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail"
                                });
                            } else {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Success",
                                    count: count
                                });
                            }
                        });

                    } else {
                        return res.status(400).send({
                            status: 400,
                            msg: 'fail',
                            count:0
                        });
                    }
                }
            }
        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            count:0
        });
    }

	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.product_sell_like = async (req, res) => {
	try {
    if (req.query.common_product_like_user_id && req.query.common_product_id) {
        db.query(`select * From tbl_bazar_product_buy_sell_like where common_product_like_user_id= ? and common_product_id=?; select * From tbl_bazar_product_buy_sell where common_product_id= ?`, [req.query.common_product_like_user_id, req.query.common_product_id, req.query.common_product_id], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            } else {
                if (req.query.flag == 1) {
                    if (results[0].length <= 0) {
                        if (results[1].length > 0) {
                            var count = results[1][0].like_count + 1;
                            var d = {
                                like_count: count
                            };
                            db.query(`UPDATE tbl_bazar_product_buy_sell SET ? where common_product_id= ?`, [d, req.query.common_product_id], function(error, results_update, fields) {
                                if (error) {

                                } else {}
                            });
                            delete(req.query.flag);
                            db.query(`INSERT INTO tbl_bazar_product_buy_sell_like SET ?`, req.query, function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: "fail"
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        count: count
                                    });
                                }
                            });
                        } else {
                            return res.status(400).send({
                                status: 400,
                                msg: 'fail',
                                count:0
                            });
                        }
                    } else {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success",
                            count: (results[1].length > 0) ? results[1][0].like_count : 0
                        });
                    }
                } else {
                    if (results[1].length > 0) {
                        var count = 0;
                        if (results[1][0].like_count > 0) {
                            count = results[1][0].like_count - 1;
                        }
                        var d = {
                            like_count: count
                        };
                        db.query(`UPDATE tbl_bazar_product_buy_sell SET ? where common_product_id= ?`, [d, req.query.common_product_id], function(error, results_update, fields) {
                            if (error) {

                            } else {}
                        });
                        db.query(`DELETE from tbl_bazar_product_buy_sell_like where common_product_id=? and common_product_like_user_id = ?`, [req.query.common_product_id, req.query.common_product_like_user_id], function(error, results, fields) {
                            if (error) {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail"
                                });
                            } else {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Success",
                                    count: count
                                });
                            }
                        });

                    } else {
                        return res.status(400).send({
                            status: 400,
                            msg: 'fail',
                            count:0
                        });
                    }
                }
            }
        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            count:0
        });
    }

	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.product_sell_view = async (req, res) => {
	try {
    if (req.query.common_product_view_user_id && req.query.common_product_id) {
        db.query(`select * From tbl_bazar_product_buy_sell_view where common_product_view_user_id= ? and common_product_id=?; select * From tbl_bazar_product_buy_sell where common_product_id= ?`, [req.query.common_product_view_user_id, req.query.common_product_id, req.query.common_product_id], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            } else {
                if (results[0].length <= 0) {
                    if (results[1].length > 0) {
                        var count = results[1][0].view_count + 1;
                        var d = {
                            view_count: count
                        };
                        db.query(`UPDATE tbl_bazar_product_buy_sell SET ? where common_product_id= ?`, [d, req.query.common_product_id], function(error, results_update, fields) {
                            if (error) {

                            } else {}
                        });
                        delete(req.query.flag);
                        db.query(`INSERT INTO tbl_bazar_product_buy_sell_view SET ?`, req.query, function(error, results, fields) {
                            if (error) {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail"
                                });
                            } else {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Success",
                                    count: count
                                });
                            }
                        });
                    } else {
                        return res.status(400).send({
                            status: 400,
                            msg: 'fail',
                            count:0
                        });
                    }
                } else {
                    return res.status(200).send({
                        status: 200,
                        msg: "Success",
                        count: (results[1].length > 0) ? results[1][0].view_count : 0
                    });
                }
            }
        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            count:0
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_follow_like = async (req, res) => {
	try {
    if (req.query.user_id && req.query.common_product_id) {
        db.query(`select * From tbl_bazar_product_buy_sell where common_product_id=?;SELECT * FROM tbl_user_coordinates where coordinate_user_id=?`, [req.query.common_product_id, req.query.user_id], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            } else {
                if (results[0].length > 0) {



                    db.query(`select * From tbl_bazar_product_buy_sell_followers where common_product_id= ? and follower_user_id=?`, [req.query.common_product_id, req.query.user_id], function(error, follow, fields) {
                        if (error) {
                            return res.status(400).send({
                                status: 400,
                                msg: "fail"
                            });
                        } else {}
                        db.query(`select * From tbl_bazar_product_buy_sell_like where common_product_id= ? and common_product_like_user_id=?`, [req.query.common_product_id, req.query.user_id], function(error, like, fields) {
                            if (error) {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail"
                                });
                            } else {

                            }
                            results[0][0].follow = follow.length;
                            results[0][0].like = like.length;
                            var result_data = results[0][0];
                            ////console.log(results[0][0]);
                            var di = '0.0 km';
                            var ti = '0 hours 0 mins';
                            var flag = 2;
                            if (results[1].length > 0) {
                                var origin = result_data.common_product_latitude + "," + result_data.common_product_longitude;
                                var destination = (results[1][0].coordinates_latitude) + "," + (results[1][0].coordinates_longitude);
                                ////console.log(destination);
                                ////console.log(origin);
                                var request = require('request');
                                var options = {
                                    'method': 'GET',
                                    'url': 'https://maps.googleapis.com/maps/api/distancematrix/json?units=km&origins=' + origin + '&destinations=' + destination + '&key='+define.GOOGLE_KEY,
                                    'headers': {}
                                };
                            }else{
                         var origin = 00;
                         var destination = 00;
                         var request = require('request');
                         var options = {
                            'method': 'GET',
                            'url': 'https://maps.googleaps.com/maps/api/distancematrix/json?units=km&origins=' + origin + '&destinations=' + destination + '&key='+define.GOOGLE_KEY,
                            'headers': {}
                        };
                    }
                                request(options, function(error, response) {
                                    if (error) {} else {
                                        var data_distance = JSON.parse(response.body);
                                        if (data_distance.rows[0]) {
                                            if (data_distance.rows[0].elements[0].status == "OK") {
                                                // if ((Math.round(req.query.distance_range * 1000)) >= (Math.round(data_distance.rows[0].elements[0].distance.value))) {
                                                di = data_distance.rows[0].elements[0].distance.text;
                                                ti = data_distance.rows[0].elements[0].duration.text;
                                                ////console.log(data_distance.rows[0].elements[0].distance.text);
                                                flag = 1;
                                                //}
                                            }
                                        }
                                    }
                                    results[0][0].distance = di;
                                    results[0][0].time = ti;
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        ProductSellListWithLikeFollow: results[0][0]
                                    });
                                });
                            // } else {
                            //     result_data.distance = di;
                            //     result_data.time = ti;
                            //     return res.status(200).send({
                            //         status: 200,
                            //         msg: "Success1",
                            //         ProductSellListWithLikeFollow: result_data
                            //     });
                            // }
                        });

                    });


                } else {
                    return res.status(400).send({
                        status: 400,
                        msg: 'fail2',
                        ProductSellListWithLikeFollow:{}
                    });
                }
            }

        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
             ProductSellListWithLikeFollow:{}
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_sell_comment = async (req, res) => {
	try {
    if (req.query.common_product_id) {
        var comment = [];
        db.query(`SELECT * FROM tbl_bazar_product_buy_sell_comments where common_product_id=?;`, [req.query.common_product_id], function(error, results_comment, fields) {
            if (error) throw error;
            if (results_comment.length > 0) {
                Object.keys(results_comment).forEach(function(key12, idx12, array12) {
                    var results_comment_data = results_comment[key12];
                    db.query(`SELECT * FROM tbl_user_profile where user_id=?;`, [results_comment_data.common_product_comment_visiter_id], function(error, results_comment, fields) {
                        if (error) throw error;
                        if (results_comment.length > 0) {
                            results_comment_data.user_name = results_comment[0].user_name;
                            results_comment_data.user_profile_img = results_comment[0].user_profile_img;
                        } else {
                            results_comment_data.user_name = '';
                            results_comment_data.user_profile_img = '';
                        }
                        comment.push(results_comment_data);
                        if (idx12 === array12.length - 1) {
                            return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                ProductSellCommentsListCount: comment.length,
                                ProductSellCommentsList: comment
                            });
                        }
                    });
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                     ProductSellCommentsListCount: 0,
                                ProductSellCommentsList: {}
                });
            }
        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
              ProductSellCommentsListCount: 0,
                                ProductSellCommentsList: {}
        });
    }

	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_fabric_type = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_fabric_type_name) {
                db.query(`SELECT * FROM tbl_bazar_product_fabric_type WHERE product_fabric_type_name = ? AND product_category_id = ?`, [req.body.product_fabric_type_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_fabric_type SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_fabric_type_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_fabric_type_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    product_fabric_type_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_fabric_type = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_fabric_type where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productFabricTypeList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productFabricTypeList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
             productFabricTypeList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_size = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_size_name) {
                db.query(`SELECT * FROM tbl_bazar_product_size WHERE product_size_name = ? AND product_category_id = ?`, [req.body.product_size_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_size SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_size_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_size_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    product_size_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_size = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_size where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productSizeList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productSizeList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            productSizeList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_sole = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_sole_name) {
                db.query(`SELECT * FROM tbl_bazar_product_sole WHERE product_sole_name = ? AND product_category_id = ?`, [req.body.product_sole_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_sole SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_sole_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_sole_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    product_sole_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_sole = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_sole where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productSoleList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productSoleList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            productSoleList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_type = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_type_name) {
                db.query(`SELECT * FROM tbl_bazar_product_type WHERE product_type_name = ? AND product_category_id = ?`, [req.body.product_type_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_type SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_type_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_type_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                     product_type_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_type = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_type where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productTypeList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productTypeList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            productTypeList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_closure = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_closure_name) {
                db.query(`SELECT * FROM tbl_bazar_product_closure WHERE product_closure_name = ? AND product_category_id = ?`, [req.body.product_closure_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_closure SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_closure_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_closure_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    product_closure_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_closure = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_closure where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productClosureList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productClosureList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
             productClosureList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_lifestyle = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_lifestyle_name) {
                db.query(`SELECT * FROM tbl_bazar_product_lifestyle WHERE product_lifestyle_name = ? AND product_category_id = ?`, [req.body.product_lifestyle_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_lifestyle SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_lifestyle_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_lifestyle_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    product_lifestyle_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_lifestyle = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_lifestyle where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productLifeStyleList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productLifeStyleList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            productLifeStyleList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_model_no = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_model_no_name) {
                db.query(`SELECT * FROM tbl_bazar_product_model_no WHERE product_model_no_name = ? AND product_category_id = ?`, [req.body.product_model_no_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_model_no SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_model_no_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_model_no_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                      product_model_no_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_model_no = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_model_no where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productModelNoList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productModelNoList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            productModelNoList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_movement_type = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_movement_type_name) {
                db.query(`SELECT * FROM tbl_bazar_product_movement_type WHERE product_movement_type_name = ? AND product_category_id = ?`, [req.body.product_movement_type_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_movement_type SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_movement_type_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_movement_type_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    product_movement_type_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_movement_type = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_movement_type where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productMovementTypeList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productMovementTypeList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            productMovementTypeList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_storage = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_storage_name) {
                db.query(`SELECT * FROM tbl_bazar_product_storage WHERE product_storage_name = ? AND product_category_id = ?`, [req.body.product_storage_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_storage SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_storage_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_storage_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                     product_storage_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_storage = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_storage where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productStorageList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productStorageList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
             productStorageList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_processor = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_processor_name) {
                db.query(`SELECT * FROM tbl_bazar_product_processor WHERE product_processor_name = ? AND product_category_id = ?`, [req.body.product_processor_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_processor SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_processor_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_processor_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                      product_processor_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_processor = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_processor where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productProcessorList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productProcessorList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            productProcessorList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_connector_type = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_connector_type_name) {
                db.query(`SELECT * FROM tbl_bazar_product_connector_type WHERE product_connector_type_name = ? AND product_category_id = ?`, [req.body.product_connector_type_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_connector_type SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_connector_type_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_connector_type_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    product_connector_type_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_connector_type = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_connector_type where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productConnectorTypeList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productConnectorTypeList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            productConnectorTypeList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_cable = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_cable_name) {
                db.query(`SELECT * FROM tbl_bazar_product_cable WHERE product_cable_name = ? AND product_category_id = ?`, [req.body.product_cable_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_cable SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_cable_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_cable_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    product_cable_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_cable = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_cable where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productCableList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productCableList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            productCableList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_components = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_components_name) {
                db.query(`SELECT * FROM tbl_bazar_product_components WHERE product_components_name = ? AND product_category_id = ?`, [req.body.product_components_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_components SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_components_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_components_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                     product_components_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_components = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_components where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productComponentsList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productComponentsList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
             productComponentsList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_plug_type = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_plug_type_name) {
                db.query(`SELECT * FROM tbl_bazar_product_plug_type WHERE product_plug_type_name = ? AND product_category_id = ?`, [req.body.product_plug_type_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_plug_type SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_plug_type_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_plug_type_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                     product_plug_type_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_plug_type = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_plug_type where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productPlugTypeList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productPlugTypeList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            productPlugTypeList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_container_type = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_container_type_name) {
                db.query(`SELECT * FROM tbl_bazar_product_container_type WHERE product_container_type_name = ? AND product_category_id = ?`, [req.body.product_container_type_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_container_type SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_container_type_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_container_type_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                     product_container_type_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_container_type = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_container_type where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productContainerTypeList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productContainerTypeList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            productContainerTypeList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_country = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_country_name) {
                db.query(`SELECT * FROM tbl_bazar_product_country WHERE product_country_name = ? AND product_category_id = ?`, [req.body.product_country_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_country SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_country_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_country_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                     product_country_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_country = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_country where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productCountryList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productCountryList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            productCountryList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_ingredient = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_ingredient_name) {
                db.query(`SELECT * FROM tbl_bazar_product_ingredient WHERE product_ingredient_name = ? AND product_category_id = ?`, [req.body.product_ingredient_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_ingredient SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_ingredient_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_ingredient_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    product_ingredient_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_ingredient = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_ingredient where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productIngredientList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productIngredientList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            productIngredientList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_flavor = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_flavor_name) {
                db.query(`SELECT * FROM tbl_bazar_product_flavor WHERE product_flavor_name = ? AND product_category_id = ?`, [req.body.product_flavor_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_flavor SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_flavor_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_flavor_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                     product_flavor_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_flavor = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_flavor where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productFlavorList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productFlavorList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
             productFlavorList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_form = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_form_name) {
                db.query(`SELECT * FROM tbl_bazar_product_form WHERE product_form_name = ? AND product_category_id = ?`, [req.body.product_form_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_form SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_form_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_form_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    product_form_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_form = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_form where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productFormList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productFormList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
             productFormList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_sent = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_sent_name) {
                db.query(`SELECT * FROM tbl_bazar_product_sent WHERE product_sent_name = ? AND product_category_id = ?`, [req.body.product_sent_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_sent SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_sent_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_sent_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                     product_sent_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_sent = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_sent where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productSentList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productSentList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
             productSentList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_fuel_type = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_fuel_type_name) {
                db.query(`SELECT * FROM tbl_bazar_product_fuel_type WHERE product_fuel_type_name = ? AND product_category_id = ?`, [req.body.product_fuel_type_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_fuel_type SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_fuel_type_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_fuel_type_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                     product_fuel_type_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_fuel_type = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_fuel_type where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productFuelTypeList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productFuelTypeList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
              productFuelTypeList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_gear_type = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_gear_type_name) {
                db.query(`SELECT * FROM tbl_bazar_product_gear_type WHERE product_gear_type_name = ? AND product_category_id = ?`, [req.body.product_gear_type_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_gear_type SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_gear_type_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_gear_type_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    product_gear_type_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_gear_type = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_gear_type where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productGearTypeList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productGearTypeList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            productGearTypeList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_owner_type = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_owner_type_name) {
                db.query(`SELECT * FROM tbl_bazar_product_owner_type WHERE product_owner_type_name = ? AND product_category_id = ?`, [req.body.product_owner_type_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_owner_type SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_owner_type_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_owner_type_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    product_owner_type_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_owner_type = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_owner_type where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productOwnerTypeList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productOwnerTypeList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            productOwnerTypeList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_seller_type = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_seller_type_name) {
                db.query(`SELECT * FROM tbl_bazar_product_seller_type WHERE product_seller_type_name = ? AND product_category_id = ?`, [req.body.product_seller_type_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_seller_type SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_seller_type_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_seller_type_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    product_seller_type_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_seller_type = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_seller_type where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productSellerTypeList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productSellerTypeList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            productSellerTypeList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_shelf_type = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_shelf_type_name) {
                db.query(`SELECT * FROM tbl_bazar_product_shelf_type WHERE product_shelf_type_name = ? AND product_category_id = ?`, [req.body.product_shelf_type_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_shelf_type SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_shelf_type_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_shelf_type_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    product_shelf_type_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_shelf_type = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_shelf_type where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productShelfTypeList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productShelfTypeList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            productShelfTypeList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_handle_type = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_handle_type_name) {
                db.query(`SELECT * FROM tbl_bazar_product_handle_type WHERE product_handle_type_name = ? AND product_category_id = ?`, [req.body.product_handle_type_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_handle_type SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_handle_type_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_handle_type_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    product_handle_type_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_handle_type = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_handle_type where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productHandleTypeList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productHandleTypeList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            productHandleTypeList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_material_type = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_material_type_name) {
                db.query(`SELECT * FROM tbl_bazar_product_material_type WHERE product_material_type_name = ? AND product_category_id = ?`, [req.body.product_material_type_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_material_type SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_material_type_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_material_type_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    product_material_type_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_material_type = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_material_type where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productMaterialTypeList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productMaterialTypeList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            productMaterialTypeList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_finish_type = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_finish_type_name) {
                db.query(`SELECT * FROM tbl_bazar_product_finish_type WHERE product_finish_type_name = ? AND product_category_id = ?`, [req.body.product_finish_type_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_finish_type SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_finish_type_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_finish_type_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    product_finish_type_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_finish_type = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_finish_type where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productFinishTypeList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productFinishTypeList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            productFinishTypeList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_installation_type = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_installation_type_name) {
                db.query(`SELECT * FROM tbl_bazar_product_installation_type WHERE product_installation_type_name = ? AND product_category_id = ?`, [req.body.product_installation_type_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_installation_type SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_installation_type_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_installation_type_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    product_installation_type_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_installation_type = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_installation_type where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productInstallationTypeList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productInstallationTypeList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            productInstallationTypeList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_handle_location = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_handle_location_name) {
                db.query(`SELECT * FROM tbl_bazar_product_handle_location WHERE product_handle_location_name = ? AND product_category_id = ?`, [req.body.product_handle_location_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_handle_location SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_handle_location_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_handle_location_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    product_handle_location_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_handle_location = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_handle_location where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productHandleLocationList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productHandleLocationList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            productHandleLocationList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_shape_type = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_shape_type_name) {
                db.query(`SELECT * FROM tbl_bazar_product_shape_type WHERE product_shape_type_name = ? AND product_category_id = ?`, [req.body.product_shape_type_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_shape_type SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_shape_type_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_shape_type_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    product_shape_type_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_shape_type = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_shape_type where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productShapeTypeList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productShapeTypeList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            productShapeTypeList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_usage_type = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_usage_type_name) {
                db.query(`SELECT * FROM tbl_bazar_product_usage_type WHERE product_usage_type_name = ? AND product_category_id = ?`, [req.body.product_usage_type_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_usage_type SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_usage_type_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_usage_type_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    product_usage_type_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_usage_type = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_usage_type where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productUsageTypeList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productUsageTypeList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            productUsageTypeList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_color = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_color_name) {
                db.query(`SELECT * FROM tbl_bazar_product_color WHERE product_color_name = ? AND product_color_code = ?`, [req.body.product_color_name,req.body.product_color_code], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_color SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_color_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_color_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    product_color_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_color = async (req, res) => {
	try {
    // if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_color;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productColorList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productColorList:[]
                });
            }
        });
    // } else {
    //     return res.status(400).send({
    //         status: 400,
    //         msg: "fail"
    //     });
    // }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_mounted_type = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_mounted_type_name) {
                db.query(`SELECT * FROM tbl_bazar_product_mounted_type WHERE product_mounted_type_name = ? AND product_category_id = ?`, [req.body.product_mounted_type_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_mounted_type SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_mounted_type_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_mounted_type_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    product_mounted_type_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_mounted_type = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_mounted_type where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productMountedTypeList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productMountedTypeList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            productMountedTypeList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_furniture_style = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_furniture_style_name) {
                db.query(`SELECT * FROM tbl_bazar_product_furniture_style WHERE product_furniture_style_name = ? AND product_category_id = ?`, [req.body.product_furniture_style_name,req.body.product_category_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_furniture_style SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_furniture_style_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_furniture_style_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    product_furniture_style_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_furniture_style = async (req, res) => {
	try {
    if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_furniture_style where product_category_id=?;`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productFurnitureStyleList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productFurnitureStyleList:[]
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            productFurnitureStyleList:[]
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_country_code = async (req, res) => {
	try {
   // if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_country_code`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productCountryCodeList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productCountryCodeList:[]
                });
            }
        });
    // } else {
    //     return res.status(400).send({
    //         status: 400,
    //         msg: "fail"
    //     });
    // }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_dimension = async (req, res) => {
	try {
  //  if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_dimension`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productDimensionList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productDimensionList:[]
                });
            }
        });
    // } else {
    //     return res.status(400).send({
    //         status: 400,
    //         msg: "fail"
    //     });
    // }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_weight_type = async (req, res) => {
	try {
   // if (req.query.product_category_id) {
        db.query(`SELECT * FROM tbl_bazar_product_weight_type`, [req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productWeightTypeList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productWeightTypeList:[]
                });
            }
        });
    // } else {
    //     return res.status(400).send({
    //         status: 400,
    //         msg: "fail"
    //     });
    // }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_category = async (req, res) => {
	try {
        db.query(`SELECT * FROM tbl_bazar_product_category `, function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productCategoryListCount: results.length,
                                productCategoryList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productCategoryListCount: 0,
                    productCategoryList: []
                });
            }
        });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_product_wishlist = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.user_id && req.body.common_product_id) {
                db.query(`SELECT * FROM tbl_bazar_product_buy_sell_wishlist WHERE user_id = ? and common_product_id=?`, [req.body.user_id, req.body.common_product_id], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_buy_sell_wishlist SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        wishlist_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                wishlist_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                    wishlist_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.delete_product_wishlist = async (req, res) => {
	try {
    if (req.query.user_id && req.query.common_product_id) {
        db.query(`DELETE from tbl_bazar_product_buy_sell_wishlist where user_id=? AND common_product_id=?`, [req.query.user_id,req.query.common_product_id], function(error, results1, fields) {
            if (error) throw error;
            return res.status(200).send({
                status: 200,
                msg: "Success"
            });
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail"
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_product_wishlist = async (req, res) => {
	try {
    if (req.query.user_id) {
        var final_array = [];
        db.query(`SELECT * FROM tbl_bazar_product_buy_sell_wishlist where user_id=?`, [req.query.user_id], function(error, results, fields) {
            if (error) throw error;
            else {
                if (results.length > 0) {
                    Object.keys(results).forEach(function(key, idx, array) {
                        var result_data = results[key];
                        db.query(`SELECT * FROM tbl_bazar_product_buy_sell where common_product_id=?`, [result_data.common_product_id], function(error, results_comment1, fields) {
                            if (error) throw error;
                            else {
                                if (results_comment1.length > 0) {
                                    final_array.push(results_comment1[0]);
                                }

                                if (idx === array.length - 1) {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        productWishlistCount: final_array.length,
                                        productWishlist: final_array
                                    });
                                }
                            }
                        });
                    });
                } else {
                    return res.status(400).send({
                        status: 400,
                        msg: "fail",
                        productWishlistCount: 0,
                        productWishlist: []
                    });
                }
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            productWishlistCount: 0,
            productWishlist: []
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_brand = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.product_brand_name) {
                db.query(`SELECT * FROM tbl_bazar_product_brand WHERE product_brand_name = ?`, [req.body.product_brand_name], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_product_brand SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        product_brand_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists",
                                product_brand_id:0
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                    product_brand_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_brand = async (req, res) => {
	try {
    if(req.query.product_category_id){
        db.query(`SELECT * FROM tbl_bazar_product_brand where product_category_id=? `,[req.query.product_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results.length > 0) {
                       return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                productBrandList: results
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "No record found.",
                    productBrandList:[]
                });
            }
        });
    }else{
        return res.status(400).send({
                    status: 400,
                    msg: "fail",
                    productBrandList:[]
                });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
