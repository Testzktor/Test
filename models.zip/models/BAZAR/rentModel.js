
const db = require("../../config/connection");
const multer = require('fastify-multer');
const crypto = require("crypto");
var path = require('path')
var bazar = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, '../uploads/bazar/');
    },
    filename: function(req, file, cb) {
        cb(null, "rent_" + crypto.createHash('md5').update('abcdefgh').digest('hex') + Date.now() + path.extname(file.originalname));
    }
});
exports.get_rent_images = async (req, res) => {
	try {
    if(req.query.rent_id){
    db.query(`SELECT *  from tbl_bazar_rent where rent_id=?`,[req.query.rent_id], function(error, results1, fields) {
        if (error) throw error;
        if (results1.length > 0 && results1[0].rent_properties_images!='') {
            var string = results1[0].rent_properties_images;
                                var myArray = string.split(",");
            return res.status(200).send({
                status: 200,
                msg: "Success",
                imageListCount: myArray.length,
                imageList: myArray
            });
        } else {

            return res.status(404).send({
                status: 404,
                msg: "Record not found",
                imageListCount:0,
                imageList: []
            });
        }
    });
    }else{
         return res.status(404).send({
                status: 404,
                msg: "Record not found",
                imageListCount:0,
                imageList: []
         });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.rent_update_images = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).fields([{
        name: 'rent_properties_images',
        maxCount: 10
    }]);
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        } else {
            if (req.body.rent_id) {
                var rent_id = req.body.rent_id;
                db.query(`SELECT * FROM tbl_bazar_rent where rent_id= ?`, [rent_id], function(error, results_f, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: "fail"
                        });
                    } else {
                        if (results_f.length > 0) {
                            if (req.body.flag == 1) {
                                var rent_properties_images = [];
                                delete(req.body.rent_id);
                                if (typeof req.files.rent_properties_images !== 'undefined') {
                               //     req.body.rent_business_id = "rent_" + crypto.createHash('md5').update('ABCDEFGHIJL1234567890').digest('hex');
                                    Object.keys(req.files.rent_properties_images).forEach(function(key, idx1, array1) {
                                        var result_file = req.files.rent_properties_images[key];
                                        rent_properties_images.push(define.BASE_URL + "bazar/" + result_file.filename);
                                        if (idx1 === array1.length - 1) {
                                            delete(req.body.urltoremove);
                                             delete(req.body.flag);
                                            if(results_f[0].rent_properties_images!='')
                                            req.body.rent_properties_images = results_f[0].rent_properties_images+","+rent_properties_images.toString();
                                            else
                                             req.body.rent_properties_images =rent_properties_images.toString();
                                            db.query(`UPDATE tbl_bazar_rent SET ? where rent_id= ?`, [req.body, rent_id], function(error, results, fields) {
                                                if (error) {
                                                    return res.status(400).send({
                                                        status: 400,
                                                        msg: "fail"
                                                    });
                                                } else {
                                                    return res.status(200).send({
                                                        status: 200,
                                                        msg: "Success"
                                                    });
                                                }
                                            });
                                        }
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success"
                                    });
                                }
                            } else {
                                var string = results_f[0].rent_properties_images;
                                var myArray = string.split(",");
                                if(req.body.urltoremove && req.body.urltoremove!=''){
                                    var newarray=(req.body.urltoremove).split(",");
                                    var filteredArray = myArray.filter(item => !newarray.includes(item));
                                       db.query(`UPDATE tbl_bazar_rent SET ? where rent_id= ?`, [{rent_properties_images:filteredArray.toString()}, rent_id], function(error, results, fields) {
                                                if (error) {
                                                    return res.status(400).send({
                                                        status: 400,
                                                        msg: "fail"
                                                    });
                                                } else {
                                                    return res.status(200).send({
                                                        status: 200,
                                                        msg: "Success"
                                                    });
                                                }
                                            });
                                }else{
                                     return res.status(200).send({
                                                        status: 200,
                                                        msg: "Success"
                                                    });
                                }
                            }
                        } else {
                            return res.status(400).send({
                                status: 400,
                                msg: "Record Not found."
                            });
                        }
                    }
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_rent = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).fields([{
        name: 'rent_properties_images',
        maxCount: 10
    }]);
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.rent_user_id) {
                var rent_properties_images = [];
                if (typeof req.files.rent_properties_images !== 'undefined') {
                    req.body.business_id = "rent_" + crypto.createHash('md5').update('ABCDEFGHIJL1234567890').digest('hex');
                    Object.keys(req.files.rent_properties_images).forEach(function(key, idx1, array1) {
                        var result_file = req.files.rent_properties_images[key];
                        rent_properties_images.push(define.BASE_URL+"bazar/"+result_file.filename);
                        if (idx1 === array1.length - 1) {
                            req.body.rent_properties_images = rent_properties_images.toString();
                            db.query(`INSERT INTO tbl_bazar_rent SET ?`, req.body, function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                rent_id:results.insertId
                                    });
                                }
                            });
                        }
                    });
                } else {
                    db.query(`INSERT INTO tbl_bazar_rent SET ?`, req.body, function(error, results, fields) {
                        if (error) {
                            return res.status(400).send({
                                status: 400,
                                msg: error
                            });
                        } else {
                            return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                rent_id:results.insertId
                            });
                        }
                    });
                }
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    rent_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.edit_rent = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).fields([{
        name: 'rent_properties_images',
        maxCount: 10
    }]);
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.rent_id) {
                var rent_properties_images = [];
                var rent_id = req.body.rent_id;
                delete(req.body.rent_id);
                if (typeof req.files.rent_properties_images !== 'undefined') {
                    req.body.business_id = "rent_" + crypto.createHash('md5').update('ABCDEFGHIJL1234567890').digest('hex');
                    Object.keys(req.files.rent_properties_images).forEach(function(key, idx1, array1) {
                        var result_file = req.files.rent_properties_images[key];
                        rent_properties_images.push(define.BASE_URL+"bazar/"+result_file.filename);
                        if (idx1 === array1.length - 1) {
                            req.body.rent_properties_images = rent_properties_images.toString();
                            db.query(`UPDATE tbl_bazar_rent SET ? where rent_id= ?`, [req.body, rent_id], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success"
                                    });
                                }
                            });
                        }
                    });
                } else {
                    db.query(`UPDATE tbl_bazar_rent SET ? where rent_id= ?`, [req.body, rent_id], function(error, results, fields) {
                        if (error) {
                            return res.status(400).send({
                                status: 400,
                                msg: error
                            });
                        } else {
                            return res.status(200).send({
                                status: 200,
                                msg: "Success"
                            });
                        }
                    });
                }
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1"
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_rating = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.rent_rating && req.body.rent_id) {
                db.query(`INSERT INTO tbl_bazar_rent_rating SET ?`, [req.body], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        var rating = 0;
                        var rating_count = 0;
                        db.query(`SELECT * FROM tbl_bazar_rent_rating where rent_id=?;`, [req.body.rent_id], function(error, results_rating, fields) {
                            if (error) throw error;
                            if (results_rating.length > 0) {
                                var total = 0;
                                Object.keys(results_rating).forEach(function(key1, idx1, array1) {
                                    var result_data_rating = results_rating[key1];
                                    total = parseFloat(total) + parseFloat(result_data_rating.rent_rating);
                                    if (idx1 === array1.length - 1) {
                                        var rating1 = parseFloat(total) / results_rating.length;
                                        rating = Math.round(rating1 * 100) / 100;
                                    }
                                });
                            }
                            return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                rating: rating,
                                rating_user_count: results_rating.length
                            });
                        });

                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    rating: 0,
                    rating_user_count: 0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_comment = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.rent_comments && req.body.rent_id) {
                db.query(`INSERT INTO tbl_bazar_rent_comments SET ?`, [req.body], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success",
                            rent_comment_id: results.insertId
                        });
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    rent_comment_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_approach = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.rent_id) {
                db.query(`INSERT INTO tbl_bazar_rent_approach SET ?`, [req.body], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success",
                            rent_approach_id: results.insertId
                        });
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1"
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_schedule = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.rent_id) {
                db.query(`INSERT INTO tbl_bazar_rent_schedule SET ?`, [req.body], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success",
                            rent_schedule_id: results.insertId
                        });
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    rent_schedule_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_rent_specialist = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: err
            });
        } else {
            if (req.body.rent_specialist_name) {
                db.query(`Select * From tbl_bazar_rent_specialist where rent_specialist_name= ?`, [req.body.rent_specialist_name], function(error, results, fields) {
                    if (error) {
                        return res.status(400).send({
                            status: 400,
                            msg: error
                        });
                    } else {
                        if (results.length <= 0) {
                            db.query(`INSERT INTO tbl_bazar_rent_specialist SET ?`, [req.body], function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: error
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        rent_specialist_id: results.insertId
                                    });
                                }
                            });
                        } else {
                            return res.status(409).send({
                                status: 409,
                                msg: "Record already exists"
                            });
                        }
                    }
                });

            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail1",
                    rent_specialist_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_rent_specialist = async (req, res) => {
	try {
    db.query(`SELECT *  from tbl_bazar_rent_specialist`, function(error, results1, fields) {
        if (error) throw error;
        if (results1.length > 0) {
            return res.status(200).send({
                status: 200,
                msg: "Success",
                rentSpecialistListCount: results1.length,
                rentSpecialistAllList: results1
            });
        } else {

            return res.status(404).send({
                status: 404,
                msg: "Record not found",
                rentSpecialistListCount: 0,
                rentSpecialistAllList: []
            });
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_rent_last_comment = async (req, res) => {
	try {
    if (req.query.rent_id && req.query.rent_comment_visiter_id) {
        db.query(`SELECT * FROM tbl_bazar_rent_comments WHERE rent_id = ? AND rent_comment_visiter_id = ? ORDER BY rent_comment_id DESC LIMIT 1;SELECT * FROM tbl_user_profile  where user_id=?`, [req.query.rent_id, req.query.rent_comment_visiter_id, req.query.rent_comment_visiter_id], function(error, results1, fields) {
            if (error) throw error;
            if (results1[0].length > 0) {
                var arr = results1[0][0];

                if (results1[1].length > 0) {

                    arr.user_name = results1[1][0].user_name;
                    arr.user_profile_img = results1[1][0].user_name;

                } else {
                    arr.user_name = '';
                    arr.user_profile_img = '';
                }
                return res.status(200).send({
                    status: 200,
                    msg: "Success",
                    rentLastComment: arr
                });
            } else {

                return res.status(404).send({
                    status: 404,
                    msg: "Record not found",
                    rentLastComment:{}
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail1",
            rentLastComment:{}
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_rent_search = async (req, res) => {
	try {
    if (req.query.user_id && req.query.distance_range) {
        db.query(`SELECT * FROM tbl_bazar_rent ORDER BY rent_id DESC;SELECT * FROM tbl_user_coordinates where coordinate_user_id=?`, [req.query.user_id], function(error, results, fields) {
            if (error) throw error;
            if (results[0].length > 0) {
                var final_array = [];
                Object.keys(results[0]).forEach(function(key, idx, array) {
                    var result_data = results[0][key];
                    result_data.table_name = "rent";
                    var di = '0.0 km';
                    var ti = '0 hours 0 mins';
                    var rating = 0;
                    var rating_count = 0;
                    var flag =2;
                    if (results[1].length > 0) {
                        //console.log(results[1]);
                        var origin = result_data.rent_latitude + "," + result_data.rent_longitude;
                        var destination = (results[1][0].coordinates_latitude) + "," + (results[1][0].coordinates_longitude);
                        //console.log(destination);
                        //console.log(origin);
                        var request = require('request');
                        var options = {
                            'method': 'GET',
                            'url': 'https://maps.googleapis.com/maps/api/distancematrix/json?units=km&origins=' + origin + '&destinations=' + destination + '&key='+define.GOOGLE_KEY,
                            'headers': {}
                        };
                    }else{
                         var origin = 00;
                         var destination = 00;
                         var request = require('request');
                         var options = {
                            'method': 'GET',
                            'url': 'https://maps.googleaps.com/maps/api/distancematrix/json?units=km&origins=' + origin + '&destinations=' + destination + '&key='+define.GOOGLE_KEY,
                            'headers': {}
                        };
                    }
                        request(options, function(error, response) {
                            if (error) {
                                result_data.distance = di;
                                result_data.time = ti;
                                flag =1;
                            } else {
                                var data_distance = JSON.parse(response.body);
                                if (data_distance.rows[0]) {
                                    if (data_distance.rows[0].elements[0].status == "OK") {
                                        if ((Math.round(req.query.distance_range * 1000)) >= (Math.round(data_distance.rows[0].elements[0].distance.value))) {
                                            di = data_distance.rows[0].elements[0].distance.text;
                                            ti = data_distance.rows[0].elements[0].duration.text;
                                            result_data.distance = di;
                                            result_data.time = ti;
                                              flag =1;
                                        }
                                    }
                                }
                            }
                           db.query(`SELECT * FROM tbl_bazar_rent_rating where rent_id=?;SELECT * FROM tbl_bazar_rent_schedule where rent_id=?`, [result_data.rent_id,result_data.rent_id], function(error, results_rating, fields) {
                                if (error) throw error;
                                if (results_rating[0].length > 0) {
                                    var total = 0;
                                    Object.keys(results_rating[0]).forEach(function(key1, idx1, array1) {
                                        var result_data_rating = results_rating[0][key1];
                                        total = parseFloat(total) + parseFloat(result_data_rating.rent_rating);
                                        if (idx1 === array1.length - 1) {
                                            var rating1 = parseFloat(total) / results_rating[0].length;
                                            rating = Math.round(rating1 * 100) / 100;
                                            //console.log(rating);
                                        }
                                    });
                                }

                                result_data.rent_schedule_details=(results_rating[1].length > 0) ? results_rating[1][0] : '';
                                result_data.distance = di;
                                result_data.time = ti;
                                result_data.rating = rating;
                                result_data.rating_user_count = results_rating.length;
                                if(flag ==1)
                                final_array.push(result_data);
                                if (idx === array.length - 1) {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        rentAllListCount: final_array.length,
                                        rentAllList: final_array
                                    });
                                }
                            });
                        });
                    // } else {
                    //     if (idx === array.length - 1) {
                    //         return res.status(200).send({
                    //             status: 200,
                    //             msg: "Success",
                    //             feedCountList: final_array
                    //         });
                    //     }
                    // }
                });
            } else {
                return res.status(404).send({
                    status: 404,
                    msg: "Record not found",
                    rentAllListCount: 0,
                    rentAllList: []
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail1",
            rentAllListCount: 0,
            rentAllList: []
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_rent_random = async (req, res) => {
	try {
    if (req.query.user_id && req.query.distance_range) {
        db.query(`SELECT * FROM tbl_bazar_rent ORDER BY rand() limit 15;SELECT * FROM tbl_user_coordinates where coordinate_user_id=?`, [req.query.user_id], function(error, results, fields) {
            if (error) throw error;
            if (results[0].length > 0) {
                var final_array = [];
                Object.keys(results[0]).forEach(function(key, idx, array) {
                    var result_data = results[0][key];
                    result_data.table_name = "rent";
                    var di = '0.0 km';
                    var ti = '0 hours 0 mins';
                    var rating = 0;
                    var rating_count = 0;
                    var flag =2;
                    if (results[1].length > 0) {
                        //console.log(results[1]);
                        var origin = result_data.rent_latitude + "," + result_data.rent_longitude;
                        var destination = (results[1][0].coordinates_latitude) + "," + (results[1][0].coordinates_longitude);
                        //console.log(destination);
                        //console.log(origin);
                        var request = require('request');
                        var options = {
                            'method': 'GET',
                            'url': 'https://maps.googleapis.com/maps/api/distancematrix/json?units=km&origins=' + origin + '&destinations=' + destination + '&key='+define.GOOGLE_KEY,
                            'headers': {}
                        };
                    }else{
                         var origin = 00;
                         var destination = 00;
                         var request = require('request');
                         var options = {
                            'method': 'GET',
                            'url': 'https://maps.googleaps.com/maps/api/distancematrix/json?units=km&origins=' + origin + '&destinations=' + destination + '&key='+define.GOOGLE_KEY,
                            'headers': {}
                        };
                    }
                        request(options, function(error, response) {
                            if (error) {
                                result_data.distance = di;
                                result_data.time = ti;
                                flag=1;

                            } else {
                                var data_distance = JSON.parse(response.body);
                                if (data_distance.rows[0]) {
                                    if (data_distance.rows[0].elements[0].status == "OK") {
                                        if ((Math.round(req.query.distance_range * 1000)) >= (Math.round(data_distance.rows[0].elements[0].distance.value))) {
                                            di = data_distance.rows[0].elements[0].distance.text;
                                            ti = data_distance.rows[0].elements[0].duration.text;

                                             flag=1;
                                        }
                                    }
                                }
                            }
                            result_data.distance = di;
                            result_data.time = ti;
                            if(flag==1)
                            final_array.push(result_data);
                            if (idx === array.length - 1) {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Success",
                                    rentRandomListCount: final_array.length,
                                    rentRandomList: final_array
                                });
                            }

                        });
                    // } else {
                    //     if (idx === array.length - 1) {
                    //         return res.status(200).send({
                    //             status: 200,
                    //             msg: "Success",
                    //             feedCountList: final_array
                    //         });
                    //     }
                    // }
                });

            } else {
                return res.status(404).send({
                    status: 404,
                    msg: "Record not found",
                    rentRandomListCount: 0,
                    rentRandomList: []
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail1",
            rentRandomListCount: 0,
            rentRandomList: []
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_rent_all = async (req, res) => {
	try {
    var pagination = [];
    if (req.query.user_id && req.query.distance_range && req.query.page_no) {
                  var no_of_records_per_page = 10;
                  var rowno = req.query.page_no;
                if (rowno != 0)
                {
                    rowno = (rowno - 1) * no_of_records_per_page;
                }
        db.query(`SELECT * FROM tbl_bazar_rent order by rent_id desc LIMIT ? OFFSET ?;SELECT * FROM tbl_user_coordinates where coordinate_user_id=?;SELECT COUNT(*) AS numrows FROM tbl_bazar_rent`, [no_of_records_per_page,rowno,req.query.user_id], function(error, results, fields) {
            if (error) throw error;
            if (results[0].length > 0) {
                var final_array = [];
                Object.keys(results[0]).forEach(function(key, idx, array) {
                    var result_data = results[0][key];
                    result_data.table_name = "rent";
                    var di = '0.0 km';
                    var ti = '0 hours 0 mins';
                    var rating = 0;
                    var rating_count = 0;
                    var flag=2;
                    if (results[1].length > 0) {
                        //console.log(results[1]);
                        var origin = result_data.rent_latitude + "," + result_data.rent_longitude;
                        var destination = (results[1][0].coordinates_latitude) + "," + (results[1][0].coordinates_longitude);
                        //console.log(destination);
                        //console.log(origin);
                        var request = require('request');
                        var options = {
                            'method': 'GET',
                            'url': 'https://maps.googleapis.com/maps/api/distancematrix/json?units=km&origins=' + origin + '&destinations=' + destination + '&key='+define.GOOGLE_KEY,
                            'headers': {}
                        };
                    }else{
                         var origin = 00;
                         var destination = 00;
                         var request = require('request');
                         var options = {
                            'method': 'GET',
                            'url': 'https://maps.googleapis.com/maps/api/distancematrix/json?units=km&origins=' + origin + '&destinations=' + destination + '&key='+define.GOOGLE_KEY,
                            'headers': {}
                        };
                    }
                        request(options, function(error, response) {
                            if (error) {
                                result_data.distance = di;
                                result_data.time = ti;
                                flag =1;
                            } else {
                                var data_distance = JSON.parse(response.body);
                                if (data_distance.rows[0] && data_distance.rows[0].elements[0].status == "OK") {
                                      //  if ((Math.round(req.query.distance_range * 1000)) >= (Math.round(data_distance.rows[0].elements[0].distance.value))) {
                                            di = data_distance.rows[0].elements[0].distance.text;
                                            ti = data_distance.rows[0].elements[0].duration.text;
                                            result_data.distance = di;
                                            result_data.time = ti;
                                            flag=1;

                                       // }
                                   // }
                                }else{
                                     flag=1;
                                result_data.distance = di;
                                result_data.time = ti;
                                }
                            }
                    db.query(`SELECT * FROM tbl_bazar_rent_rating where rent_id=?;SELECT * FROM tbl_bazar_rent_schedule where rent_id=?`, [result_data.rent_id,result_data.rent_id], function(error, results_rating, fields) {
                                if (error) throw error;
                                if (results_rating[0].length > 0) {
                                    var total = 0;
                                    Object.keys(results_rating[0]).forEach(function(key1, idx1, array1) {
                                        var result_data_rating = results_rating[0][key1];
                                        total = parseFloat(total) + parseFloat(result_data_rating.rent_rating);
                                        if (idx1 === array1.length - 1) {
                                            var rating1 = parseFloat(total) / results_rating[0].length;
                                            rating = Math.round(rating1 * 100) / 100;
                                            //console.log(rating);
                                        }
                                    });
                                }

                                result_data.rent_schedule_details=(results_rating[1].length > 0) ? results_rating[1][0] : '';
                                result_data.rating = rating;
                                result_data.rating_user_count = results_rating.length;
                                //console.log(result_data);
                              //  if(flag==1)
                                final_array.push(result_data);
                                 if (idx === array.length - 1) {
                                      setTimeout(function() {
                                    //let no_of_records_per_page = 5;
                                    if (final_array.length > 0) {
                                        let max_pages = parseInt(Math.ceil((results[2][0].numrows) / no_of_records_per_page));
                                        if (req.query.page_no && req.query.page_no <= max_pages) {
                                            let page_no = req.query.page_no;

                                            // PAGINATION START

                                            let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
                                          //  let sliceData = final_array.slice(offset, offset + no_of_records_per_page)
                                            var pagination = {
                                                total_rows: results[2][0].numrows,
                                                total_pages: parseInt(Math.ceil((results[2][0].numrows) / no_of_records_per_page)),
                                                per_page: no_of_records_per_page,
                                                offset: offset,
                                                current_page_no: page_no
                                            };
                                        // PAGINATION END

                                        return res.status(200).send({
                                            status: 200,
                                            msg: "Success",
                                            rentAllListCount: results[2][0].numrows,
                                            rentAllList: final_array,
                                            pagination: pagination
                                        });
                                    } else {
                                        return res.status(404).send({
                                            status: 404,
                                            msg: "Page no missing or Its incorrect.",
                                            rentAllListCount: 0,
                                            rentAllList: [],
                                            pagination:  {
                                                total_rows: 0,
                                                total_pages: 0,
                                                per_page: 0,
                                                offset: 0,
                                                current_page_no: '0'
                                            }

                                        });
                                    }
                                    }else{
                                        return res.status(404).send({
                                            status: 404,
                                            msg: "No matching records found.",
                                            rentAllListCount: 0,
                                            rentAllList: [],
                                            pagination:  {
                                                total_rows: 0,
                                                total_pages: 0,
                                                per_page: 0,
                                                offset: 0,
                                                current_page_no: '0'
                                            }
                                        });
                                    }
                                      }, 100);
                                }

                            });
                        });
                    // } else {
                    //     if (idx === array.length - 1) {
                    //         return res.status(200).send({
                    //             status: 200,
                    //             msg: "Success",
                    //             feedCountList: final_array
                    //         });
                    //     }
                    // }
                });

            } else {
                return res.status(404).send({
                    status: 404,
                    msg: "Record not found",
                    rentAllListCount: 0,
                    rentAllList: [],
                    pagination:  {
                        total_rows: 0,
                        total_pages: 0,
                        per_page: 0,
                        offset: 0,
                        current_page_no: '0'
                    }
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail1",
            rentAllListCount: 0,
            rentAllList: [],
            pagination:  {
                total_rows: 0,
                total_pages: 0,
                per_page: 0,
                offset: 0,
                current_page_no: '0'
            }
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_rent_click = async (req, res) => {
	try {
    if (req.query.rent_id) {
        db.query(`SELECT * FROM tbl_bazar_rent where rent_id= ? ; SELECT * FROM tbl_bazar_rent where rent_id != ? LIMIT 30;SELECT * FROM tbl_user_coordinates where coordinate_user_id=?`, [req.query.rent_id, req.query.rent_id,req.query.user_id], function(error, results, fields) {
            if (error) throw error;
            if (results[0].length > 0) {
                var final_array = [];
                var final_array_one = [];
                var comment = [];
                var rating = 0;
                var rating_count = 0;
                var flag = 2;
                if (results[1].length > 0) {
                    const merged = results[0].concat(results[1]);
                    //console.log(merged);
                    Object.keys(merged).forEach(function(key, idx, array) {
                        var result_data = merged[key];
                        result_data.table_name = "rent";
                        db.query(`SELECT * FROM tbl_bazar_rent_rating where rent_id=?;`, [result_data.rent_id], function(error, results_rating, fields) {
                            if (error) throw error;
                            var di = '0.0 km';
                            var ti = '0 hours 0 mins';
                            if (results[2].length > 0) {
                                //console.log(results[1]);
                                var origin = result_data.rent_latitude + "," + result_data.rent_longitude;
                                var destination = (results[2][0].coordinates_latitude) + "," + (results[2][0].coordinates_longitude);
                                //console.log(destination);
                                //console.log(origin);
                                var request = require('request');
                                var options = {
                                    'method': 'GET',
                                    'url': 'https://maps.googleapis.com/maps/api/distancematrix/json?units=km&origins=' + origin + '&destinations=' + destination + '&key='+define.GOOGLE_KEY,
                                    'headers': {}
                                };
                            }else{
                                 var origin = 00;
                                 var destination = 00;
                                 var request = require('request');
                                 var options = {
                                    'method': 'GET',
                                    'url': 'https://maps.googleapis.com/maps/api/distancematrix/json?units=km&origins=' + origin + '&destinations=' + destination + '&key='+define.GOOGLE_KEY,
                                    'headers': {}
                                };
                            }
                                request(options, function(error, response) {
                                    if (error) {
                                        result_data.distance = di;
                                        result_data.time = ti;
                                        flag =1;
                                    } else {
                                        var data_distance = JSON.parse(response.body);
                                        if (data_distance.rows[0] && data_distance.rows[0].elements[0].status == "OK") {
                                              //  if ((Math.round(req.query.distance_range * 1000)) >= (Math.round(data_distance.rows[0].elements[0].distance.value))) {
                                                    di = data_distance.rows[0].elements[0].distance.text;
                                                    ti = data_distance.rows[0].elements[0].duration.text;
                                                    result_data.distance = di;
                                                    result_data.time = ti;
                                                    flag=1;

                                               // }
                                           // }
                                        }else{
                                             flag=1;
                                        result_data.distance = di;
                                        result_data.time = ti;
                                        }
                                    }
                            if (results_rating.length > 0) {
                                var total = 0;
                                Object.keys(results_rating).forEach(function(key1, idx1, array1) {
                                    var result_data_rating = results_rating[key1];
                                    total = parseFloat(total) + parseFloat(result_data_rating.rent_rating);
                                    if (idx1 === array1.length - 1) {
                                        var rating1 = parseFloat(total) / results_rating.length;
                                        rating = Math.round(rating1 * 100) / 100;
                                    }
                                });
                            }

                            result_data.rating = rating;
                            result_data.rating_user_count = results_rating.length;
                            if (result_data.rent_id == req.query.rent_id)
                                final_array.push(result_data);
                            else
                                final_array_one.push(result_data);
                            if (idx === array.length - 1) {
                                   db.query(`SELECT * FROM tbl_bazar_rent_comments where rent_id=?;SELECT * FROM tbl_bazar_rent_schedule where rent_id=?`, [req.query.rent_id,req.query.rent_id], function(error, results_comment, fields) {
                                    if (error) throw error;
                                                 if(results_comment[0]==''){
                                        results_comment[0][0]={
                                            rent_comment_visiter_id:''
                                        }
                                    }
                                    if (results_comment[0].length > 0) {
                                        Object.keys(results_comment[0]).forEach(function(key12, idx12, array12) {
                                            var results_comment_data = results_comment[0][key12];
                                            db.query(`SELECT * FROM tbl_user_profile where user_id=?;`, [results_comment_data.rent_comment_visiter_id], function(error, results_comment, fields) {
                                                if (error) throw error;
                                                if (results_comment.length > 0) {
                                                    results_comment_data.user_name = results_comment[0].user_name;
                                                    results_comment_data.user_profile_img = results_comment[0].user_profile_img;
                                                } else {
                                                    results_comment_data.user_name = '';
                                                    results_comment_data.user_profile_img = '';
                                                }
                                                  if(results_comment_data.rent_comment_visiter_id!='')
                                                comment.push(results_comment_data);
                                                if (idx12 === array12.length - 1) {
                                                     setTimeout(function() {
                                                    return res.status(200).send({
                                                        status: 200,
                                                        msg: "Success",
                                                        rentClickListCount: final_array_one.length,
                                                        rentClickDetails: (final_array[0]!='') ? final_array[0] : {},
                                                        comment: comment,
                                                        rent_schedule_details:(results_comment[1]) ? results_comment[1][0] : '',
                                                        rentClickList: final_array_one
                                                    });
                                                     }, 900);
                                                 
                                                }
                                            });
                                        });
                                    } else {
                                        return res.status(200).send({
                                            status: 200,
                                            msg: "Success",
                                            rentClickListCount: final_array_one.length,
                                            rentClickDetails: (final_array[0]!='') ? final_array[0] : {},
                                            comment: comment,
                                            rent_schedule_details:(results_comment[1]) ? results_comment[1][0] : '',
                                            rentClickList: final_array_one
                                        });
                                    }
                                });

                            }
                        });
                        });
                    });
                } else {
                    if (idx === array.length - 1) {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success",
                            rentClickListCount: 0,
                            rentClickDetails: {},
                            comment: {},
                            rent_schedule_details:{},
                            rentClickList: []
                        });
                    }
                }


            } else {
                return res.status(404).send({
                    status: 404,
                    msg: "Record not found",
                    rentClickListCount: 0,
                    rentClickDetails: {},
                    comment: {},
                    rent_schedule_details:{},
                    rentClickList: []
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            rentClickListCount: 0,
            rentClickDetails: {},
            comment: {},
            rent_schedule_details:{},
            rentClickList: []
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.rent_follow = async (req, res) => {
	try {
    if (req.query.follower_user_id && req.query.rent_id) {
        db.query(`select * From tbl_bazar_rent_followers where follower_user_id= ?; select * From tbl_bazar_rent where rent_id= ?`, [req.query.follower_user_id, req.query.rent_id], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            } else {
                if (results[0].length <= 0) {
                    if (results[1].length > 0) {
                        var count = results[1][0].follower_count + 1;
                        var d = {
                            follower_count: count
                        };
                        db.query(`UPDATE tbl_bazar_rent SET ? where rent_id= ?`, [d, req.query.rent_id], function(error, results_update, fields) {
                            if (error) {

                            } else {}
                        });
                        req.query.follower_status = 1;
                        db.query(`INSERT INTO tbl_bazar_rent_followers SET ?`, req.query, function(error, results, fields) {
                            if (error) {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail"
                                });
                            } else {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Success",
                                    count: count
                                });
                            }
                        });
                    } else {
                        return res.status(400).send({
                            status: 400,
                            msg: 'fail'
                        });
                    }
                } else {
                    if (results[1].length > 0) {
                        var follower_status = 1;
                        var count = 0;
                        if (results[0][0].follower_status == 1) {
                            follower_status = 0;
                        }
                        if (results[1][0].follower_count > 0 && results[0][0].follower_status == 1) {
                            count = results[1][0].follower_count - 1;
                        } else {
                            count = results[1][0].follower_count + 1;
                        }
                        var d = {
                            follower_count: count
                        };
                        db.query(`UPDATE tbl_bazar_rent SET ? where rent_id= ?`, [d, req.query.rent_id], function(error, results_update, fields) {
                            if (error) {

                            } else {}
                        });
                        db.query(`UPDATE tbl_bazar_rent_followers SET ? where follower_user_id = ?`, [{
                            follower_status: follower_status
                        }, req.query.follower_user_id], function(error, results, fields) {
                            if (error) {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail"
                                });
                            } else {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Success",
                                    count: count
                                });
                            }
                        });

                    } else {
                        return res.status(400).send({
                            status: 400,
                            msg: 'fail'
                        });
                    }
                }
            }
        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail"
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.rent_like = async (req, res) => {
	try {
    if (req.query.rent_like_user_id && req.query.rent_id) {
        db.query(`select * From tbl_bazar_rent_like where rent_like_user_id= ? and rent_id=?; select * From tbl_bazar_rent where rent_id= ?`, [req.query.rent_like_user_id, req.query.rent_id, req.query.rent_id], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            } else {
                if (req.query.flag == 1) {
                    if (results[0].length <= 0) {
                        if (results[1].length > 0) {
                            var count = results[1][0].like_count + 1;
                            var d = {
                                like_count: count
                            };
                            db.query(`UPDATE tbl_bazar_rent SET ? where rent_id= ?`, [d, req.query.rent_id], function(error, results_update, fields) {
                                if (error) {

                                } else {}
                            });
                            delete(req.query.flag);
                            db.query(`INSERT INTO tbl_bazar_rent_like SET ?`, req.query, function(error, results, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: "fail"
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        count: count
                                    });
                                }
                            });
                        } else {
                            return res.status(400).send({
                                status: 400,
                                msg: 'fail'
                            });
                        }
                    } else {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success",
                            count: (results[1].length > 0) ? results[1][0].like_count : 0
                        });
                    }
                } else {
                    if (results[1].length > 0) {
                        var count = 0;
                        if (results[1][0].like_count > 0) {
                            count = results[1][0].like_count - 1;
                        }
                        var d = {
                            like_count: count
                        };
                        db.query(`UPDATE tbl_bazar_rent SET ? where rent_id= ?`, [d, req.query.rent_id], function(error, results_update, fields) {
                            if (error) {

                            } else {}
                        });
                        db.query(`DELETE from tbl_bazar_rent_like where rent_id=? and rent_like_user_id = ?`, [req.query.rent_id, req.query.rent_like_user_id], function(error, results, fields) {
                            if (error) {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail"
                                });
                            } else {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Success",
                                    count: count
                                });
                            }
                        });

                    } else {
                        return res.status(400).send({
                            status: 400,
                            msg: 'fail'
                        });
                    }
                }
            }
        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail"
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.rent_view = async (req, res) => {
	try {
    if (req.query.rent_view_user_id && req.query.rent_id) {
        db.query(`select * From tbl_bazar_rent_view where rent_view_user_id= ? and rent_id=?; select * From tbl_bazar_rent where rent_id= ?`, [req.query.rent_view_user_id, req.query.rent_id, req.query.rent_id], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            } else {
                if (results[0].length <= 0) {
                    if (results[1].length > 0) {
                        var count = results[1][0].view_count + 1;
                        var d = {
                            view_count: count
                        };
                        db.query(`UPDATE tbl_bazar_rent SET ? where rent_id= ?`, [d, req.query.rent_id], function(error, results_update, fields) {
                            if (error) {

                            } else {}
                        });
                        delete(req.query.flag);
                        db.query(`INSERT INTO tbl_bazar_rent_view SET ?`, req.query, function(error, results, fields) {
                            if (error) {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail"
                                });
                            } else {
                                return res.status(200).send({
                                    status: 200,
                                    msg: "Success",
                                    count: count
                                });
                            }
                        });
                    } else {
                        return res.status(400).send({
                            status: 400,
                            msg: 'fail'
                        });
                    }
                } else {
                    return res.status(200).send({
                        status: 200,
                        msg: "Success",
                        count: (results[1].length > 0) ? results[1][0].view_count : 0
                    });
                }
            }
        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail"
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_follow_like = async (req, res) => {
	try {
    if (req.query.user_id && req.query.rent_id) {
        db.query(`select * From tbl_bazar_rent where rent_id=?;SELECT * FROM tbl_user_coordinates where coordinate_user_id=?`, [req.query.rent_id, req.query.user_id], function(error, results, fields) {
            if (error) {
                return res.status(400).send({
                    status: 400,
                    msg: "fail"
                });
            } else {
                if (results[0].length > 0) {



                    db.query(`select * From tbl_bazar_rent_followers where rent_id= ? and follower_user_id=?`, [req.query.rent_id, req.query.user_id], function(error, follow, fields) {
                        if (error) {
                            return res.status(400).send({
                                status: 400,
                                msg: "fail"
                            });
                        } else {}
                        db.query(`select * From tbl_bazar_rent_like where rent_id= ? and rent_like_user_id=?`, [req.query.rent_id, req.query.user_id], function(error, like, fields) {
                            if (error) {
                                return res.status(400).send({
                                    status: 400,
                                    msg: "fail"
                                });
                            } else {

                            }
                            results[0][0].follow = follow.length;
                            results[0][0].like = like.length;
                            var result_data = results[0][0];
                            //console.log(results[0][0]);
                            var di = '0.0 km';
                            var ti = '0 hours 0 mins';
                            var flag = 2;
                            if (results[1].length > 0) {
                                var origin = result_data.rent_latitude + "," + result_data.rent_longitude;
                                var destination = (results[1][0].coordinates_latitude) + "," + (results[1][0].coordinates_longitude);
                                //console.log(destination);
                                //console.log(origin);
                                var request = require('request');
                                var options = {
                                    'method': 'GET',
                                    'url': 'https://maps.googleapis.com/maps/api/distancematrix/json?units=km&origins=' + origin + '&destinations=' + destination + '&key='+define.GOOGLE_KEY,
                                    'headers': {}
                                };
                            }else{
                         var origin = 00;
                         var destination = 00;
                         var request = require('request');
                         var options = {
                            'method': 'GET',
                            'url': 'https://maps.googleaps.com/maps/api/distancematrix/json?units=km&origins=' + origin + '&destinations=' + destination + '&key='+define.GOOGLE_KEY,
                            'headers': {}
                        };
                    }
                                request(options, function(error, response) {
                                    if (error) {} else {
                                        var data_distance = JSON.parse(response.body);
                                        if (data_distance.rows[0]) {
                                            if (data_distance.rows[0].elements[0].status == "OK") {
                                                // if ((Math.round(req.query.distance_range * 1000)) >= (Math.round(data_distance.rows[0].elements[0].distance.value))) {
                                                di = data_distance.rows[0].elements[0].distance.text;
                                                ti = data_distance.rows[0].elements[0].duration.text;
                                                //console.log(data_distance.rows[0].elements[0].distance.text);
                                                flag = 1;
                                                //}
                                            }
                                        }
                                    }
                                    results[0][0].distance = di;
                                    results[0][0].time = ti;
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        rentListWithLikeFollow: results[0][0]
                                    });
                                });
                            // } else {
                            //     result_data.distance = di;
                            //     result_data.time = ti;
                            //     return res.status(200).send({
                            //         status: 200,
                            //         msg: "Success1",
                            //         rentListWithLikeFollow: result_data
                            //     });
                            // }
                        });

                    });


                } else {
                    return res.status(400).send({
                        status: 400,
                        msg: 'fail2',
                        rentListWithLikeFollow:{}
                    });
                }
            }

        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            rentListWithLikeFollow:{}
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_rent_comment = async (req, res) => {
	try {
    if (req.query.rent_id) {
        var comment = [];
        db.query(`SELECT * FROM tbl_bazar_rent_comments where rent_id=?;`, [req.query.rent_id], function(error, results_comment, fields) {
            if (error) throw error;
            if (results_comment.length > 0) {
                Object.keys(results_comment).forEach(function(key12, idx12, array12) {
                    var results_comment_data = results_comment[key12];
                    db.query(`SELECT * FROM tbl_user_profile where user_id=?;`, [results_comment_data.rent_comment_visiter_id], function(error, results_comment, fields) {
                        if (error) throw error;
                        if (results_comment.length > 0) {
                            results_comment_data.user_name = results_comment[0].user_name;
                            results_comment_data.user_profile_img = results_comment[0].user_profile_img;
                        } else {
                            results_comment_data.user_name = '';
                            results_comment_data.user_profile_img = '';
                        }
                        comment.push(results_comment_data);
                        if (idx12 === array12.length - 1) {
                            return res.status(200).send({
                                status: 200,
                                msg: "Success",
                                rentCommentsListCount: comment.length,
                                rentCommentsList: comment
                            });
                        }
                    });
                });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                    rentCommentsListCount: 0,
                    rentCommentsList: []
                });
            }
        });

    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            rentCommentsListCount: 0,
            rentCommentsList: []
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_schedule = async (req, res) => {
	try {
    let upload = multer({
        storage: bazar,
    }).single('');
    upload(req, res, function(err) {
        if (err) {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        } else {
            if (req.body.rent_id) {
                            db.query(`INSERT INTO tbl_bazar_rent_schedule SET ?`, [req.body], function(error, results66, fields) {
                                if (error) {
                                    return res.status(400).send({
                                        status: 400,
                                        msg: "fail"
                                    });
                                } else {
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        rent_schedule_id:results66.insertId
                                    });
                                }
                            });
            } else {
                return res.status(400).send({
                    status: 400,
                    msg: "fail",
                    rent_schedule_id:0
                });
            }
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_schedule = async (req, res) => {
	try {
    var comment = [];
    if (req.query.rent_id) {
    db.query(`SELECT * FROM tbl_bazar_rent_schedule where rent_id=?`,[req.query.rent_id], function(error, results_comment, fields) {
        if (error) throw error;
        if (results_comment.length > 0) {

            return res.status(200).send({
                status: 200,
                msg: "Success",
                rent_schedule_details: results_comment
            });

        } else {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        }
    });
}else{
    return res.status(400).send({
        status: 400,
        msg: "fail"
    });
}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
