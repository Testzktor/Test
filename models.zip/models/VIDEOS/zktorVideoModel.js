const fs = require('fs');
const db = require("../../config/connection");
const middleware = require("../../middleware/authentication");
var timeAgo = require('node-time-ago');
const {
	getVideoDurationInSeconds
} = require('get-video-duration');
var timeout = require('connect-timeout');
var bodyParser = require('body-parser');
const full = require("../USER/userFullProfile");
const multer = require('fastify-multer');
const crypto = require("crypto");
const {
	exec
} = require("child_process");
var path = require('path')
var zktor = multer.diskStorage({
	destination: function(req, file, cb) {
		cb(null, '../uploads/ztkor_video_media/');
	},
	filename: function(req, file, cb) {
		cb(null, "zktor_video_media_" + crypto.createHash('md5').update('abcdefgh').digest('hex') + Date.now() + path.extname(file.originalname));
	}
});
exports.update_zktor_video = async (req, res) => {
	try {
	let upload = multer({
		storage: zktor,
	}).fields([{
		name: 'zktor_video_url',
		maxCount: 10
	}, {
		name: 'zktor_video_thumbnail_url'
	}]);
	upload(req, res, function(err) {
		if (err) {
			return res.status(400).send({
				status: 400,
				msg: err
			});
		} else {
			if (req.body.zktor_video_id) {
				var zktor_video_id = req.body.zktor_video_id;
				delete(req.body.zktor_video_id);
				var i = 0;
				var zktor_video_url = [];
				var zktor_video_url_type = '';
				var zktor_short_video_url = [];
				var zktor_video_video_length = [];
				var zktor_video_thumbnail_url = [];
				if (typeof req.files.zktor_video_url !== 'undefined') {
					Object.keys(req.files.zktor_video_url).forEach(function(key, idx1, array1) {
						var result_file = req.files.zktor_video_url[key];
						let ext = (result_file.filename).substring((result_file.filename).lastIndexOf('.'), (result_file.filename).length);
						if (ext == ".png" || ext == ".jpg" || ext == ".jpeg") {
							let image_file_path = result_file.path;
							let ext = (result_file.filename).substring((result_file.filename).lastIndexOf('.'), (result_file.filename).length);
							let image = "feed_image_" + crypto.createHash('md5').update('abcdefgh').digest('hex') + Date.now() + ext;
							let path_to_store_generated_width = "../uploads/ztkor_video_media/" + image;
							let cmd = "ffmpeg -i " + image_file_path + " -vf scale=iw*2:ih*2 " + path_to_store_generated_width;
							exec(cmd, (error, stdout, stderr) => {
								if (error) {
									i++;
								}
								if (stderr) {}
							});
							zktor_video_url.push(define.BASE_URL + "ztkor_video_media/" + image);
							if (zktor_video_url_type == '')
								zktor_video_url_type = 'image';
						}
						let video_file_path = result_file.path;
						getVideoDurationInSeconds(video_file_path).then((duration) => {
							if (ext === '.mov' || ext === '.avchd' || ext === '.mkv' || ext === '.webm' || ext === '.gif' || ext === '.mp4' || ext === '.ogg' || ext === '.wmv' || ext === '.x-flv' || ext === '.avi') {
								let video_file_path = result_file.path;
								let ext = (result_file.filename).substring((result_file.filename).lastIndexOf('.'), (result_file.filename).length);

								let video = "zktor_video_url_" + crypto.createHash('md5').update('abcdefgh').digest('hex') + Date.now() + ext;
								let path_to_store_generated_width = "../uploads/ztkor_video_media/" + video;
								let cmd = "ffmpeg -i " + video_file_path + " -max_muxing_queue_size 21512512 -vf scale=iw*2:ih*2 -preset slow -crf 40 " + path_to_store_generated_width;
								exec(cmd, (error, stdout, stderr) => {
									if (error) {
										i = 1;
									}
									if (stderr) {}
								});
								// let video1 = "zktor_video_thumbnail_url_" + crypto.createHash('md5').update('abcdefgh').digest('hex') + Date.now() + ".jpg";
								// let path_to_store_generated_thumbnail = "../uploads/ztkor_video_media/" + video1;
								// let sec = 4;
								// let cmd1 = "ffmpeg  -i " + video_file_path + " -vf scale=iw*2:ih*2 -deinterlace -an -ss " + sec + " -t 00:00:01   -r 1 -y -vcodec mjpeg -f mjpeg " + path_to_store_generated_thumbnail + " 2>&1";
								// exec(cmd1, (error, stdout, stderr) => {
								//     if (error) {}
								//     if (stderr) {
								//     }
								// });
								let video2 = "zktor_short_video_url_" + crypto.createHash('md5').update('abcdefgh').digest('hex') + Date.now() + ext;
								let path_to_store_generated_short_video = "../uploads/ztkor_video_media/" + video2;
								let cmd2 = "ffmpeg -i " + video_file_path + " -max_muxing_queue_size 21512512 -vf scale=iw*2:ih*2  -ss 00:01 -to 00:05 -c:v libx264 -crf 40 " + path_to_store_generated_short_video;
								exec(cmd2, (error, stdout, stderr) => {
									if (error) {
										i = 1;
										//  //console.log(`error: ${error.message}`);
										//  return;
									}
									if (stderr) {
										// //console.log(`stderr short video: ${stderr}`);
										// return;
									}
									// //console.log(`stdout: ${stdout}`);
								});
								zktor_video_video_length.push(Math.round(duration));
								if (zktor_video_url_type == '')
									zktor_video_url_type = 'video';
								zktor_video_url.push(define.BASE_URL + "ztkor_video_media/" + video);
								//  zktor_video_thumbnail_url.push("https://softawork1.xyz/uploads/ztkor_video_media/"+video1);
								zktor_short_video_url.push(define.BASE_URL + "ztkor_video_media/" + video2);
							}
							if (idx1 === array1.length - 1) {
								if (i == 0) {
									// //console.log(req.files.zktor_video_thumbnail_url[0]);
									if (typeof req.files.zktor_video_thumbnail_url !== 'undefined') {
										req.body.zktor_video_thumbnail_url = define.BASE_URL + "ztkor_video_media/" + req.files.zktor_video_thumbnail_url[0].filename;
									}
									req.body.zktor_video_url = zktor_video_url.toString();
									//req.body.zktor_video_thumbnail_url = zktor_video_thumbnail_url.toString();
									req.body.zktor_short_video_url = zktor_short_video_url.toString();
									// //console.log(zktor_video_video_length);
									req.body.zktor_video_video_length = zktor_video_video_length.toString();
									//req.body.zktor_video_url_type = zktor_video_url_type;
									db.query(`UPDATE tbl_zktor_video SET ? where zktor_video_id=?`, [req.body, zktor_video_id], function(error, results, fields) {
										if (error) {
											return res.status(400).send({
												status: 400,
												msg: "fail"
											});
										} else {
											return res.status(200).send({
												status: 200,
												msg: "Success"
											});
										}
									});
								} else {
									return res.status(400).send({
										status: 400,
										msg: "Media file is corrupted "
									});
								}
							}
						});
					});
				} else {
					if (typeof req.files.zktor_video_thumbnail_url !== 'undefined') {
						req.body.zktor_video_thumbnail_url = define.BASE_URL + "ztkor_video_media/" + req.files.zktor_video_thumbnail_url[0].filename;
					}
					db.query(`UPDATE tbl_zktor_video SET ? where zktor_video_id=?`, [req.body, zktor_video_id], function(error, results, fields) {
						if (error) {
							return res.status(400).send({
								status: 400,
								msg: "fail"
							});
						} else {
							return res.status(200).send({
								status: 200,
								msg: "Success"
							});
						}
					});
				}
			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.insert_zktor_video = async (req, res) => {
	try {
	let upload = multer({
		storage: zktor,
	}).fields([{
		name: 'zktor_video_url',
		maxCount: 10
	}, {
		name: 'zktor_video_thumbnail_url'
	}]);
	upload(req, res, function(err) {
		if (err) {
			return res.status(400).send({
				status: 400,
				msg: err
			});
		} else {
			if (req.body.zktor_video_user_id) {
				var i = 0;
				var zktor_video_url = [];
				var zktor_video_url_type = '';
				var zktor_short_video_url = [];
				var zktor_video_video_length = [];
				var zktor_video_thumbnail_url = [];
				if (typeof req.files.zktor_video_url !== 'undefined') {
					Object.keys(req.files.zktor_video_url).forEach(function(key, idx1, array1) {
						var result_file = req.files.zktor_video_url[key];
						let ext = result_file.originalname.substring(result_file.originalname.lastIndexOf('.'), result_file.originalname.length);
						if (ext == ".png" || ext == ".jpg" || ext == ".jpeg") {
							let image_file_path = result_file.path;
							let ext = (result_file.filename).substring((result_file.filename).lastIndexOf('.'), (result_file.filename).length);
							let image = "feed_image_" + crypto.createHash('md5').update('abcdefgh').digest('hex') + Date.now() + ext;
							let path_to_store_generated_width = "../uploads/ztkor_video_media/" + image;
							let cmd = "ffmpeg -i " + image_file_path + " -vf scale=iw*2:ih*2 " + path_to_store_generated_width;
							exec(cmd, (error, stdout, stderr) => {
								if (error) {
									i++;
								}
								if (stderr) {}
							});
							zktor_video_url.push(define.BASE_URL + "ztkor_video_media/" + image);
							if (zktor_video_url_type == '')
								zktor_video_url_type = 'image';
						}
						let video_file_path = result_file.path;
						getVideoDurationInSeconds(video_file_path).then((duration) => {
							if (ext == '.mov' || ext == '.avchd' || ext == '.mkv' || ext == '.webm' || ext == '.gif' || ext == '.mp4' || ext == '.ogg' || ext == '.wmv' || ext == '.x-flv' || ext == '.avi') {
								let video_file_path = result_file.path;
								let ext = (result_file.filename).substring((result_file.filename).lastIndexOf('.'), (result_file.filename).length);

								let video = "zktor_video_url_" + crypto.createHash('md5').update('abcdefgh').digest('hex') + Date.now() + ext;
								let path_to_store_generated_width = "../uploads/ztkor_video_media/" + video;
								let cmd = "ffmpeg -i " + video_file_path + " -max_muxing_queue_size 21512512 -vf scale=iw*2:ih*2 -preset slow -crf 40 " + path_to_store_generated_width;
								exec(cmd, (error, stdout, stderr) => {
									if (error) {
										i = 1;
									}
									if (stderr) {}
								});
								// let video1 = "zktor_video_thumbnail_url_" + crypto.createHash('md5').update('abcdefgh').digest('hex') + Date.now() + ".jpg";
								// let path_to_store_generated_thumbnail = "../uploads/ztkor_video_media/" + video1;
								// let sec = 4;
								// let cmd1 = "ffmpeg  -i " + video_file_path + " -vf scale=iw*2:ih*2 -deinterlace -an -ss " + sec + " -t 00:00:01   -r 1 -y -vcodec mjpeg -f mjpeg " + path_to_store_generated_thumbnail + " 2>&1";
								// exec(cmd1, (error, stdout, stderr) => {
								//     if (error) {}
								//     if (stderr) {
								//     }
								// });
								let video2 = "zktor_short_video_url_" + crypto.createHash('md5').update('abcdefgh').digest('hex') + Date.now() + ext;
								let path_to_store_generated_short_video = "../uploads/ztkor_video_media/" + video2;
								let cmd2 = "ffmpeg -i " + video_file_path + " -max_muxing_queue_size 21512512 -vf scale=iw*2:ih*2  -ss 00:01 -to 00:05 -c:v libx264 -crf 40 " + path_to_store_generated_short_video;
								exec(cmd2, (error, stdout, stderr) => {
									if (error) {
										i = 1;
										//  //console.log(`error: ${error.message}`);
										//  return;
									}
									if (stderr) {
										// //console.log(`stderr short video: ${stderr}`);
										// return;
									}
									// //console.log(`stdout: ${stdout}`);
								});
								zktor_video_video_length.push(Math.round(duration));
								if (zktor_video_url_type == '')
									zktor_video_url_type = 'video';
								zktor_video_url.push(define.BASE_URL + "ztkor_video_media/" + video);
								//  zktor_video_thumbnail_url.push("https://softawork1.xyz/uploads/ztkor_video_media/"+video1);
								zktor_short_video_url.push(define.BASE_URL + "ztkor_video_media/" + video2);
							}
							if (idx1 === array1.length - 1) {
								if (i == 0) {
									// //console.log(req.files.zktor_video_thumbnail_url[0]);
									if (typeof req.files.zktor_video_thumbnail_url !== 'undefined') {
										req.body.zktor_video_thumbnail_url = define.BASE_URL + "ztkor_video_media/" + req.files.zktor_video_thumbnail_url[0].filename;
									}
									req.body.zktor_video_url = zktor_video_url.toString();
									//req.body.zktor_video_thumbnail_url = zktor_video_thumbnail_url.toString();
									req.body.zktor_short_video_url = zktor_short_video_url.toString();
									// //console.log(zktor_video_video_length);
									req.body.zktor_video_video_length = zktor_video_video_length.toString();
									//req.body.zktor_video_url_type = zktor_video_url_type;
									db.query(`INSERT INTO tbl_zktor_video SET ?`, req.body, function(error, results, fields) {
										if (error) {
											return res.status(400).send({
												status: 400,
												msg: "fail"
											});
										} else {
											return res.status(200).send({
												status: 200,
												msg: "Success"
											});
										}
									});
								} else {
									return res.status(400).send({
										status: 400,
										msg: "Media file is corrupted "
									});
								}
							}
						});
					});
				} else {
					if (typeof req.files.zktor_video_thumbnail_url !== 'undefined') {
						req.body.zktor_video_thumbnail_url = define.BASE_URL + "ztkor_video_media/" + req.files.zktor_video_thumbnail_url[0].filename;
					}
					db.query(`INSERT INTO tbl_zktor_video SET ?`, req.body, function(error, results, fields) {
						if (error) {
							return res.status(400).send({
								status: 400,
								msg: "fail"
							});
						} else {
							return res.status(200).send({
								status: 200,
								msg: "Success"
							});
						}
					});
				}
			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_wishlist = async (req, res) => {
	try {
	let upload = multer({
		storage: zktor,
	}).single('');
	upload(req, res, function(err) {
		if (err) {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		} else {
			if (req.body.wishlist_zktor_video_id && req.body.wishlist_user_id) {
				db.query(`Select * From tbl_zktor_video_wishlist where wishlist_zktor_video_id= ? and wishlist_user_id=?;`, [req.body.wishlist_zktor_video_id, req.body.wishlist_user_id], function(error, results, fields) {
					if (error) {
						return res.status(400).send({
							status: 400,
							msg: "fail"
						});
					} else {
						if (results.length <= 0) {
							db.query(`INSERT INTO tbl_zktor_video_wishlist SET ?`, [req.body], function(error, results66, fields) {
								if (error) {
									return res.status(400).send({
										status: 400,
										msg: "fail"
									});
								} else {
									return res.status(200).send({
										status: 200,
										msg: "Success"
									});
								}
							});
						} else {

							return res.status(200).send({
								status: 200,
								msg: "Success"
							});
						}
					}
				});

			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_recent = async (req, res) => {
	try {
	let upload = multer({
		storage: zktor,
	}).single('');
	upload(req, res, function(err) {
		if (err) {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		} else {
			if (req.body.recent_zktor_video_id && req.body.recent_user_id) {
				db.query(`Select * From tbl_zktor_video_recent where recent_zktor_video_id= ? and recent_user_id=?;`, [req.body.recent_zktor_video_id, req.body.recent_user_id], function(error, results, fields) {
					if (error) {
						return res.status(400).send({
							status: 400,
							msg: "fail"
						});
					} else {
						if (results.length <= 0) {
							db.query(`INSERT INTO tbl_zktor_video_recent SET ?`, [req.body], function(error, results66, fields) {
								if (error) {
									return res.status(400).send({
										status: 400,
										msg: "fail"
									});
								} else {
									return res.status(200).send({
										status: 200,
										msg: "Success"
									});
								}
							});
						} else {

							return res.status(200).send({
								status: 200,
								msg: "Success"
							});
						}
					}
				});

			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_zktor_video_singer = async (req, res) => {
	try {
	let upload = multer({
		storage: zktor,
	}).single('');
	upload(req, res, function(err) {
		if (err) {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		} else {
			if (req.body.zktor_video_singer_name) {
				db.query(`Select * From tbl_zktor_video_singer where zktor_video_singer_name=?`, [req.body.zktor_video_singer_name], function(error, results, fields) {
					if (error) {
						return res.status(400).send({
							status: 400,
							msg: "fail"
						});
					} else {
						if (results.length <= 0) {
							db.query(`INSERT INTO tbl_zktor_video_singer SET ?`, [req.body], function(error, results66, fields) {
								if (error) {
									return res.status(400).send({
										status: 400,
										msg: "fail"
									});
								} else {
									return res.status(200).send({
										status: 200,
										msg: "Success"
									});
								}
							});
						} else {

							return res.status(200).send({
								status: 200,
								msg: "Success"
							});
						}
					}
				});

			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.report_video = async (req, res) => {
	try {
	let upload = multer({
		storage: zktor,
	}).single('');
	upload(req, res, function(err) {
		if (err) {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		} else {
			if (req.body.zktor_video_id && req.body.zktor_video_report_user_id) {

				db.query(`INSERT INTO tbl_zktor_video_report SET ?`, [req.body], function(error, results66, fields) {
					if (error) {
						return res.status(400).send({
							status: 400,
							msg: "fail"
						});
					} else {
						return res.status(200).send({
							status: 200,
							msg: "Success"
						});
					}
				});


			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_zktor_video_mood = async (req, res) => {
	try {
	let upload = multer({
		storage: zktor,
	}).single('');
	upload(req, res, function(err) {
		if (err) {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		} else {
			if (req.body.zktor_video_mood_name) {
				db.query(`Select * From tbl_zktor_video_mood where zktor_video_mood_name=?`, [req.body.zktor_video_mood_name], function(error, results, fields) {
					if (error) {
						return res.status(400).send({
							status: 400,
							msg: "fail"
						});
					} else {
						if (results.length <= 0) {
							db.query(`INSERT INTO tbl_zktor_video_mood SET ?`, [req.body], function(error, results66, fields) {
								if (error) {
									return res.status(400).send({
										status: 400,
										msg: "fail"
									});
								} else {
									return res.status(200).send({
										status: 200,
										msg: "Success"
									});
								}
							});
						} else {

							return res.status(200).send({
								status: 200,
								msg: "Success"
							});
						}
					}
				});

			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_zktor_video_character = async (req, res) => {
	try {
	let upload = multer({
		storage: zktor,
	}).single('');
	upload(req, res, function(err) {
		if (err) {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		} else {
			if (req.body.zktor_video_character_name) {
				db.query(`Select * From tbl_zktor_video_character where zktor_video_character_name=?`, [req.body.zktor_video_character_name], function(error, results, fields) {
					if (error) {
						return res.status(400).send({
							status: 400,
							msg: "fail"
						});
					} else {
						if (results.length <= 0) {
							db.query(`INSERT INTO tbl_zktor_video_character SET ?`, [req.body], function(error, results66, fields) {
								if (error) {
									return res.status(400).send({
										status: 400,
										msg: "fail"
									});
								} else {
									return res.status(200).send({
										status: 200,
										msg: "Success"
									});
								}
							});
						} else {

							return res.status(200).send({
								status: 200,
								msg: "Success"
							});
						}
					}
				});

			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_zktor_video_era = async (req, res) => {
	try {
	let upload = multer({
		storage: zktor,
	}).single('');
	upload(req, res, function(err) {
		if (err) {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		} else {
			if (req.body.zktor_video_era_name) {
				db.query(`Select * From tbl_zktor_video_era where zktor_video_era_name=?`, [req.body.zktor_video_era_name], function(error, results, fields) {
					if (error) {
						return res.status(400).send({
							status: 400,
							msg: "fail"
						});
					} else {
						if (results.length <= 0) {
							db.query(`INSERT INTO tbl_zktor_video_era SET ?`, [req.body], function(error, results66, fields) {
								if (error) {
									return res.status(400).send({
										status: 400,
										msg: "fail"
									});
								} else {
									return res.status(200).send({
										status: 200,
										msg: "Success"
									});
								}
							});
						} else {

							return res.status(200).send({
								status: 200,
								msg: "Success"
							});
						}
					}
				});

			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_subscriber = async (req, res) => {
	try {
	let upload = multer({
		storage: zktor,
	}).single('');
	upload(req, res, function(err) {
		if (err) {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		} else {
			if (req.body.subscriber_by_user_id && req.body.subscriber_to_user_id) {
				db.query(`Select * From tbl_zktor_video_subscriber where subscriber_by_user_id= ? and subscriber_to_user_id=?;Select * From tbl_user_profile where user_id= ?`, [req.body.subscriber_by_user_id, req.body.subscriber_to_user_id, req.body.subscriber_to_user_id], function(error, results, fields) {
					if (error) {
						return res.status(400).send({
							status: 400,
							msg: "fail"
						});
					} else {
						if (results[0].length <= 0) {
							db.query(`INSERT INTO tbl_zktor_video_subscriber SET ?`, [req.body], function(error, results66, fields) {
								if (error) {
									return res.status(400).send({
										status: 400,
										msg: "fail"
									});
								} else {
									return res.status(200).send({
										status: 200,
										msg: "Success",
										user_channel_id: (results[1].length > 0) ? results[1][0].user_channel_id : ''
									});
								}
							});
						} else {
							if (req.body.status) {
								db.query(`UPDATE tbl_zktor_video_subscriber SET ? where subscriber_by_user_id= ? and subscriber_to_user_id=?`, [{
									status: req.body.status
								}, req.body.subscriber_by_user_id, req.body.subscriber_to_user_id], function(error, results11, fields) {});
							} else if (req.body.bell_icon) {
								db.query(`UPDATE tbl_zktor_video_subscriber SET ? where subscriber_by_user_id= ? and subscriber_to_user_id=?`, [{
									bell_icon: req.body.bell_icon
								}, req.body.subscriber_by_user_id, req.body.subscriber_to_user_id], function(error, results116, fields) {});
							}
							return res.status(200).send({
								status: 200,
								msg: "Success",
								user_channel_id: (results[1].length > 0) ? results[1][0].user_channel_id : ''
							});
						}
					}
				});

			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_zktor_video_folder = async (req, res) => {
	try {
	let upload = multer({
		storage: zktor,
	}).single('');
	upload(req, res, function(err) {
		if (err) {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		} else {
			if (req.body.zktor_video_user_id && req.body.zktor_video_folder_name) {
				db.query(`INSERT INTO tbl_zktor_video_folder SET ?`, [req.body], function(error, results, fields) {
					if (error) {
						return res.status(400).send({
							status: 400,
							msg: "fail"
						});
					} else {
						return res.status(200).send({
							status: 200,
							msg: "Success",
							zktor_video_folder_id: results.insertId
						});
					}
				});

			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.comment_reaction = async (req, res) => {
	try {
	let upload = multer({
		storage: zktor,
	}).single('reply_comment_media');
	upload(req, res, function(err) {
		if (err) {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		} else {
			if (req.body.reaction_user_id && req.body.comment_id) {
				if (req.body.flag == 1) {
					db.query(`SELECT * FROM tbl_zktor_video_comment where comment_id=? and comment_operation=?`, [req.body.comment_id, '0'], function(error, results12, fields) {
						if (error) {
							return res.status(400).send({
								status: 400,
								msg: "fail"
							});
						} else {
							if (results12.length > 0) {
								db.query(`SELECT * FROM tbl_zktor_video_comment_reaction where reaction_comment_id=? and reaction_user_id=?`, [req.body.comment_id, req.body.reaction_user_id], function(error, results_update, fields) {
									if (error) {
										return res.status(400).send({
											status: 400,
											msg: "fail"
										});
									} else {
										if (results_update.length <= 0) {
											delete(req.body.flag);
											req.body.reaction_comment_id = req.body.comment_id;
											delete(req.body.comment_id);
											db.query(`INSERT INTO tbl_zktor_video_comment_reaction SET ?`, req.body, function(error, results, fields) {
												if (error) {
													return res.status(400).send({
														status: 400,
														msg: "fail"
													});
												} else {
													return res.status(200).send({
														status: 200,
														msg: "Success"
													});
												}
											});
										} else {
											db.query(`UPDATE tbl_zktor_video_comment_reaction SET ? where reaction_user_id=? and reaction_comment_id=?`, [{
												comment_feeling_string: req.body.comment_feeling_string
											}, req.body.reaction_user_id, req.body.comment_id], function(error, results, fields) {
												if (error) {
													return res.status(400).send({
														status: 400,
														msg: "fail"
													});
												} else {
													return res.status(200).send({
														status: 200,
														msg: "Success"
													});
												}
											});
										}
									}
								});
							} else {
								return res.status(400).send({
									status: 400,
									msg: "fail"
								});
							}
						}
					});
				} else {
					db.query(`SELECT * FROM tbl_zktor_video_comment where comment_id=? and comment_operation=?`, [req.body.comment_id, '0'], function(error, results12, fields) {
						if (error) {
							return res.status(400).send({
								status: 400,
								msg: "fail"
							});
						} else {
							if (results12.length > 0) {
								db.query(`SELECT * FROM tbl_zktor_video_comment_reaction where reaction_comment_id=? and reaction_user_id=?`, [req.body.comment_id, req.body.reaction_user_id], function(error, results_update, fields) {
									if (error) {
										return res.status(400).send({
											status: 400,
											msg: "fail"
										});
									} else {
										if (results_update.length >= 1) {
											delete(req.body.flag);
											db.query(`DELETE FROM tbl_zktor_video_comment_reaction where reaction_comment_id=? and reaction_user_id=?`, [req.body.comment_id, req.body.reaction_user_id], function(error, results, fields) {
												if (error) {
													return res.status(400).send({
														status: 400,
														msg: "fail"
													});
												} else {
													return res.status(200).send({
														status: 200,
														msg: "Success"
													});
												}
											});
										} else {
											return res.status(400).send({
												status: 400,
												msg: "fail"
											});
										}
									}
								});


							} else {
								return res.status(400).send({
									status: 400,
									msg: "fail"
								});
							}
						}
					});
				}

			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail45"
				});
			}
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.update_zktor_video_comment_reply = async (req, res) => {
	try {
	let upload = multer({
		storage: zktor,
	}).single('reply_comment_media');
	upload(req, res, function(err) {
		if (err) {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		} else {
			if (req.body.comment_reply_id) {
				var comment_reply_id = req.body.comment_reply_id;
				delete(req.body.comment_reply_id);
				var d = '';
				//console.log(req.file);
				if (typeof req.file !== 'undefined') {
					req.body.reply_comment_media = define.BASE_URL + "ztkor_video_media/" + req.file.filename;
					d = define.BASE_URL + "ztkor_video_media/" + req.file.filename;
				}
				db.query(`UPDATE tbl_zktor_video_comment_reply SET ? where comment_reply_id=?;SELECT COUNT(*) AS numrows FROM tbl_zktor_video_comment_reply where comment_id=? and comment_reply_operation != ?`, [req.body, comment_reply_id, req.body.comment_id, '2'], function(error, results, fields) {
					if (error) {
						return res.status(400).send({
							status: 400,
							msg: "fail"
						});
					} else {
						return res.status(200).send({
							status: 200,
							msg: "Success",
							reply_comment_media: d,
							comment_reply_id: results.insertId,
							comment_reply_count: results[1][0].numrows
						});
					}
				});

			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_zktor_video_comment_reply = async (req, res) => {
	try {
	let upload = multer({
		storage: zktor,
	}).single('reply_comment_media');
	upload(req, res, function(err) {
		if (err) {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		} else {
			if (req.body.comment_id) {
				var d = '';
				//console.log(req.file);
				if (typeof req.file !== 'undefined') {
					req.body.reply_comment_media = define.BASE_URL + "ztkor_video_media/" + req.file.filename;
					d = define.BASE_URL + "ztkor_video_media/" + req.file.filename;
				}
				db.query(`INSERT INTO tbl_zktor_video_comment_reply SET ?;SELECT COUNT(*) AS numrows FROM tbl_zktor_video_comment_reply where comment_id=? and comment_reply_operation != ?`, [req.body, req.body.comment_id, '2'], function(error, results, fields) {
					if (error) {
						return res.status(400).send({
							status: 400,
							msg: "fail"
						});
					} else {
						return res.status(200).send({
							status: 200,
							msg: "Success",
							reply_comment_media: d,
							comment_reply_id: results.insertId,
							comment_reply_count: results[1][0].numrows
						});
					}
				});

			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_zktor_video_comment = async (req, res) => {
	try {
	let upload = multer({
		storage: zktor,
	}).single('comment_media');
	upload(req, res, function(err) {
		if (err) {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		} else {
			if (req.body.comment_user_id && req.body.comment_zktor_video_id) {
				var d = '';
				//console.log(req.file);
				if (typeof req.file !== 'undefined') {
					req.body.comment_media = define.BASE_URL + "ztkor_video_media/" + req.file.filename;
					d = define.BASE_URL + "ztkor_video_media/" + req.file.filename;
				}
				db.query(`INSERT INTO tbl_zktor_video_comment SET ?`, [req.body], function(error, results, fields) {
					if (error) {
						return res.status(400).send({
							status: 400,
							msg: "fail"
						});
					} else {
						return res.status(200).send({
							status: 200,
							msg: "Success",
							comment_media: d,
							comment_id: results.insertId
						});
					}
				});

			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.update_zktor_video_comment = async (req, res) => {
	try {
	let upload = multer({
		storage: zktor,
	}).single('comment_media');
	upload(req, res, function(err) {
		if (err) {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		} else {
			if (req.body.comment_id) {
				var d = '';
				var comment_id = req.body.comment_id;
				delete(req.body.comment_id);
				//console.log(req.file);
				if (typeof req.file !== 'undefined') {
					req.body.comment_media = define.BASE_URL + "ztkor_video_media/" + req.file.filename;
					d = define.BASE_URL + "ztkor_video_media/" + req.file.filename;
				}
				db.query(`UPDATE tbl_zktor_video_comment SET ? where comment_id=?`, [req.body, comment_id], function(error, results, fields) {
					if (error) {
						return res.status(400).send({
							status: 400,
							msg: "fail"
						});
					} else {
						return res.status(200).send({
							status: 200,
							msg: "Success",
							comment_media: d
						});
					}
				});

			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.delete_zktor_video_comment = async (req, res) => {
	try {
	if (req.query.comment_id) {
		db.query(`DELETE from tbl_zktor_video_comment where comment_id=?`, [req.query.comment_id], function(error, results1, fields) {
			if (error) throw error;
			return res.status(200).send({
				status: 200,
				msg: "Success"
			});
		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_zktor_video_test = async (req, res) => {
	try {
	if (!req.timedout) {
		setTimeout(function() {
			if (req.query.zktor_video_user_id && req.query.vistor_user_id && req.query.page_no) {
				var no_of_records_per_page = 10;
				var rowno = req.query.page_no;
				if (rowno != 0) {
					rowno = (rowno - 1) * no_of_records_per_page;
				}
				if (!req.query.seed) {
					req.query.seed = 123;
				}
				db.query(`SELECT * FROM tbl_zktor_video ORDER BY RAND(?) LIMIT ? OFFSET ?; SELECT COUNT(*) AS numrows FROM tbl_zktor_video`, [req.query.seed, no_of_records_per_page, rowno], function(error, results, fields) {
					if (error) throw error;
					if (results[0].length > 0) {
						var final_array = [];
						var final_array_one = [];
						var comment = [];
						var rating = 0;
						var rating_count = 0;
						var flag = 2;
						if (results[0].length > 0) {
							const merged = results[0].concat(results[1]);
							//console.log(merged);
							Object.keys(results[0]).forEach(function(key, idx, array) {
								var result_data = results[0][key];
								db.query(`SELECT * FROM tbl_zktor_video_ignore where zktor_video_id=? AND zktor_video_user_id=?;SELECT * FROM tbl_zktor_video_channel_ignore where zktor_video_ignored_by_user_id=? AND zktor_video_ignored_to_user_id=?`, [result_data.zktor_video_id, req.query.zktor_video_user_id, result_data.zktor_video_user_id, req.query.zktor_video_user_id], function(error, results_ignore, fields) {
									if (error) throw error;
									if (results_ignore[0].length <= 0 && results_ignore[1].length <= 0) {

										db.query(`SELECT * FROM tbl_zktor_video_like where zktor_video_user_id=? AND zktor_video_id=?;SELECT * FROM tbl_zktor_video_like where zktor_video_id=? ORDER BY zktor_video_like_id DESC LIMIT 2;SELECT  *  FROM tbl_zktor_video_subscriber where subscriber_to_user_id=? and subscriber_by_user_id=?`, [req.query.zktor_video_user_id, result_data.zktor_video_id, result_data.zktor_video_id, req.query.zktor_video_user_id, req.query.vistor_user_id], function(error, results_rating, fields) {
											if (error) throw error;
											if (results_rating[0].length > 0) {
												result_data.user_reaction = results_rating[0][0].video_feeling_string;
											} else {
												result_data.user_reaction = '';
											}
											if (results_rating[1].length > 0) {
												result_data.first_video_feeling_string = results_rating[1][0].video_feeling_string;
											} else {
												result_data.first_video_feeling_string = '';
											}
											if (results_rating[1].length > 1) {
												result_data.second_video_feeling_string = results_rating[1][1].video_feeling_string;
											} else {
												result_data.second_video_feeling_string = '';
											}

											db.query(`SELECT * FROM tbl_user_profile where user_id=?; SELECT COUNT(*) AS numrows FROM tbl_zktor_video_comment where comment_zktor_video_id=? and comment_operation=?;SELECT * FROM tbl_user_profile where user_id=?;SELECT COUNT(*) AS numrows FROM tbl_zktor_video_wishlist where wishlist_zktor_video_id=? and wishlist_user_id=?`, [result_data.zktor_video_user_id, result_data.zktor_video_id, '0', results_rating[0].zktor_video_user_id, result_data.zktor_video_id, req.query.zktor_video_user_id], function(error, results_comment, fields) {
												if (error) throw error;
												if (results_comment[0].length > 0) {
													result_data.user_name = results_comment[0][0].user_name;
													result_data.user_profile_img = results_comment[0][0].user_profile_img;
													result_data.user_profile_background = results_comment[0][0].user_profile_background;
													result_data.user_channel_id = results_comment[0][0].user_channel_id;
													result_data.user_channel_name = results_comment[0][0].user_channel_name;
												} else {
													result_data.user_name = '';
													result_data.user_profile_img = '';
													result_data.user_profile_background = '';
													result_data.user_channel_id = '';
													result_data.user_channel_name = '';
												}
												if (results_comment[2].length > 0) {
													result_data.last_reacted_user = results_comment[2][0].user_name;
												} else {
													result_data.last_reacted_user = '';
												}
												if (results_comment[3].length > 0) {
													result_data.wishlist_flag = results_comment[3][0].numrows > 0 ? 1 : 0;
												} else {
													result_data.wishlist_flag = 0;
												}
												if (results_rating[2].length > 0) {
													result_data.subscriber_flag = results_rating[2][0].status;
													result_data.bell_icon = results_rating[2][0].bell_icon;
												} else {
													result_data.subscriber_flag = "2";
													result_data.bell_icon = "2";
												}
												result_data.zktor_video_views = result_data.zktor_video_views.toString();
												result_data.zktor_video_like_count = result_data.zktor_video_like_count.toString();
												//result_data.wishlist_flag=result_data.wishlist_flag.toString();
												result_data.zktor_video_id = result_data.zktor_video_id.toString();
												result_data.comment_count = results_comment[1][0].numrows.toString();
												result_data.zktor_video_duration = timeAgo(new Date(result_data.created_date).toISOString());
												final_array.push(result_data);
												if (idx === array.length - 1) {
													let max_pages = parseInt(Math.ceil((results[1][0].numrows) / no_of_records_per_page));
													if (req.query.page_no && req.query.page_no <= max_pages) {
														let page_no = req.query.page_no;
														// PAGINATION START
														let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
														//  let sliceData = final_array.slice(offset, offset + no_of_records_per_page)
														var pagination = {
															total_rows: results[1][0].numrows,
															total_pages: parseInt(Math.ceil((results[1][0].numrows) / no_of_records_per_page)),
															per_page: no_of_records_per_page,
															offset: offset,
															current_page_no: page_no
														};
														return res.status(200).send({
															status: 200,
															msg: "Success",
															zktorVideoListCount: results[1][0].numrows,
															zktorVideoList: final_array,
															pagination: pagination
														});
													} else {
														return res.status(404).send({
															status: 404,
															msg: "Page no missing or Its incorrect."
														});
													}
												}
											});
										});
									}
								});
							});
						} else {
							if (idx === array.length - 1) {
								return res.status(200).send({
									status: 200,
									msg: "Success",
									zktorVideoList: final_array
								});
							}
						}


					} else {
						return res.status(404).send({
							status: 404,
							msg: "Record not found"
						});
					}
				});
			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}
		}, (Math.random() * 70) >>> 0);
	} else {
		return res.status(400).send({
			status: 400,
			msg: "Request timed out"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_zktor_video = async (req, res) => {
	try {
	if (req.query.zktor_video_user_id && req.query.vistor_user_id && req.query.page_no) {
		var no_of_records_per_page = 10;
		var rowno = req.query.page_no;
		if (rowno != 0) {
			rowno = (rowno - 1) * no_of_records_per_page;
		}
		if (!req.query.seed) {
			req.query.seed = 123;
		}
		db.query(`SELECT * FROM tbl_zktor_video ORDER BY RAND(?) LIMIT ? OFFSET ?; SELECT COUNT(*) AS numrows FROM tbl_zktor_video`, [req.query.seed, no_of_records_per_page, rowno], function(error, results, fields) {
			if (error) throw error;
			if (results[0].length > 0) {
				var final_array = [];
				var final_array_one = [];
				var comment = [];
				var rating = 0;
				var rating_count = 0;
				var flag = 2;
				if (results[0].length > 0) {
					const merged = results[0].concat(results[1]);
					//console.log(merged);
					Object.keys(results[0]).forEach(function(key, idx, array) {
						var result_data = results[0][key];
						db.query(`SELECT * FROM tbl_zktor_video_ignore where zktor_video_id=? AND zktor_video_user_id=?;SELECT * FROM tbl_zktor_video_channel_ignore where zktor_video_ignored_by_user_id=? AND zktor_video_ignored_to_user_id=?`, [result_data.zktor_video_id, req.query.zktor_video_user_id, result_data.zktor_video_user_id, req.query.zktor_video_user_id], function(error, results_ignore, fields) {
							if (error) throw error;
							if (results_ignore[0].length <= 0 && results_ignore[1].length <= 0) {

								db.query(`SELECT * FROM tbl_zktor_video_like where zktor_video_user_id=? AND zktor_video_id=?;SELECT * FROM tbl_zktor_video_like where zktor_video_id=? ORDER BY zktor_video_like_id DESC LIMIT 2;SELECT  *  FROM tbl_zktor_video_subscriber where subscriber_to_user_id=? and subscriber_by_user_id=?`, [req.query.zktor_video_user_id, result_data.zktor_video_id, result_data.zktor_video_id, req.query.zktor_video_user_id, req.query.vistor_user_id], function(error, results_rating, fields) {
									if (error) throw error;
									if (results_rating[0].length > 0) {
										result_data.user_reaction = results_rating[0][0].video_feeling_string;
									} else {
										result_data.user_reaction = '';
									}
									if (results_rating[1].length > 0) {
										result_data.first_video_feeling_string = results_rating[1][0].video_feeling_string;
									} else {
										result_data.first_video_feeling_string = '';
									}
									if (results_rating[1].length > 1) {
										result_data.second_video_feeling_string = results_rating[1][1].video_feeling_string;
									} else {
										result_data.second_video_feeling_string = '';
									}

									db.query(`SELECT * FROM tbl_user_profile where user_id=?; SELECT COUNT(*) AS numrows FROM tbl_zktor_video_comment where comment_zktor_video_id=? and comment_operation=?;SELECT * FROM tbl_user_profile where user_id=?;SELECT COUNT(*) AS numrows FROM tbl_zktor_video_wishlist where wishlist_zktor_video_id=? and wishlist_user_id=?`, [result_data.zktor_video_user_id, result_data.zktor_video_id, '0', results_rating[0].zktor_video_user_id, result_data.zktor_video_id, req.query.zktor_video_user_id], function(error, results_comment, fields) {
										if (error) throw error;
										if (results_comment[0].length > 0) {
											result_data.user_name = results_comment[0][0].user_name;
											result_data.user_profile_img = results_comment[0][0].user_profile_img;
											result_data.user_profile_background = results_comment[0][0].user_profile_background;
											result_data.user_channel_id = results_comment[0][0].user_channel_id;
											result_data.user_channel_name = results_comment[0][0].user_channel_name;
										} else {
											result_data.user_name = '';
											result_data.user_profile_img = '';
											result_data.user_profile_background = '';
											result_data.user_channel_id = '';
											result_data.user_channel_name = '';
										}
										if (results_comment[2].length > 0) {
											result_data.last_reacted_user = results_comment[2][0].user_name;
										} else {
											result_data.last_reacted_user = '';
										}
										if (results_comment[3].length > 0) {
											result_data.wishlist_flag = results_comment[3][0].numrows > 0 ? 1 : 0;
										} else {
											result_data.wishlist_flag = 0;
										}
										if (results_rating[2].length > 0) {
											result_data.subscriber_flag = results_rating[2][0].status;
											result_data.bell_icon = results_rating[2][0].bell_icon;
										} else {
											result_data.subscriber_flag = "2";
											result_data.bell_icon = "2";
										}
										result_data.zktor_video_views = result_data.zktor_video_views.toString();
										result_data.zktor_video_like_count = result_data.zktor_video_like_count.toString();
										//result_data.wishlist_flag=result_data.wishlist_flag.toString();
										result_data.zktor_video_id = result_data.zktor_video_id.toString();
										result_data.comment_count = results_comment[1][0].numrows.toString();
										result_data.zktor_video_duration = timeAgo(new Date(result_data.created_date).toISOString());
										final_array.push(result_data);
										if (idx === array.length - 1) {
											let max_pages = parseInt(Math.ceil((results[1][0].numrows) / no_of_records_per_page));
											if (req.query.page_no && req.query.page_no <= max_pages) {
												let page_no = req.query.page_no;
												// PAGINATION START
												let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
												//  let sliceData = final_array.slice(offset, offset + no_of_records_per_page)
												var pagination = {
													total_rows: results[1][0].numrows,
													total_pages: parseInt(Math.ceil((results[1][0].numrows) / no_of_records_per_page)),
													per_page: no_of_records_per_page,
													offset: offset,
													current_page_no: page_no
												};
												return res.status(200).send({
													status: 200,
													msg: "Success",
													zktorVideoListCount: results[1][0].numrows,
													zktorVideoList: final_array,
													pagination: pagination
												});
											} else {
												return res.status(404).send({
													status: 404,
													msg: "Page no missing or Its incorrect."
												});
											}
										}
									});
								});
							}
						});
					});
				} else {
					if (idx === array.length - 1) {
						return res.status(200).send({
							status: 200,
							msg: "Success",
							zktorVideoList: final_array
						});
					}
				}


			} else {
				return res.status(404).send({
					status: 404,
					msg: "Record not found"
				});
			}
		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.video_channel_detail = async (req, res) => {
	try {
	if (req.query.user_id) {
		var final_array = [];
		db.query(`SELECT SUM(zktor_video_views) as zktor_video_views,SUM(zktor_video_like_count) as zktor_video_like_count FROM tbl_zktor_video where zktor_video_user_id=?;SELECT * FROM tbl_user_profile where user_id=?;SELECT  COUNT(*) AS numrows  FROM tbl_zktor_video_subscriber where subscriber_to_user_id=? and status=?`, [req.query.user_id, req.query.user_id, req.query.user_id, '1'], function(error, results_comment, fields) {
			if (error) throw error;
			else {
				if (results_comment[1].length > 0) {
					final_array.push({
						user_id: results_comment[1][0].user_id,
						user_name: results_comment[1][0].user_name,
						user_profile_img: results_comment[1][0].user_profile_img,
						user_profile_background: results_comment[1][0].user_profile_background,
						user_channel_name: results_comment[1][0].user_channel_name,
						user_channel_description: results_comment[1][0].user_channel_description,
						user_email: results_comment[1][0].user_email,
						user_address: results_comment[1][0].user_address,
						user_website: results_comment[1][0].user_website,
						created_date: results_comment[1][0].created_date,
						total_view_count: results_comment[0][0].zktor_video_views != null ? results_comment[0][0].zktor_video_views.toString() : "0",
						total_like_count: results_comment[0][0].zktor_video_like_count != null ? results_comment[0][0].zktor_video_like_count.toString() : "0",
						subscriber_count: results_comment[2][0].numrows.toString()
					});
				} else {
					final_array.push({
						user_name: '',
						user_profile_img: '',
						user_profile_background: '',
						user_channel_name: '',
						user_channel_description: '',
						user_email: '',
						user_address: '',
						user_website: '',
						created_date: '',
						total_view_count: results_comment[0][0].zktor_video_views != null ? results_comment[0][0].zktor_video_views.toString() : "0",
						total_like_count: results_comment[0][0].zktor_video_like_count != null ? results_comment[0][0].zktor_video_like_count.toString() : "0",
						subscriber_count: results_comment[2][0].numrows.toString()
					});

				}
				return res.status(200).send({
					status: 200,
					msg: "Success",
					ChanneDetaillList: final_array[0]
				});
			}
		});

	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}

	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_All_search_data = async (req, res) => {
	try {
	if (req.query.user_id) {

		db.query(`SELECT zktor_video_id,zktor_video_category_id,zktor_video_user_id,zktor_video_video_length,zktor_video_views,zktor_short_video_url,zktor_video_language,zktor_video_title,zktor_video_thumbnail_url,zktor_video_character,zktor_video_singer,zktor_video_mood,zktor_video_era,created_date FROM tbl_zktor_video `, function(error, results, fields) {
			if (error) throw error;
			if (results.length > 0) {
				var final_array = [];
				var final_array_one = [];
				var comment = [];
				var rating = 0;
				var rating_count = 0;
				var flag = 2;
				if (results.length > 0) {
					Object.keys(results).forEach(function(key, idx, array) {
						var result_data = results[key];
						db.query(`SELECT * FROM tbl_zktor_video_ignore where zktor_video_id=? AND zktor_video_user_id=?;SELECT * FROM tbl_zktor_video_channel_ignore where zktor_video_ignored_by_user_id=? AND zktor_video_ignored_to_user_id=?`, [result_data.zktor_video_id, req.query.zktor_video_user_id, result_data.zktor_video_user_id, req.query.zktor_video_user_id], function(error, results_ignore, fields) {
							if (error) throw error;
							if (results_ignore[0].length <= 0 && results_ignore[1].length <= 0) {


								db.query(`SELECT * FROM tbl_user_profile where user_id=?`, [result_data.zktor_video_user_id], function(error, results_comment, fields) {
									if (error) throw error;

									if (results_comment.length > 0) {
										result_data.user_name = results_comment[0].user_name;
										result_data.user_profile_img = results_comment[0].user_profile_img;

									} else {
										result_data.user_name = '';
										result_data.user_profile_img = '';

									}

									result_data.zktor_video_views = result_data.zktor_video_views.toString();
									//   result_data.zktor_video_like_count=result_data.zktor_video_like_count.toString();
									//     result_data.wishlist_flag=result_data.wishlist_flag.toString();
									result_data.zktor_video_id = result_data.zktor_video_id.toString();
									// result_data.comment_count = results_comment[1][0].numrows.toString();
									// result_data.zktor_video_category_name = (results_comment[1].length > 0) ? results_comment[1][0].zktor_video_category_name : '';
									result_data.zktor_video_duration = timeAgo(new Date(result_data.created_date).toISOString());
									delete(result_data.created_date);
									final_array.push(result_data);
									if (idx === array.length - 1) {
										return res.status(200).send({
											status: 200,
											msg: "Success",
											searchList: final_array
										});
									}
								});
							}
						});
					});


				} else {
					if (idx === array.length - 1) {
						return res.status(200).send({
							status: 200,
							msg: "Success",
							searchList: final_array
						});
					}
				}


			} else {
				return res.status(404).send({
					status: 404,
					msg: "Record not found"
				});
			}
		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_zktor_video_with_id = async (req, res) => {
	try {
	if (req.query.zktor_video_id && req.query.zktor_video_user_id) {

		db.query(`SELECT * FROM tbl_zktor_video where zktor_video_id=?`, [req.query.zktor_video_id], function(error, results, fields) {
			if (error) throw error;
			if (results.length > 0) {
				var final_array = [];
				var final_array_one = [];
				var comment = [];
				var rating = 0;
				var rating_count = 0;
				var flag = 2;
				if (results.length > 0) {
					const merged = results.concat(results[1]);
					//console.log(merged);
					Object.keys(results).forEach(function(key, idx, array) {
						var result_data = results[key];
						db.query(`SELECT * FROM tbl_zktor_video_ignore where zktor_video_id=? AND zktor_video_user_id=?;SELECT * FROM tbl_zktor_video_channel_ignore where zktor_video_ignored_by_user_id=? AND zktor_video_ignored_to_user_id=?`, [result_data.zktor_video_id, req.query.zktor_video_user_id, result_data.zktor_video_user_id, req.query.zktor_video_user_id], function(error, results_ignore, fields) {
							if (error) throw error;
							if (results_ignore[0].length <= 0 && results_ignore[1].length <= 0) {

								db.query(`SELECT * FROM tbl_zktor_video_like where zktor_video_user_id=? AND zktor_video_id=?;SELECT * FROM tbl_zktor_video_like where zktor_video_id=? ORDER BY zktor_video_like_id DESC LIMIT 2;SELECT  *  FROM tbl_zktor_video_subscriber where subscriber_to_user_id=? and subscriber_by_user_id=?;SELECT  *  FROM tbl_zktor_video_folder where zktor_video_folder_id=?`, [req.query.zktor_video_user_id, result_data.zktor_video_id, result_data.zktor_video_id, req.query.zktor_video_user_id, req.query.vistor_user_id, result_data.zktor_video_folder_id], function(error, results_rating, fields) {
									if (error) throw error;
									var user = 0;
									if (results_rating[0].length > 0) {
										result_data.user_reaction = results_rating[0][0].video_feeling_string;
									} else {
										result_data.user_reaction = '';
									}
									if (results_rating[1].length > 0) {
										user = results_rating[1][0].zktor_video_user_id;
										result_data.first_video_feeling_string = results_rating[1][0].video_feeling_string;
									} else {
										result_data.first_video_feeling_string = '';
									}
									if (results_rating[1].length > 1) {
										result_data.second_video_feeling_string = results_rating[1][1].video_feeling_string;
									} else {
										result_data.second_video_feeling_string = '';
									}

									db.query(`SELECT * FROM tbl_user_profile where user_id=?; SELECT * FROM tbl_zktor_video_category where zktor_video_category_id=?;SELECT * FROM tbl_user_profile where user_id=?;SELECT COUNT(*) AS numrows FROM tbl_zktor_video_wishlist where wishlist_zktor_video_id=? and wishlist_user_id=?`, [result_data.zktor_video_user_id, result_data.zktor_video_category_id, user, result_data.zktor_video_id, req.query.zktor_video_user_id], function(error, results_comment, fields) {
										if (error) throw error;

										if (results_comment[0].length > 0) {
											result_data.user_name = results_comment[0][0].user_name;
											result_data.user_profile_img = results_comment[0][0].user_profile_img;
											result_data.user_profile_background = results_comment[0][0].user_profile_background;
											result_data.user_channel_id = results_comment[0][0].user_channel_id;
											result_data.user_channel_name = results_comment[0][0].user_channel_name;
										} else {
											result_data.user_name = '';
											result_data.user_profile_img = '';
											result_data.user_profile_background = '';
											result_data.user_channel_id = '';
											result_data.user_channel_name = '';
										}
										if (results_comment[2].length > 0) {
											result_data.last_reacted_user = results_comment[2][0].user_name;
										} else {
											result_data.last_reacted_user = '';
										}
										if (results_comment[3].length > 0) {
											result_data.wishlist_flag = results_comment[3][0].numrows > 0 ? 1 : 0;
										} else {
											result_data.wishlist_flag = 0;
										}
										if (results_rating[2].length > 0) {
											result_data.subscriber_flag = results_rating[2][0].status;
											result_data.bell_icon = results_rating[2][0].bell_icon;
										} else {
											result_data.subscriber_flag = "2";
											result_data.bell_icon = "2";
										}
										result_data.zktor_video_views = result_data.zktor_video_views.toString();
										result_data.zktor_video_like_count = result_data.zktor_video_like_count.toString();
										//result_data.wishlist_flag=result_data.wishlist_flag.toString();
										result_data.zktor_video_id = result_data.zktor_video_id.toString();
										// result_data.comment_count = results_comment[1][0].numrows.toString();
										result_data.zktor_video_category_name = (results_comment[1].length > 0) ? results_comment[1][0].zktor_video_category_name : '';
										result_data.zktor_video_duration = timeAgo(new Date(result_data.created_date).toISOString());
										final_array.push(result_data);
										if (idx === array.length - 1) {
											return res.status(200).send({
												status: 200,
												msg: "Success",
												zktorVideoDetails: final_array
											});
										}
									});
								});
							}
						});
					});
				} else {
					if (idx === array.length - 1) {
						return res.status(200).send({
							status: 200,
							msg: "Success",
							zktorVideoList: final_array
						});
					}
				}


			} else {
				return res.status(404).send({
					status: 404,
					msg: "Record not found"
				});
			}
		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_zktor_video_category = async (req, res) => {
	try {
	var pagination = [];
	if (req.query.page_no) {
		var no_of_records_per_page = 10;
		var rowno = req.query.page_no;
		if (rowno != 0) {
			rowno = (rowno - 1) * no_of_records_per_page;
		}
		var comment = [];
		db.query(`SELECT * FROM tbl_zktor_video_category LIMIT ? OFFSET ?;SELECT COUNT(*) AS numrows FROM tbl_zktor_video_category`, [no_of_records_per_page, rowno], function(error, results_comment, fields) {
			if (error) throw error;
			if (results_comment[0].length > 0) {
				Object.keys(results_comment[0]).forEach(function(key12, idx12, array12) {
					var results_comment_data = results_comment[0][key12];
					comment.push(results_comment_data);
					if (idx12 === array12.length - 1) {
						let max_pages = parseInt(Math.ceil((results_comment[1][0].numrows) / no_of_records_per_page));
						if (req.query.page_no && req.query.page_no <= max_pages) {
							let page_no = req.query.page_no;
							// PAGINATION START
							let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
							//  let sliceData = final_array.slice(offset, offset + no_of_records_per_page)
							var pagination = {
								total_rows: results_comment[1][0].numrows,
								total_pages: parseInt(Math.ceil((results_comment[1][0].numrows) / no_of_records_per_page)),
								per_page: no_of_records_per_page,
								offset: offset,
								current_page_no: page_no
							};
							return res.status(200).send({
								status: 200,
								msg: "Success",
								zktorVideoCategoryListCount: results_comment[1][0].numrows,
								zktorVideoCategoryList: comment,
								pagination: pagination
							});
						} else {
							return res.status(404).send({
								status: 404,
								msg: "Page no missing or Its incorrect."
							});
						}
					}

				});
			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}
		});

	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}

	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_zktor_video_category_without_pagination = async (req, res) => {
	try {
	var comment = [];
	db.query(`SELECT * FROM tbl_zktor_video_category`, function(error, results_comment, fields) {
		if (error) throw error;
		if (results_comment.length > 0) {

			return res.status(200).send({
				status: 200,
				msg: "Success",
				zktorVideoCategoryListCount: results_comment.length,
				zktorVideoCategoryList: results_comment
			});

		} else {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.delete_zktor_video_comment = async (req, res) => {
	try {
	if (req.query.comment_id) {
		db.query(`DELETE from tbl_zktor_video_comment where comment_id=?`, [req.query.comment_id], function(error, results1, fields) {
			if (error) throw error;
			return res.status(200).send({
				status: 200,
				msg: "Success"
			});
		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.ztkor_video_list_with_user_id = async (req, res) => {
	try {
	    if (req.query.zktor_video_user_id && req.query.vistor_user_id && req.query.page_no) {
        var no_of_records_per_page = 10;
        var rowno = req.query.page_no;
        if (rowno != 0) {
            rowno = (rowno - 1) * no_of_records_per_page;
        }
        db.query(`SELECT * FROM tbl_zktor_video where zktor_video_user_id=? LIMIT ? OFFSET ?; SELECT COUNT(*) AS numrows FROM tbl_zktor_video where zktor_video_user_id=?;SELECT  *  FROM tbl_zktor_video_subscriber where subscriber_to_user_id=? and subscriber_by_user_id=?;SELECT  COUNT(*) AS numrows  FROM tbl_zktor_video_subscriber where subscriber_to_user_id=? and status=?;SELECT * FROM tbl_user_profile where user_id=?`, [req.query.zktor_video_user_id, no_of_records_per_page, rowno, req.query.zktor_video_user_id, req.query.zktor_video_user_id, req.query.vistor_user_id, req.query.zktor_video_user_id, '1', req.query.zktor_video_user_id], function(error, results, fields) {
            if (error) throw error;
            if (results[0].length > 0) {
                var final_array = [];
                var final_array_one = [];
                var comment = [];
                var rating = 0;
                var rating_count = 0;
                var flag = 2;
                if (results[0].length > 0) {
                    const merged = results[0].concat(results[1]);

                    Object.keys(results[0]).forEach(function(key, idx, array) {
                        var result_data = results[0][key];

                        db.query(`SELECT * FROM tbl_zktor_video_ignore where zktor_video_id=? AND zktor_video_user_id=?;SELECT * FROM tbl_zktor_video_channel_ignore where zktor_video_ignored_by_user_id=? AND zktor_video_ignored_to_user_id=?;SELECT * FROM tbl_zktor_video_category where zktor_video_category_id=? ;`, [result_data.zktor_video_id, req.query.zktor_video_user_id, result_data.zktor_video_user_id, req.query.zktor_video_user_id,result_data.zktor_video_category_id], function(error, results_ignore, fields) {
                            if (error) throw error;
                            if (results_ignore[0].length <= 0 && results_ignore[1].length <= 0) {

                                db.query(`SELECT * FROM tbl_zktor_video_like where zktor_video_user_id=? AND zktor_video_id=?;SELECT * FROM tbl_zktor_video_like where zktor_video_id=? ORDER BY zktor_video_like_id DESC LIMIT 2;SELECT  *  FROM tbl_zktor_video_subscriber where subscriber_to_user_id=? and subscriber_by_user_id=?;SELECT  *  FROM tbl_zktor_video_folder where zktor_video_folder_id=?`, [req.query.zktor_video_user_id, result_data.zktor_video_id, result_data.zktor_video_id, req.query.zktor_video_user_id, req.query.vistor_user_id, result_data.zktor_video_folder_id], function(error, results_rating, fields) {
                                    if (error) throw error;
                                    var user = 0;
                                    if (results_rating[0].length > 0) {
                                        result_data.user_reaction = results_rating[0][0].video_feeling_string;
                                    } else {
                                        result_data.user_reaction = '';
                                    }
                                    if (results_rating[1].length > 0) {
                                        user = results_rating[1][0].zktor_video_user_id;
                                        result_data.first_video_feeling_string = results_rating[1][0].video_feeling_string;
                                    } else {
                                        result_data.first_video_feeling_string = '';
                                    }
                                    if (results_rating[1].length > 1) {
                                        result_data.second_video_feeling_string = results_rating[1][1].video_feeling_string;
                                    } else {
                                        result_data.second_video_feeling_string = '';
                                    }
                                    if (results_rating[3].length > 0) {
                                        result_data.folder_details = results_rating[3][0];
                                    } else {
                                        result_data.folder_details = '';
                                    }
                                       if (results_ignore[2].length > 0) {
                                        result_data.zktor_video_category_name = results_ignore[2][0].zktor_video_category_name;
                                    } else {
                                        result_data.zktor_video_category_name = '';
                                    }
                                    db.query(`SELECT * FROM tbl_user_profile where user_id=?; SELECT COUNT(*) AS numrows FROM tbl_zktor_video_comment where comment_zktor_video_id=? and comment_operation=?;SELECT * FROM tbl_user_profile where user_id=?;SELECT COUNT(*) AS numrows FROM tbl_zktor_video_wishlist where wishlist_zktor_video_id=? and wishlist_user_id=?`, [result_data.zktor_video_user_id, result_data.zktor_video_id, '0', user, result_data.zktor_video_id, req.query.zktor_video_user_id], function(error, results_comment, fields) {
                                        if (error) throw error;
                                        if (results_comment[0].length > 0) {
                                            result_data.user_name = results_comment[0][0].user_name;
                                            result_data.user_profile_img = results_comment[0][0].user_profile_img;
                                            result_data.user_profile_background = results_comment[0][0].user_profile_background;
                                            result_data.user_channel_id = results_comment[0][0].user_channel_id;
                                            result_data.user_channel_name = results_comment[0][0].user_channel_name;
                                        } else {
                                            result_data.user_name = '';
                                            result_data.user_profile_img = '';
                                            result_data.user_profile_background = '';
                                            result_data.user_channel_id = '';
                                            result_data.user_channel_name = '';
                                        }
                                        if (results_comment[2].length > 0) {
                                            result_data.last_reacted_user = results_comment[2][0].user_name;
                                        } else {
                                            result_data.last_reacted_user = '';
                                        }
                                        if (results_comment[3].length > 0) {
                                            result_data.wishlist_flag = results_comment[3][0].numrows > 0 ? 1 : 0;
                                        } else {
                                            result_data.wishlist_flag = 0;
                                        }
                                        if (results_rating[2].length > 0) {
                                            //result_data.subscriber_flag = results_rating[2][0].status;
                                            result_data.bell_icon = results_rating[2][0].bell_icon;
                                        } else {
                                            //result_data.subscriber_flag = "2";
                                            result_data.bell_icon = "2";
                                        }
                                        result_data.zktor_video_views = result_data.zktor_video_views.toString();
                                        result_data.zktor_video_like_count = result_data.zktor_video_like_count.toString();
                                        //  result_data.wishlist_flag=result_data.wishlist_flag.toString();
                                        result_data.zktor_video_id = result_data.zktor_video_id.toString();
                                        // result_data.comment_count = results_comment[1][0].numrows.toString();
                                        //result_data.comment_count = results_comment[1][0].numrows;
                                        result_data.zktor_video_duration = timeAgo(new Date(result_data.created_date).toISOString());
                                        final_array.push(result_data);
                                        if (idx === array.length - 1) {
                                            //console.log(final_array);
                                            let max_pages = parseInt(Math.ceil((results[1][0].numrows) / no_of_records_per_page));
                                            if (req.query.page_no && req.query.page_no <= max_pages && final_array.length > 0) {
                                                let page_no = req.query.page_no;
                                                // PAGINATION START
                                                let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
                                                //  let sliceData = final_array.slice(offset, offset + no_of_records_per_page)
                                                var pagination = {
                                                    total_rows: results[1][0].numrows,
                                                    total_pages: parseInt(Math.ceil((results[1][0].numrows) / no_of_records_per_page)),
                                                    per_page: no_of_records_per_page,
                                                    offset: offset,
                                                    current_page_no: page_no
                                                };
                                                return res.status(200).send({
                                                    status: 200,
                                                    msg: "Success",
                                                    subscriber_count: results[3][0].numrows,
                                                    "user_name": results[4][0].user_name,
                                                    "user_profile_img": results[4][0].user_profile_img,
                                                    "user_profile_background": results[4][0].user_profile_background,
                                                    "user_channel_id": results[4][0].user_channel_id,
                                                    "user_channel_name": results[4][0].user_channel_name,
                                                    bell_icon: (results[2].length > 0) ? results[2][0].bell_icon : "2",
                                                    subscriber_flag: (results[2].length > 0) ? results[2][0].status : "2",
                                                    //  zktorVideoListCount: results[1][0].numrows,
                                                    zktorVideoList: final_array,
                                                    pagination: pagination
                                                });
                                            } else {
                                                return res.status(404).send({
                                                    status: 404,
                                                    msg: "Page no missing or Its incorrect.",
                                                   subscriber_count: results[3][0].numrows,
                      	"user_name":(results[4].length>0) ? results[4][0].user_name : '',
					"user_profile_img": (results[4].length>0) ? results[4][0].user_profile_img : '',
					"user_profile_background": (results[4].length>0) ? results[4][0].user_profile_background : '',
					"user_channel_id": (results[4].length>0) ? results[4][0].user_channel_id : '',
					"user_channel_name": (results[4].length>0) ? results[4][0].user_channel_name : '',
                        bell_icon: (results[2].length > 0) ? results[2][0].bell_icon : "2",
                        subscriber_flag: (results[2].length > 0) ? results[2][0].status : "2",
                                                    zktorVideoList: [],
                                                    pagination: {
                                                        "total_rows": 0,
                                                        "total_pages": 0,
                                                        "per_page": 0,
                                                        "current_page_no": "0"
                                                    }
                                                });
                                            }
                                        }
                                    });
                                });
                            }
                        });
                    });
                } else {
                    if (idx === array.length - 1) {
                        return res.status(404).send({
                            status: 404,
                            msg: "fail",
                            subscriber_count: results[3][0].numrows,
                        "user_name": results[4][0].user_name,
                        "user_profile_img": results[4][0].user_profile_img,
                        "user_profile_background": results[4][0].user_profile_background,
                        "user_channel_id": results[4][0].user_channel_id,
                        "user_channel_name": results[4][0].user_channel_name,
                        bell_icon: (results[2].length > 0) ? results[2][0].bell_icon : "2",
                        subscriber_flag: (results[2].length > 0) ? results[2][0].status : "2",
                            zktorVideoList: [],
                            pagination: {
                                "total_rows": 0,
                                "total_pages": 0,
                                "per_page": 0,
                                "current_page_no": "0"
                            }

                        });
                    }
                }


            } else {
          
                return res.status(404).send({
                        status: 404,
                        msg: "Record not found",
                        subscriber_count: results[3][0].numrows,
                        "user_name": results[4][0].user_name,
                        "user_profile_img": results[4][0].user_profile_img,
                        "user_profile_background": results[4][0].user_profile_background,
                        "user_channel_id": results[4][0].user_channel_id,
                        "user_channel_name": results[4][0].user_channel_name,
                        bell_icon: (results[2].length > 0) ? results[2][0].bell_icon : "2",
                        subscriber_flag: (results[2].length > 0) ? results[2][0].status : "2",
                        //  zktorVideoListCount: results[1][0].numrows,
                        zktorVideoList: [],
                        pagination: {
                            "total_rows": 0,
                            "total_pages": 0,
                            "per_page": 0,
                            "current_page_no": "0"
                        }
                    });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
            subscriber_count: 0,
            "user_name": '',
            "user_profile_img": '',
            "user_profile_background": '',
            "user_channel_id": '',
            "user_channel_name": '',
            bell_icon: "2",
            subscriber_flag: "2",
            //  zktorVideoListCount: results[1][0].numrows,
            zktorVideoList: [],
            pagination: {
                "total_rows": 0,
                "total_pages": 0,
                "per_page": 0,
                "current_page_no": "0"
            }
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.ztkor_video_list_with_folder_id = async (req, res) => {
	try {
	if (req.query.zktor_video_folder_id && req.query.page_no) {
		var no_of_records_per_page = 10;
		var rowno = req.query.page_no;
		if (rowno != 0) {
			rowno = (rowno - 1) * no_of_records_per_page;
		}
		db.query(`SELECT * FROM tbl_zktor_video where zktor_video_folder_id=? LIMIT ? OFFSET ?; SELECT COUNT(*) AS numrows FROM tbl_zktor_video where zktor_video_folder_id=?`, [req.query.zktor_video_folder_id, no_of_records_per_page, rowno, req.query.zktor_video_folder_id], function(error, results, fields) {
			if (error) throw error;
			if (results[0].length > 0) {
				var final_array = [];
				var final_array_one = [];
				var comment = [];
				var rating = 0;
				var rating_count = 0;
				var flag = 2;
				if (results[0].length > 0) {
					const merged = results[0].concat(results[1]);
					//console.log(merged);
					Object.keys(results[0]).forEach(function(key, idx, array) {
						var result_data = results[0][key];
					 db.query(`SELECT * FROM tbl_zktor_video_ignore where zktor_video_id=? AND zktor_video_user_id=?;SELECT * FROM tbl_zktor_video_channel_ignore where zktor_video_ignored_by_user_id=? AND zktor_video_ignored_to_user_id=?;SELECT * FROM tbl_zktor_video_category where zktor_video_category_id=? ;`, [result_data.zktor_video_id, req.query.zktor_video_user_id, result_data.zktor_video_user_id, req.query.zktor_video_user_id,result_data.zktor_video_category_id], function(error, results_ignore, fields) {
                            if (error) throw error;
                            if (results_ignore[0].length <= 0 && results_ignore[1].length <= 0) {

                                db.query(`SELECT * FROM tbl_zktor_video_like where zktor_video_user_id=? AND zktor_video_id=?;SELECT * FROM tbl_zktor_video_like where zktor_video_id=? ORDER BY zktor_video_like_id DESC LIMIT 2;SELECT  *  FROM tbl_zktor_video_subscriber where subscriber_to_user_id=? and subscriber_by_user_id=?;SELECT  *  FROM tbl_zktor_video_folder where zktor_video_folder_id=?`, [req.query.zktor_video_user_id, result_data.zktor_video_id, result_data.zktor_video_id, req.query.zktor_video_user_id, req.query.vistor_user_id, result_data.zktor_video_folder_id], function(error, results_rating, fields) {
                                    if (error) throw error;
                                    var user = 0;
                                    if (results_rating[0].length > 0) {
                                        result_data.user_reaction = results_rating[0][0].video_feeling_string;
                                    } else {
                                        result_data.user_reaction = '';
                                    }
                                    if (results_rating[1].length > 0) {
                                        user = results_rating[1][0].zktor_video_user_id;
                                        result_data.first_video_feeling_string = results_rating[1][0].video_feeling_string;
                                    } else {
                                        result_data.first_video_feeling_string = '';
                                    }
                                    if (results_rating[1].length > 1) {
                                        result_data.second_video_feeling_string = results_rating[1][1].video_feeling_string;
                                    } else {
                                        result_data.second_video_feeling_string = '';
                                    }
                                    if (results_rating[3].length > 0) {
                                        result_data.folder_details = results_rating[3][0];
                                    } else {
                                        result_data.folder_details = '';
                                    }
                                       if (results_ignore[2].length > 0) {
                                        result_data.zktor_video_category_name = results_ignore[2][0].zktor_video_category_name;
                                    } else {
                                        result_data.zktor_video_category_name = '';
                                    }
									db.query(`SELECT * FROM tbl_user_profile where user_id=?; SELECT COUNT(*) AS numrows FROM tbl_zktor_video_comment where comment_zktor_video_id=? and comment_operation=?;SELECT * FROM tbl_user_profile where user_id=?;SELECT COUNT(*) AS numrows FROM tbl_zktor_video_wishlist where wishlist_zktor_video_id=? and wishlist_user_id=?`, [result_data.zktor_video_user_id, result_data.zktor_video_id, '0', user, result_data.zktor_video_id, req.query.zktor_video_user_id], function(error, results_comment, fields) {
										if (error) throw error;
										if (results_comment[0].length > 0) {
											result_data.user_name = results_comment[0][0].user_name;
											result_data.user_profile_img = results_comment[0][0].user_profile_img;
											result_data.user_profile_background = results_comment[0][0].user_profile_background;
											result_data.user_channel_id = results_comment[0][0].user_channel_id;
											result_data.user_channel_name = results_comment[0][0].user_channel_name;
										} else {
											result_data.user_name = '';
											result_data.user_profile_img = '';
											result_data.user_profile_background = '';
											result_data.user_channel_id = '';
											result_data.user_channel_name = '';
										}
										if (results_comment[2].length > 0) {
											result_data.last_reacted_user = results_comment[2][0].user_name;
										} else {
											result_data.last_reacted_user = '';
										}
										if (results_comment[3].length > 0) {
											result_data.wishlist_flag = results_comment[3][0].numrows > 0 ? 1 : 0;
										} else {
											result_data.wishlist_flag = 0;
										}
										if (results_rating[2].length > 0) {
											//   result_data.subscriber_flag = results_rating[2][0].status;
											result_data.bell_icon = results_rating[2][0].bell_icon;
										} else {
											// result_data.subscriber_flag = "2";
											result_data.bell_icon = "2";
										}
										result_data.zktor_video_views = result_data.zktor_video_views.toString();
										result_data.zktor_video_like_count = result_data.zktor_video_like_count.toString();
										//  result_data.wishlist_flag=result_data.wishlist_flag.toString();
										result_data.zktor_video_id = result_data.zktor_video_id.toString();
										//    result_data.comment_count = results_comment[1][0].numrows.toString();
										// result_data.comment_count = results_comment[1][0].numrows;
										result_data.zktor_video_duration = timeAgo(new Date(result_data.created_date).toISOString());
										final_array.push(result_data);
										if (idx === array.length - 1) {
											let max_pages = parseInt(Math.ceil((results[1][0].numrows) / no_of_records_per_page));
											if (req.query.page_no && req.query.page_no <= max_pages) {
												let page_no = req.query.page_no;
												// PAGINATION START
												let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
												//  let sliceData = final_array.slice(offset, offset + no_of_records_per_page)
												var pagination = {
													total_rows: results[1][0].numrows,
													total_pages: parseInt(Math.ceil((results[1][0].numrows) / no_of_records_per_page)),
													per_page: no_of_records_per_page,
													offset: offset,
													current_page_no: page_no
												};
												return res.status(200).send({
													status: 200,
													msg: "Success",
													//zktorVideoListCount: results[1][0].numrows,
													zktorVideoList: final_array,
													pagination: pagination
												});
											} else {
												return res.status(404).send({
													status: 404,
													msg: "Page no missing or Its incorrect."
												});
											}
										}
									});
								});
							}
						});
					});
				} else {
					if (idx === array.length - 1) {
						return res.status(200).send({
							status: 200,
							msg: "Success",
							zktorVideoList: final_array
						});
					}
				}


			} else {
				return res.status(404).send({
					status: 404,
					msg: "Record not found"
				});
			}
		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_zktor_video_character = async (req, res) => {
	try {
	var comment = [];
	db.query(`SELECT * FROM tbl_zktor_video_character`, function(error, results_comment, fields) {
		if (error) throw error;
		if (results_comment.length > 0) {

			return res.status(200).send({
				status: 200,
				msg: "Success",
				zktorCharacterListCount: results_comment.length,
				zktorCharacterList: results_comment
			});

		} else {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_zktor_video_era = async (req, res) => {
	try {
	var comment = [];
	db.query(`SELECT * FROM tbl_zktor_video_era`, function(error, results_comment, fields) {
		if (error) throw error;
		if (results_comment.length > 0) {
			return res.status(200).send({
				status: 200,
				msg: "Success",
				zktorEraListCount: results_comment.length,
				zktorEraList: results_comment
			});
		} else {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_zktor_video_mood = async (req, res) => {
	try {
	var comment = [];
	db.query(`SELECT * FROM tbl_zktor_video_mood`, function(error, results_comment, fields) {
		if (error) throw error;
		if (results_comment.length > 0) {

			return res.status(200).send({
				status: 200,
				msg: "Success",
				zktorMoodListCount: results_comment.length,
				zktorMoodList: results_comment
			});

		} else {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_zktor_video_search = async (req, res) => {
	try {
	if (req.query.zktor_video_category_id && req.query.page_no) {
		var no_of_records_per_page = 10;
		var rowno = req.query.page_no;
		if (rowno != 0) {
			rowno = (rowno - 1) * no_of_records_per_page;
		}
		var swl = "SELECT * FROM tbl_zktor_video where zktor_video_category_id=" + req.query.zktor_video_category_id;
		var swl1 = "SELECT COUNT(*) AS numrows FROM tbl_zktor_video where zktor_video_category_id=" + req.query.zktor_video_category_id;
		if (req.query.zktor_video_character && req.query.zktor_video_character != '') {
			var totalfriendsList = req.query.zktor_video_character.split(',');
			var kl = ' ';
			totalfriendsList.forEach((element, index, array) => {

				kl = kl + " " + "OR zktor_video_character LIKE " + "'%" + element + "%'";
				if (index === array.length - 1) {
					swl = swl + " " + kl;
					swl1 = swl1 + " " + kl;
				}
			});
		}
		if (req.query.zktor_video_singer && req.query.zktor_video_singer != '') {
			var totalfriendsList = req.query.zktor_video_singer.split(',');
			var kl = ' ';
			totalfriendsList.forEach((element, index, array) => {
				kl = kl + " " + "OR zktor_video_singer LIKE " + "'%" + element + "%'";
				if (index === array.length - 1) {
					swl = swl + " " + kl;
					swl1 = swl1 + " " + kl;
				}
			});
		}
		if (req.query.zktor_video_mood && req.query.zktor_video_mood != '') {
			var totalfriendsList = req.query.zktor_video_mood.split(',');
			var kl = ' ';
			totalfriendsList.forEach((element, index, array) => {
				kl = kl + " " + "OR zktor_video_mood LIKE " + "'%" + element + "%'";
				if (index === array.length - 1) {
					swl = swl + " " + kl;
					swl1 = swl1 + " " + kl;
				}
			});
		}
		if (req.query.zktor_video_era && req.query.zktor_video_era != '') {
			var totalfriendsList = req.query.zktor_video_era.split(',');
			var kl = ' ';
			totalfriendsList.forEach((element, index, array) => {
				kl = kl + " " + "OR zktor_video_era LIKE " + "'%" + element + "%'";
				if (index === array.length - 1) {
					swl = swl + " " + kl;
					swl1 = swl1 + " " + kl;
				}
			});
		}
		var me = swl + " order by zktor_video_id desc  LIMIT ? OFFSET ? ";
		var me1 = swl1 + "  ";
		var klm = me + ";" + me1;
		db.query(klm, [no_of_records_per_page, rowno], function(error, results, fields) {
			if (error) throw error;
			if (results[0].length > 0) {
				var final_array = [];
				var final_array_one = [];
				var comment = [];
				var rating = 0;
				var rating_count = 0;
				var flag = 2;
				if (results[0].length > 0) {
					const merged = results[0].concat(results[1]);
					//console.log(merged);
					Object.keys(results[0]).forEach(function(key, idx, array) {
						var result_data = results[0][key];
						db.query(`SELECT * FROM tbl_zktor_video_ignore where zktor_video_id=? AND zktor_video_user_id=?;SELECT * FROM tbl_zktor_video_channel_ignore where zktor_video_ignored_by_user_id=? AND zktor_video_ignored_to_user_id=?;SELECT * FROM tbl_user_profile where user_id=?`, [result_data.zktor_video_id, req.query.zktor_video_user_id, result_data.zktor_video_user_id, req.query.zktor_video_user_id, req.query.zktor_video_user_id], function(error, results_ignore, fields) {
							if (error) throw error;
							//    if (results_ignore[0].length <= 0 && results_ignore[1].length <= 0) {

							db.query(`SELECT * FROM tbl_zktor_video_like where zktor_video_user_id=? AND zktor_video_id=?;SELECT * FROM tbl_zktor_video_like where zktor_video_id=? ORDER BY zktor_video_like_id DESC LIMIT 2;SELECT  *  FROM tbl_zktor_video_subscriber where subscriber_to_user_id=? and subscriber_by_user_id=?`, [req.query.zktor_video_user_id, result_data.zktor_video_id, result_data.zktor_video_id, req.query.zktor_video_user_id, req.query.vistor_user_id], function(error, results_rating, fields) {
								if (error) throw error;
								var user = 0;
								if (results_rating[0].length > 0) {
									result_data.user_reaction = results_rating[0][0].video_feeling_string;
								} else {
									result_data.user_reaction = '';
								}
								if (results_rating[1].length > 0) {
									user = results_rating[1][0].zktor_video_user_id;
									result_data.first_video_feeling_string = results_rating[1][0].video_feeling_string;
								} else {
									result_data.first_video_feeling_string = '';
								}
								if (results_rating[1].length > 1) {
									result_data.second_video_feeling_string = results_rating[1][1].video_feeling_string;
								} else {
									result_data.second_video_feeling_string = '';
								}

								db.query(`SELECT * FROM tbl_user_profile where user_id=?; SELECT * FROM tbl_zktor_video_category where zktor_video_category_id=?;SELECT * FROM tbl_user_profile where user_id=?;SELECT COUNT(*) AS numrows FROM tbl_zktor_video_wishlist where wishlist_zktor_video_id=? and wishlist_user_id=?`, [result_data.zktor_video_user_id, result_data.zktor_video_category_id, user, result_data.zktor_video_id, req.query.zktor_video_user_id], function(error, results_comment, fields) {
									if (error) throw error;

									if (results_comment[0].length > 0) {
										result_data.user_name = results_comment[0][0].user_name;
										result_data.user_profile_img = results_comment[0][0].user_profile_img;
										result_data.user_profile_background = results_comment[0][0].user_profile_background;
										result_data.user_channel_id = results_comment[0][0].user_channel_id;
										result_data.user_channel_name = results_comment[0][0].user_channel_name;
									} else {
										result_data.user_name = '';
										result_data.user_profile_img = '';
										result_data.user_profile_background = '';
										result_data.user_channel_id = '';
										result_data.user_channel_name = '';
									}
									if (results_comment[2].length > 0) {
										result_data.last_reacted_user = results_comment[2][0].user_name;
									} else {
										result_data.last_reacted_user = '';
									}
									if (results_comment[3].length > 0) {
										result_data.wishlist_flag = results_comment[3][0].numrows > 0 ? 1 : 0;
									} else {
										result_data.wishlist_flag = 0;
									}
									if (results_rating[2].length > 0) {
										result_data.subscriber_flag = results_rating[2][0].status;
										result_data.bell_icon = results_rating[2][0].bell_icon;
									} else {
										result_data.subscriber_flag = "2";
										result_data.bell_icon = "2";
									}
									result_data.zktor_video_category_name = (results_comment[1].length > 0) ? results_comment[1][0].zktor_video_category_name : '';
									result_data.zktor_video_duration = timeAgo(new Date(result_data.created_date).toISOString());
									if (results_ignore[0].length <= 0 && results_ignore[1].length <= 0) {
										final_array.push(result_data);
									}
									// //console.log(final_array);
									if (idx === array.length - 1) {
										let max_pages = parseInt(Math.ceil((results[1][0].numrows) / no_of_records_per_page));
										if (req.query.page_no && req.query.page_no <= max_pages) {
											let page_no = req.query.page_no;
											// PAGINATION START
											let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
											//  let sliceData = final_array.slice(offset, offset + no_of_records_per_page)
											var pagination = {
												total_rows: results[1][0].numrows,
												total_pages: parseInt(Math.ceil((results[1][0].numrows) / no_of_records_per_page)),
												per_page: no_of_records_per_page,
												offset: offset,
												current_page_no: page_no
											};
											return res.status(200).send({
												status: 200,
												msg: "Success",
												zktorVideoSearchListCount: results[1][0].numrows,
												zktorVideoSearchList: final_array,
												pagination: pagination
											});
										} else {
											return res.status(404).send({
												status: 404,
												msg: "Page no missing or Its incorrect."
											});
										}
									}
								});
							});

						});
					});
				} else {
					if (idx === array.length - 1) {
						return res.status(200).send({
							status: 200,
							msg: "Success",
							zktorVideoSearchList: final_array
						});
					}
				}
			} else {
				return res.status(404).send({
					status: 404,
					msg: "Record not found"
				});
			}
		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.video_search = async (req, res) => {
	try {
	if (req.query.string) {
		var kl = "%" + req.query.string + "%";
		db.query(`SELECT * FROM tbl_zktor_video where zktor_video_character LIKE ? OR zktor_video_singer LIKE ? OR zktor_video_mood LIKE ? OR zktor_video_era LIKE ? OR zktor_video_title LIKE ?`, [kl, kl, kl, kl, kl], function(error, results, fields) {
			if (error) throw error;
			if (results.length > 0) {
				var final_array = [];
				var final_array_one = [];
				var comment = [];
				var rating = 0;
				var rating_count = 0;
				var flag = 2;
				if (results.length > 0) {

					Object.keys(results).forEach(function(key, idx, array) {
						var result_data = results[key];
						db.query(`SELECT * FROM tbl_zktor_video_ignore where zktor_video_id=? AND zktor_video_user_id=?;SELECT * FROM tbl_zktor_video_channel_ignore where zktor_video_ignored_by_user_id=? AND zktor_video_ignored_to_user_id=?;SELECT * FROM tbl_user_profile where user_id=?`, [result_data.zktor_video_id, req.query.zktor_video_user_id, result_data.zktor_video_user_id, req.query.zktor_video_user_id, req.query.zktor_video_user_id], function(error, results_ignore, fields) {
							if (error) throw error;
							if (results_ignore[0].length <= 0 && results_ignore[1].length <= 0) {

								db.query(`SELECT * FROM tbl_zktor_video_like where zktor_video_user_id=? AND zktor_video_id=?;SELECT * FROM tbl_zktor_video_like where zktor_video_id=? ORDER BY zktor_video_like_id DESC LIMIT 2;SELECT  *  FROM tbl_zktor_video_subscriber where subscriber_to_user_id=? and subscriber_by_user_id=?`, [req.query.zktor_video_user_id, result_data.zktor_video_id, result_data.zktor_video_id, req.query.zktor_video_user_id, req.query.vistor_user_id], function(error, results_rating, fields) {
									if (error) throw error;
									var user = 0;
									if (results_rating[0].length > 0) {
										result_data.user_reaction = results_rating[0][0].video_feeling_string;
									} else {
										result_data.user_reaction = '';
									}
									if (results_rating[1].length > 0) {
										user = results_rating[1][0].zktor_video_user_id;
										result_data.first_video_feeling_string = results_rating[1][0].video_feeling_string;
									} else {
										result_data.first_video_feeling_string = '';
									}
									if (results_rating[1].length > 1) {
										result_data.second_video_feeling_string = results_rating[1][1].video_feeling_string;
									} else {
										result_data.second_video_feeling_string = '';
									}

									db.query(`SELECT * FROM tbl_user_profile where user_id=?; SELECT * FROM tbl_zktor_video_category where zktor_video_category_id=?;SELECT * FROM tbl_user_profile where user_id=?;SELECT COUNT(*) AS numrows FROM tbl_zktor_video_wishlist where wishlist_zktor_video_id=? and wishlist_user_id=?`, [result_data.zktor_video_user_id, result_data.zktor_video_category_id, user, result_data.zktor_video_id, req.query.zktor_video_user_id], function(error, results_comment, fields) {
										if (error) throw error;

										if (results_comment[0].length > 0) {
											result_data.user_name = results_comment[0][0].user_name;
											result_data.user_profile_img = results_comment[0][0].user_profile_img;
											result_data.user_profile_background = results_comment[0][0].user_profile_background;
											result_data.user_channel_id = results_comment[0][0].user_channel_id;
											result_data.user_channel_name = results_comment[0][0].user_channel_name;
										} else {
											result_data.user_name = '';
											result_data.user_profile_img = '';
											result_data.user_profile_background = '';
											result_data.user_channel_id = '';
											result_data.user_channel_name = '';
										}
										if (results_comment[2].length > 0) {
											result_data.last_reacted_user = results_comment[2][0].user_name;
										} else {
											result_data.last_reacted_user = '';
										}
										if (results_comment[3].length > 0) {
											result_data.wishlist_flag = results_comment[3][0].numrows > 0 ? 1 : 0;
										} else {
											result_data.wishlist_flag = 0;
										}
										if (results_rating[2].length > 0) {
											result_data.subscriber_flag = results_rating[2][0].status;
											result_data.bell_icon = results_rating[2][0].bell_icon;
										} else {
											result_data.subscriber_flag = "2";
											result_data.bell_icon = "2";
										}
										result_data.zktor_video_category_name = (results_comment[1].length > 0) ? results_comment[1][0].zktor_video_category_name : '';
										result_data.zktor_video_duration = timeAgo(new Date(result_data.created_date).toISOString());
										final_array.push(result_data);
										if (idx === array.length - 1) {
											return res.status(200).send({
												status: 200,
												msg: "Success",
												zktorVideoSearchCount: final_array.length,
												zktorVideoSearch: final_array
											});
										}
									});
								});
							}
						});
					});
				} else {
					if (idx === array.length - 1) {
						return res.status(200).send({
							status: 200,
							msg: "Success",
							zktorVideoSearch: final_array
						});
					}
				}


			} else {
				return res.status(404).send({
					status: 404,
					msg: "Record not found"
				});
			}
		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.delete_folder = async (req, res) => {
	try {
	if (req.query.zktor_video_folder_id) {
		db.query(`DELETE from tbl_zktor_video_folder where zktor_video_folder_id=?`, [req.query.zktor_video_folder_id], function(error, results1, fields) {
			if (error) throw error;
			db.query(`UPDATE tbl_zktor_video SET ?`, [{
				zktor_video_folder_id: 0
			}], function(error, results1, fields) {
				if (error) throw error;
				return res.status(200).send({
					status: 200,
					msg: "Success"
				});
			});
		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.zktor_video_like = async (req, res) => {
	try {
	if (req.query.zktor_video_user_id && req.query.zktor_video_id) {
		db.query(`select * From tbl_zktor_video_like where zktor_video_user_id= ? and zktor_video_id=?; select * From tbl_zktor_video where zktor_video_id= ?`, [req.query.zktor_video_user_id, req.query.zktor_video_id, req.query.zktor_video_id], function(error, results, fields) {
			if (error) {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			} else {
				if (req.query.flag == 1) {
					if (results[0].length <= 0) {
						if (results[1].length > 0) {
							var count = results[1][0].zktor_video_like_count + 1;
							var d = {
								zktor_video_like_count: count
							};
							db.query(`UPDATE tbl_zktor_video SET ? where zktor_video_id= ?`, [d, req.query.zktor_video_id], function(error, results_update, fields) {
								if (error) {

								} else {}
							});
							delete(req.query.flag);
							db.query(`INSERT INTO tbl_zktor_video_like SET ?`, req.query, function(error, results, fields) {
								if (error) {
									return res.status(400).send({
										status: 400,
										msg: "fail"
									});
								} else {
									return res.status(200).send({
										status: 200,
										msg: "Success",
										likeCount: count
									});
								}
							});
						} else {
							return res.status(400).send({
								status: 400,
								msg: 'fail'
							});
						}
					} else {
						return res.status(200).send({
							status: 200,
							msg: "Success",
							likeCount: (results[1].length > 0) ? results[1][0].zktor_video_like_count : 0
						});
					}
				} else {
					if (results[1].length > 0) {
						var count = 0;
						if (results[1][0].zktor_video_like_count > 0) {
							count = results[1][0].zktor_video_like_count - 1;
						}
						var d = {
							zktor_video_like_count: count
						};
						db.query(`UPDATE tbl_zktor_video SET ? where zktor_video_id= ?`, [d, req.query.zktor_video_id], function(error, results_update, fields) {
							if (error) {

							} else {}
						});
						db.query(`DELETE from tbl_zktor_video_like where zktor_video_id=? and zktor_video_user_id = ?`, [req.query.zktor_video_id, req.query.zktor_video_user_id], function(error, results, fields) {
							if (error) {
								return res.status(400).send({
									status: 400,
									msg: "fail"
								});
							} else {
								return res.status(200).send({
									status: 200,
									msg: "Success",
									likeCount: count
								});
							}
						});

					} else {
						return res.status(400).send({
							status: 400,
							msg: 'fail'
						});
					}
				}
			}
		});

	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}

	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.video_view = async (req, res) => {
	try {
	if (req.query.zktor_video_id) {
		db.query(` select * From tbl_zktor_video where zktor_video_id= ?`, [req.query.zktor_video_id], function(error, results, fields) {
			if (error) {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			} else {
				if (results.length > 0) {
					var count = results[0].zktor_video_views + 1;
					var d = {
						zktor_video_views: count
					};
					db.query(`UPDATE tbl_zktor_video SET ? where zktor_video_id= ?`, [d, req.query.zktor_video_id], function(error, results_update, fields) {
						if (error) {
							return res.status(400).send({
								status: 400,
								msg: "fail"
							});
						} else {
							return res.status(200).send({
								status: 200,
								msg: "Success",
								viewCount: count
							});
						}
					});
				} else {
					return res.status(200).send({
						status: 200,
						msg: "Success",
						viewCount: (results[0].length > 0) ? results[0].zktor_video_view_count : 0
					});
				}
			}
		});

	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}

	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_zktor_video_mood_type = async (req, res) => {
	try {
	if (req.query.zktor_video_type) {
		var kl = "%" + req.query.zktor_video_type + "%";
		db.query(`SELECT * FROM tbl_zktor_video_mood where zktor_video_type like ?;SELECT * FROM tbl_zktor_video_category where zktor_video_category_name=?`, [kl, req.query.zktor_video_type], function(error, results_comment, fields) {
			if (error) {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			} else {
				if (results_comment[0].length > 0) {
					var d = '';
					if (results_comment[1].length > 0) {
						d = (results_comment[1][0].zktor_video_category_id).toString();
					}
					return res.status(200).send({
						status: 200,
						msg: "Success",
						category_id: d,
						moodListCount: results_comment[0].length,
						moodList: results_comment[0]
					});

				} else {
					return res.status(400).send({
						status: 400,
						msg: "fail"
					});
				}
			}
		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_zktor_video_singer = async (req, res) => {
	try {
	var comment = [];
	db.query(`SELECT * FROM tbl_zktor_video_singer`, function(error, results_comment, fields) {
		if (error) throw error;
		if (results_comment.length > 0) {

			return res.status(200).send({
				status: 200,
				msg: "Success",
				zktorSingerListCount: results_comment.length,
				zktorSingerList: results_comment
			});

		} else {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_zktor_video_rated = async (req, res) => {
	try {
	var comment = [];
	db.query(`SELECT * FROM tbl_zktor_video_rated`, function(error, results_comment, fields) {
		if (error) throw error;
		if (results_comment.length > 0) {

			return res.status(200).send({
				status: 200,
				msg: "Success",
				zktorRatedListCount: results_comment.length,
				zktorRatedList: results_comment
			});

		} else {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_zktor_video_language = async (req, res) => {
	try {
	var comment = [];
	db.query(`SELECT * FROM tbl_zktor_video_language`, function(error, results_comment, fields) {
		if (error) throw error;
		if (results_comment.length > 0) {

			return res.status(200).send({
				status: 200,
				msg: "Success",
				zktorLanguageListCount: results_comment.length,
				zktorLanguageList: results_comment
			});

		} else {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_zktor_video_content = async (req, res) => {
	try {
	var comment = [];
	db.query(`SELECT * FROM tbl_zktor_video_content`, function(error, results_comment, fields) {
		if (error) throw error;
		if (results_comment.length > 0) {

			return res.status(200).send({
				status: 200,
				msg: "Success",
				zktorContentListCount: results_comment.length,
				zktorContentList: results_comment
			});
		} else {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.delete_zktor_video = async (req, res) => {
	try {
	if (req.query.zktor_video_id) {
		db.query(`DELETE from tbl_zktor_video where zktor_video_id=?`, [req.query.zktor_video_id], function(error, results1, fields) {
			if (error) throw error;
			return res.status(200).send({
				status: 200,
				msg: "Success"
			});
		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_user_subscriber = async (req, res) => {
	try {
	if (req.query.user_id) {
		var final_array = [];
		db.query(`SELECT * FROM tbl_zktor_video_subscriber where subscriber_to_user_id=? AND status=?;SELECT * FROM tbl_user_profile where user_id=?;SELECT  COUNT(*) AS numrows  FROM tbl_zktor_video_subscriber where subscriber_to_user_id=? and status=?`, [req.query.user_id, '1', req.query.user_id, req.query.user_id, '1'], function(error, results, fields) {
			if (error) throw error;
			else {
				if (results[0].length > 0) {
					Object.keys(results[0]).forEach(function(key, idx, array) {
						var result_data = results[0][key];
						db.query(`SELECT SUM(zktor_video_views) as zktor_video_views,SUM(zktor_video_like_count) as zktor_video_like_count FROM tbl_zktor_video where zktor_video_user_id=?;SELECT * FROM tbl_user_profile where user_id=?;SELECT  COUNT(*) AS numrows  FROM tbl_zktor_video_subscriber where subscriber_to_user_id=? and status=?`, [result_data.subscriber_to_user_id, result_data.subscriber_by_user_id, result_data.subscriber_by_user_id, '1'], function(error, results_comment1, fields) {
							if (error) throw error;
							else {

								if (results_comment1.length > 0) {

									result_data.user_name = results_comment1[1][0].user_name;
									result_data.user_profile_img = results_comment1[1][0].user_profile_img;
									result_data.user_profile_background = results_comment1[1][0].user_profile_background;
									result_data.user_channel_name = results_comment1[1][0].user_channel_name;
									result_data.user_channel_id = results_comment1[1][0].user_channel_id;
									result_data.user_id = results_comment1[1][0].user_id;
									//result_data.user_address = results_comment1[1][0].user_address;
									//result_data.user_website = results_comment1[1][0].user_website;
									result_data.created_date = results_comment1[1][0].created_date;
									// result_data.total_view_count = results_comment1[0][0].zktor_video_views;
									// result_data.total_like_count = results_comment1[0][0].zktor_video_like_count;
									result_data.subscriber_count = results_comment1[2][0].numrows;

								} else {

									result_data.user_name = '';
									result_data.user_profile_img = '';
									result_data.user_profile_background = '';
									result_data.user_channel_name = '';
									result_data.user_channel_id = '';
									result_data.user_id = '';
									//result_data.user_address = '';
									//result_data.user_website = '';
									result_data.created_date = '';
									// result_data.total_view_count = results_comment1[0][0].zktor_video_views;
									// result_data.total_like_count = results_comment1[0][0].zktor_video_like_count;
									result_data.subscriber_count = results_comment1[2][0].numrows;

								}
								final_array.push(result_data);
								if (idx === array.length - 1) {
									return res.status(200).send({
										status: 200,
										msg: "Success",
										subscriber_count: results[2][0].numrows,
										user_name: (results[1].length > 0) ? results[1][0].user_name : '',
										user_profile_img: (results[1].length > 0) ? results[1][0].user_profile_img : '',
										subscriberVideoList: final_array
									});
								}
							}
						});
					});
				} else {
					return res.status(400).send({
						status: 400,
						msg: "fail"
					});
				}
			}
		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}

	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_wishlist = async (req, res) => {
	try {
	if (req.query.user_id && req.query.page_no) {
		var no_of_records_per_page = 10;
		var rowno = req.query.page_no;
		if (rowno != 0) {
			rowno = (rowno - 1) * no_of_records_per_page;
		}
		db.query(`SELECT * FROM tbl_zktor_video_wishlist inner join tbl_zktor_video ON tbl_zktor_video_wishlist.wishlist_zktor_video_id=tbl_zktor_video.zktor_video_id where tbl_zktor_video_wishlist.wishlist_user_id=? LIMIT ? OFFSET ?; SELECT COUNT(*) AS numrows FROM tbl_zktor_video_wishlist inner join tbl_zktor_video ON tbl_zktor_video_wishlist.wishlist_zktor_video_id=tbl_zktor_video.zktor_video_id where tbl_zktor_video_wishlist.wishlist_user_id=?`, [req.query.user_id, no_of_records_per_page, rowno, req.query.user_id], function(error, results, fields) {
			if (error) throw error;
			if (results[0].length > 0) {
				var final_array = [];
				var final_array_one = [];
				var comment = [];
				var rating = 0;
				var rating_count = 0;
				var flag = 2;
				if (results[0].length > 0) {
					const merged = results[0].concat(results[1]);
					//console.log(merged);
					Object.keys(results[0]).forEach(function(key, idx, array) {
						var result_data = results[0][key];
						db.query(`SELECT * FROM tbl_zktor_video where zktor_video_id=?`, [result_data.wishlist_zktor_video_id], function(error, results_ignore, fields) {
							if (error) throw error;
							if (results_ignore.length > 0) {

								db.query(`SELECT * FROM tbl_zktor_video_like where zktor_video_user_id=? AND zktor_video_id=?;SELECT * FROM tbl_zktor_video_like where zktor_video_id=? ORDER BY zktor_video_like_id DESC LIMIT 2;SELECT  *  FROM tbl_zktor_video_subscriber where subscriber_to_user_id=? and subscriber_by_user_id=?;SELECT  *  FROM tbl_zktor_video_folder where zktor_video_folder_id=?`, [req.query.zktor_video_user_id, result_data.zktor_video_id, result_data.zktor_video_id, req.query.zktor_video_user_id, req.query.vistor_user_id, result_data.zktor_video_folder_id], function(error, results_rating, fields) {
									if (error) throw error;
									var user = 0;
									if (results_rating[0].length > 0) {
										result_data.user_reaction = results_rating[0][0].video_feeling_string;
									} else {
										result_data.user_reaction = '';
									}
									if (results_rating[1].length > 0) {
										user = results_rating[1][0].zktor_video_user_id;
										result_data.first_video_feeling_string = results_rating[1][0].video_feeling_string;
									} else {
										result_data.first_video_feeling_string = '';
									}
									if (results_rating[1].length > 1) {
										result_data.second_video_feeling_string = results_rating[1][1].video_feeling_string;
									} else {
										result_data.second_video_feeling_string = '';
									}
									if (results_rating[3].length > 0) {
										result_data.folder_details = results_rating[3][0];
									} else {
										result_data.folder_details = '';
									}
									db.query(`SELECT * FROM tbl_user_profile where user_id=?; SELECT COUNT(*) AS numrows FROM tbl_zktor_video_comment where comment_zktor_video_id=? and comment_operation=?;SELECT * FROM tbl_user_profile where user_id=?;SELECT COUNT(*) AS numrows FROM tbl_zktor_video_wishlist where wishlist_zktor_video_id=? and wishlist_user_id=?`, [result_data.zktor_video_user_id, result_data.zktor_video_id, '0', user, result_data.zktor_video_id, req.query.zktor_video_user_id], function(error, results_comment, fields) {
										if (error) throw error;
										if (results_comment[0].length > 0) {
											result_data.user_name = results_comment[0][0].user_name;
											result_data.user_profile_img = results_comment[0][0].user_profile_img;
											result_data.user_profile_background = results_comment[0][0].user_profile_background;
											result_data.user_channel_id = results_comment[0][0].user_channel_id;
											result_data.user_channel_name = results_comment[0][0].user_channel_name;
										} else {
											result_data.user_name = '';
											result_data.user_profile_img = '';
											result_data.user_profile_background = '';
											result_data.user_channel_id = '';
											result_data.user_channel_name = '';
										}
										if (results_comment[2].length > 0) {
											result_data.last_reacted_user = results_comment[2][0].user_name;
										} else {
											result_data.last_reacted_user = '';
										}
										// if (results_comment[3].length > 0) {
										//     result_data.wishlist_flag = results_comment[3][0].numrows > 0 ? 1 : 0;
										// } else {
										//     result_data.wishlist_flag = 0;
										// }
										// if (results_rating[2].length > 0) {
										//     result_data.subscriber_flag = results_rating[2][0].status;
										//     result_data.bell_icon = results_rating[2][0].bell_icon;
										// } else {
										//     result_data.subscriber_flag = "2";
										//     result_data.bell_icon = "2";
										// }
										if (results_rating[3].length > 0) {
											result_data.folder_details = results_rating[3][0];

										} else {
											result_data.folder_details = [];
										}

										delete(result_data.wishlist_zktor_video_id);
										delete(result_data.wishlist_user_id);
										db.query(`SELECT * FROM tbl_zktor_video_ignore where zktor_video_id=? AND zktor_video_user_id=?;SELECT * FROM tbl_zktor_video_channel_ignore where zktor_video_ignored_by_user_id=? AND zktor_video_ignored_to_user_id=?`, [results_ignore[0].zktor_video_id, req.query.zktor_video_user_id, results_ignore[0].zktor_video_user_id, req.query.zktor_video_user_id], function(error, results_ignore_in, fields) {
											if (error) throw error;
											if (results_ignore_in[0].length <= 0 && results_ignore_in[1].length <= 0) {

												db.query(`SELECT * FROM tbl_zktor_video_like where zktor_video_user_id=? AND zktor_video_id=?;SELECT * FROM tbl_zktor_video_like where zktor_video_id=? ORDER BY zktor_video_like_id DESC LIMIT 2;SELECT  *  FROM tbl_zktor_video_subscriber where subscriber_to_user_id=? and subscriber_by_user_id=?;SELECT  *  FROM tbl_zktor_video_folder where zktor_video_folder_id=?`, [req.query.zktor_video_user_id, results_ignore[0].zktor_video_id, results_ignore[0].zktor_video_id, req.query.zktor_video_user_id, req.query.vistor_user_id, results_ignore[0].zktor_video_folder_id], function(error, results_rating_in, fields) {
													if (error) throw error;
													var user = 0;
													// if (results_rating_in[0].length > 0) {
													//     results_ignore[0].user_reaction = results_rating_in[0][0].video_feeling_string;
													// } else {
													//     results_ignore[0].user_reaction = '';
													// }
													if (results_rating_in[1].length > 0) {
														user = results_rating_in[1][0].zktor_video_user_id;
														results_ignore[0].first_video_feeling_string = results_rating_in[1][0].video_feeling_string;
													} else {
														results_ignore[0].first_video_feeling_string = '';
													}
													if (results_rating_in[1].length > 1) {
														results_ignore[0].second_video_feeling_string = results_rating_in[1][1].video_feeling_string;
													} else {
														results_ignore[0].second_video_feeling_string = '';
													}

													db.query(`SELECT * FROM tbl_user_profile where user_id=?; SELECT * FROM tbl_zktor_video_category where zktor_video_category_id=?;SELECT * FROM tbl_user_profile where user_id=?;SELECT COUNT(*) AS numrows FROM tbl_zktor_video_wishlist where wishlist_zktor_video_id=? and wishlist_user_id=?`, [results_ignore[0].zktor_video_user_id, results_ignore[0].zktor_video_category_id, user, results_ignore[0].zktor_video_id, req.query.zktor_video_user_id], function(error, results_comment_in, fields) {
														if (error) throw error;

														if (results_comment_in[0].length > 0) {
															results_ignore[0].user_name = results_comment_in[0][0].user_name;
															results_ignore[0].user_profile_img = results_comment_in[0][0].user_profile_img;
															results_ignore[0].user_profile_background = results_comment_in[0][0].user_profile_background;
															results_ignore[0].user_channel_id = results_comment_in[0][0].user_channel_id;
															results_ignore[0].user_channel_name = results_comment_in[0][0].user_channel_name;
														} else {
															results_ignore[0].user_name = '';
															results_ignore[0].user_profile_img = '';
															results_ignore[0].user_profile_background = '';
															results_ignore[0].user_channel_id = '';
															results_ignore[0].user_channel_name = '';
														}
														if (results_comment_in[2].length > 0) {
															results_ignore[0].last_reacted_user = results_comment_in[2][0].user_name;
														} else {
															results_ignore[0].last_reacted_user = '';
														}
														// if (results_comment_in[3].length > 0) {
														//     results_ignore[0].wishlist_flag = results_comment_in[3][0].numrows > 0 ? 1 : 0;
														// } else {
														//     results_ignore[0].wishlist_flag = 0;
														// }
														if (results_rating_in[2].length > 0) {
															//results_ignore[0].subscriber_flag = results_rating_in[2][0].status;
															results_ignore[0].bell_icon = results_rating_in[2][0].bell_icon;
														} else {
															//[0].subscriber_flag = "2";
															results_ignore[0].bell_icon = "2";
														}
														result_data.zktor_video_views = result_data.zktor_video_views.toString();
														result_data.zktor_video_like_count = result_data.zktor_video_like_count.toString();
														result_data.zktor_video_id = result_data.zktor_video_id.toString();

														results_ignore[0].zktor_video_views = results_ignore[0].zktor_video_views.toString();
														results_ignore[0].zktor_video_like_count = results_ignore[0].zktor_video_like_count.toString();
														results_ignore[0].zktor_video_id = results_ignore[0].zktor_video_id.toString();

														// result_data.comment_count = results_comment[1][0].numrows.toString();
														results_ignore[0].zktor_video_category_name = (results_comment_in[1].length > 0) ? results_comment_in[1][0].zktor_video_category_name : '';
														results_ignore[0].zktor_video_duration = timeAgo(new Date(results_ignore[0].created_date).toISOString());
														result_data.vide_details = results_ignore[0];
														// result_data.comment_count = results_comment[1][0].numrows;
														//result_data.zktor_video_duration = timeAgo(new Date(result_data.created_date).toISOString());
														final_array.push(result_data);
														if (idx === array.length - 1) {
															let max_pages = parseInt(Math.ceil((results[1][0].numrows) / no_of_records_per_page));
															if (req.query.page_no && req.query.page_no <= max_pages) {
																let page_no = req.query.page_no;
																// PAGINATION START
																let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
																//  let sliceData = final_array.slice(offset, offset + no_of_records_per_page)
																var pagination = {
																	total_rows: results[1][0].numrows,
																	total_pages: parseInt(Math.ceil((results[1][0].numrows) / no_of_records_per_page)),
																	per_page: no_of_records_per_page,
																	offset: offset,
																	current_page_no: page_no
																};
																return res.status(200).send({
																	status: 200,
																	msg: "Success",
																	wishlistVideoListCount: results[1][0].numrows,
																	wishlistVideoList: final_array,
																	pagination: pagination
																});
															} else {
																return res.status(404).send({
																	status: 404,
																	msg: "Page no missing or Its incorrect."
																});
															}
														}
													});
												});
											}
										});
									});
								});
							} else {
								if (idx === array.length - 1) {
									return res.status(200).send({
										status: 200,
										msg: "Success",
										wishlistVideoList: final_array
									});
								}
							}
						});
					});
				} else {
					if (idx === array.length - 1) {
						return res.status(200).send({
							status: 200,
							msg: "Success",
							wishlistVideoList: final_array
						});
					}
				}


			} else {
				return res.status(404).send({
					status: 404,
					msg: "Record not found"
				});
			}
		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_recent = async (req, res) => {
	try {
	if (req.query.user_id && req.query.page_no) {
		var no_of_records_per_page = 10;
		var rowno = req.query.page_no;
		if (rowno != 0) {
			rowno = (rowno - 1) * no_of_records_per_page;
		}
		db.query(`SELECT * FROM tbl_zktor_video_recent inner join tbl_zktor_video ON tbl_zktor_video_recent.recent_zktor_video_id=tbl_zktor_video.zktor_video_id where tbl_zktor_video_recent.recent_user_id=? order by recent_id DESC LIMIT ? OFFSET ?; SELECT COUNT(*) AS numrows FROM tbl_zktor_video_recent inner join tbl_zktor_video ON tbl_zktor_video_recent.recent_zktor_video_id=tbl_zktor_video.zktor_video_id where tbl_zktor_video_recent.recent_user_id=?`, [req.query.user_id, no_of_records_per_page, rowno, req.query.user_id], function(error, results, fields) {
			if (error) throw error;
			if (results[0].length > 0) {
				var final_array = [];
				var final_array_one = [];
				var comment = [];
				var rating = 0;
				var rating_count = 0;
				var flag = 2;
				if (results[0].length > 0) {
					const merged = results[0].concat(results[1]);
					//console.log(merged);
					Object.keys(results[0]).forEach(function(key, idx, array) {
						var result_data = results[0][key];
						db.query(`SELECT * FROM tbl_zktor_video where zktor_video_id=?`, [result_data.recent_zktor_video_id], function(error, results_ignore, fields) {
							if (error) throw error;
							if (results_ignore.length > 0) {

								db.query(`SELECT * FROM tbl_zktor_video_like where zktor_video_user_id=? AND zktor_video_id=?;SELECT * FROM tbl_zktor_video_like where zktor_video_id=? ORDER BY zktor_video_like_id DESC LIMIT 2;SELECT  *  FROM tbl_zktor_video_subscriber where subscriber_to_user_id=? and subscriber_by_user_id=?;SELECT * FROM tbl_zktor_video_folder where zktor_video_folder_id=?`, [req.query.zktor_video_user_id, result_data.zktor_video_id, result_data.zktor_video_id, req.query.zktor_video_user_id, req.query.vistor_user_id, result_data.zktor_video_folder_id], function(error, results_rating, fields) {
									if (error) throw error;
									if (results_rating[0].length > 0) {
										result_data.user_reaction = results_rating[0][0].video_feeling_string;
									} else {
										result_data.user_reaction = '';
									}
									if (results_rating[1].length > 0) {
										result_data.first_video_feeling_string = results_rating[1][0].video_feeling_string;
									} else {
										result_data.first_video_feeling_string = '';
									}
									if (results_rating[1].length > 1) {
										result_data.second_video_feeling_string = results_rating[1][1].video_feeling_string;
									} else {
										result_data.second_video_feeling_string = '';
									}
									db.query(`SELECT * FROM tbl_user_profile where user_id=?; SELECT COUNT(*) AS numrows FROM tbl_zktor_video_comment where comment_zktor_video_id=? and comment_operation=?;SELECT * FROM tbl_user_profile where user_id=?;SELECT COUNT(*) AS numrows FROM tbl_zktor_video_recent where recent_zktor_video_id=? and recent_user_id=?`, [result_data.zktor_video_user_id, result_data.zktor_video_id, '0', results_rating[0].zktor_video_user_id, result_data.zktor_video_id, req.query.zktor_video_user_id], function(error, results_comment, fields) {
										if (error) throw error;
										if (results_comment[0].length > 0) {
											result_data.user_name = results_comment[0][0].user_name;
											result_data.user_profile_img = results_comment[0][0].user_profile_img;
											result_data.user_profile_background = results_comment[0][0].user_profile_background;
											result_data.user_channel_id = results_comment[0][0].user_channel_id;
											result_data.user_channel_name = results_comment[0][0].user_channel_name;
										} else {
											result_data.user_name = '';
											result_data.user_profile_img = '';
											result_data.user_profile_background = '';
											result_data.user_channel_id = '';
											result_data.user_channel_name = '';
										}
										if (results_comment[2].length > 0) {
											result_data.last_reacted_user = results_comment[2][0].user_name;
										} else {
											result_data.last_reacted_user = '';
										}
										if (results_comment[3].length > 0) {
											result_data.wishlist_flag = results_comment[3][0].numrows > 0 ? 1 : 0;
										} else {
											result_data.wishlist_flag = 0;
										}
										// if (results_rating[2].length > 0) {
										//     result_data.subscriber_flag = results_rating[2][0].status;
										//     result_data.bell_icon = results_rating[2][0].bell_icon;
										// } else {
										//     result_data.subscriber_flag = "2";
										//     result_data.bell_icon = "2";
										// }
										// if (results_rating[3].length > 0) {
										//     result_data.folder_details = results_rating[3][0];

										// } else {
										//     result_data.folder_details = [];
										// }
										delete(result_data.recent_zktor_video_id);
										delete(result_data.recent_user_id);
										//    result_data.vide_details = results_ignore[0];
										// result_data.comment_count = results_comment[1][0].numrows;
										// result_data.zktor_video_duration = timeAgo(new Date(result_data.created_date).toISOString());
										db.query(`SELECT * FROM tbl_zktor_video_ignore where zktor_video_id=? AND zktor_video_user_id=?;SELECT * FROM tbl_zktor_video_channel_ignore where zktor_video_ignored_by_user_id=? AND zktor_video_ignored_to_user_id=?`, [results_ignore[0].zktor_video_id, req.query.zktor_video_user_id, results_ignore[0].zktor_video_user_id, req.query.zktor_video_user_id], function(error, results_ignore_in, fields) {
											if (error) throw error;
											if (results_ignore_in[0].length <= 0 && results_ignore_in[1].length <= 0) {

												db.query(`SELECT * FROM tbl_zktor_video_like where zktor_video_user_id=? AND zktor_video_id=?;SELECT * FROM tbl_zktor_video_like where zktor_video_id=? ORDER BY zktor_video_like_id DESC LIMIT 2;SELECT  *  FROM tbl_zktor_video_subscriber where subscriber_to_user_id=? and subscriber_by_user_id=?;SELECT  *  FROM tbl_zktor_video_folder where zktor_video_folder_id=?`, [req.query.zktor_video_user_id, results_ignore[0].zktor_video_id, results_ignore[0].zktor_video_id, req.query.zktor_video_user_id, req.query.vistor_user_id, results_ignore[0].zktor_video_folder_id], function(error, results_rating_in, fields) {
													if (error) throw error;
													var user = 0;
													// if (results_rating_in[0].length > 0) {
													//     results_ignore[0].user_reaction = results_rating_in[0][0].video_feeling_string;
													// } else {
													//     results_ignore[0].user_reaction = '';
													// }
													if (results_rating_in[1].length > 0) {
														user = results_rating_in[1][0].zktor_video_user_id;
														results_ignore[0].first_video_feeling_string = results_rating_in[1][0].video_feeling_string;
													} else {
														results_ignore[0].first_video_feeling_string = '';
													}
													if (results_rating_in[1].length > 1) {
														results_ignore[0].second_video_feeling_string = results_rating_in[1][1].video_feeling_string;
													} else {
														results_ignore[0].second_video_feeling_string = '';
													}

													db.query(`SELECT * FROM tbl_user_profile where user_id=?; SELECT * FROM tbl_zktor_video_category where zktor_video_category_id=?;SELECT * FROM tbl_user_profile where user_id=?;SELECT COUNT(*) AS numrows FROM tbl_zktor_video_wishlist where wishlist_zktor_video_id=? and wishlist_user_id=?`, [results_ignore[0].zktor_video_user_id, results_ignore[0].zktor_video_category_id, user, results_ignore[0].zktor_video_id, req.query.zktor_video_user_id], function(error, results_comment_in, fields) {
														if (error) throw error;

														if (results_comment_in[0].length > 0) {
															results_ignore[0].user_name = results_comment_in[0][0].user_name;
															results_ignore[0].user_profile_img = results_comment_in[0][0].user_profile_img;
															results_ignore[0].user_profile_background = results_comment_in[0][0].user_profile_background;
															results_ignore[0].user_channel_id = results_comment_in[0][0].user_channel_id;
															results_ignore[0].user_channel_name = results_comment_in[0][0].user_channel_name;
														} else {
															results_ignore[0].user_name = '';
															results_ignore[0].user_profile_img = '';
															results_ignore[0].user_profile_background = '';
															results_ignore[0].user_channel_id = '';
															results_ignore[0].user_channel_name = '';
														}
														if (results_comment_in[2].length > 0) {
															results_ignore[0].last_reacted_user = results_comment_in[2][0].user_name;
														} else {
															results_ignore[0].last_reacted_user = '';
														}
														// if (results_comment_in[3].length > 0) {
														//     results_ignore[0].wishlist_flag = results_comment_in[3][0].numrows > 0 ? 1 : 0;
														// } else {
														//     results_ignore[0].wishlist_flag = 0;
														// }
														if (results_rating_in[2].length > 0) {
															//  results_ignore[0].subscriber_flag = results_rating_in[2][0].status;
															results_ignore[0].bell_icon = results_rating_in[2][0].bell_icon;
														} else {
															//results_ignore[0].subscriber_flag = "2";
															results_ignore[0].bell_icon = "2";
														}
														results_ignore[0].zktor_video_category_name = (results_comment_in[1].length > 0) ? results_comment_in[1][0].zktor_video_category_name : '';
														results_ignore[0].zktor_video_duration = timeAgo(new Date(results_ignore[0].created_date).toISOString());
														result_data.vide_details = results_ignore[0];
														final_array.push(result_data);
														if (idx === array.length - 1) {
															let max_pages = parseInt(Math.ceil((results[1][0].numrows) / no_of_records_per_page));
															if (req.query.page_no && req.query.page_no <= max_pages) {
																let page_no = req.query.page_no;
																// PAGINATION START
																let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
																//  let sliceData = final_array.slice(offset, offset + no_of_records_per_page)
																var pagination = {
																	total_rows: results[1][0].numrows,
																	total_pages: parseInt(Math.ceil((results[1][0].numrows) / no_of_records_per_page)),
																	per_page: no_of_records_per_page,
																	offset: offset,
																	current_page_no: page_no
																};
																return res.status(200).send({
																	status: 200,
																	msg: "Success",
																	recentVideoListCount: results[1][0].numrows,
																	recentVideoList: final_array,
																	pagination: pagination
																});
															} else {
																return res.status(404).send({
																	status: 404,
																	msg: "Page no missing or Its incorrect."
																});
															}
														}
													});
												});
											}
										});
									});
								});
							} else {
								if (idx === array.length - 1) {
									return res.status(200).send({
										status: 200,
										msg: "Success",
										recentVideoList: final_array
									});
								}
							}
						});
					});
				} else {
					if (idx === array.length - 1) {
						return res.status(200).send({
							status: 200,
							msg: "Success",
							recentVideoList: final_array
						});
					}
				}


			} else {
				return res.status(404).send({
					status: 404,
					msg: "Record not found"
				});
			}
		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_folder = async (req, res) => {
	try {
	if (req.query.user_id) {
		var final_array = [];
		db.query(`SELECT * FROM tbl_zktor_video_folder where zktor_video_user_id=?`, [req.query.user_id], function(error, results, fields) {
			if (error) throw error;
			else {
				if (results.length > 0) {
					Object.keys(results).forEach(function(key, idx, array) {
						var result_data = results[key];
						db.query(`SELECT  COUNT(*) AS numrows  FROM tbl_zktor_video where zktor_video_folder_id=?;SELECT * FROM tbl_zktor_video WHERE zktor_video_folder_id = ? ORDER BY rand() LIMIT 1`, [result_data.zktor_video_folder_id, result_data.zktor_video_folder_id, '1'], function(error, results_comment1, fields) {
							if (error) throw error;
							else {

								if (results_comment1[0].length > 0) {

									result_data.video_count = results_comment1[0][0].numrows;
									//  result_data.zktor_video_thumbnail_url = results_comment1[1][0].zktor_video_thumbnail_url;

								} else {

									result_data.video_count = results_comment1[0][0].numrows;
									// result_data.zktor_video_thumbnail_url = '';

								}
								if (results_comment1[1].length > 0) {

									//  result_data.video_count = results_comment1[0][0].numrows;
									result_data.zktor_video_thumbnail_url = results_comment1[1][0].zktor_video_thumbnail_url;

								} else {

									//result_data.video_count = results_comment1[0][0].numrows;
									result_data.zktor_video_thumbnail_url = '';

								}
								final_array.push(result_data);
								if (idx === array.length - 1) {
									return res.status(200).send({
										status: 200,
										msg: "Success",
										folderListCount: final_array.length,
										folderList: final_array
									});
								}
							}
						});
					});
				} else {
					return res.status(400).send({
						status: 400,
						msg: "fail"
					});
				}
			}
		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}

	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_zktor_video_comment = async (req, res) => {
	try {
	if (req.query.comment_zktor_video_id) {
		var comment = [];
		db.query(`SELECT * FROM tbl_zktor_video_comment where comment_zktor_video_id=? and comment_operation=?`, [req.query.comment_zktor_video_id, '0'], function(error, results_comment, fields) {
			if (error) throw error;
			if (results_comment.length > 0) {
				//console.log(timeAgo(new Date('2022-02-22 07:12:49').toISOString()));
				Object.keys(results_comment).forEach(function(key12, idx12, array12) {
					var results_comment_data = results_comment[key12];
					db.query(`SELECT * FROM tbl_user_profile where user_id=?;SELECT reaction_comment_id, COUNT(*) as total FROM tbl_zktor_video_comment_reaction WHERE reaction_comment_id = ? GROUP BY reaction_comment_id`, [results_comment_data.comment_user_id, results_comment_data.comment_id], function(error, results_comment1, fields) {
						if (error) throw error;
						if (results_comment1[0].length > 0) {
							results_comment_data.user_name = results_comment1[0][0].user_name;
							results_comment_data.user_profile_img = results_comment1[0][0].user_profile_img;
						} else {
							results_comment_data.user_name = '';
							results_comment_data.user_profile_img = '';
						}
						if (results_comment1[1].length > 0)
							results_comment_data.reaction_count = results_comment1[1][0].total;
						else
							results_comment_data.reaction_count = 0;
						results_comment_data.is_friend = (res.totalfriendsList.includes(results_comment_data.comment_user_id)) ? "1" : "0";
						if (results_comment_data.created_date != '0000-00-00 00:00:00')
							results_comment_data.comment_ago = timeAgo(new Date(results_comment_data.created_date).toISOString());
						else
							results_comment_data.comment_ago = 'just now';


						var comment_re = [];
						db.query(`SELECT * FROM tbl_zktor_video_comment_reply where comment_id=? and comment_reply_operation!=?`, [results_comment_data.comment_id, '2'], function(error, results_comment_re, fields) {
							if (error) throw error;
							if (results_comment_re.length > 0) {
								Object.keys(results_comment_re).forEach(function(key_re, idx_re, array_re) {
									var results_comment_reply_data = results_comment_re[key_re];
									db.query(`SELECT * FROM tbl_user_profile where user_id=?`, [results_comment_reply_data.comment_reply_user_id, results_comment_reply_data.comment_reply_id], function(error, results_comment_reply, fields) {
										if (error) throw error;
										if (results_comment_reply.length > 0) {
											results_comment_reply_data.user_name = results_comment_reply[0].user_name;
											results_comment_reply_data.user_profile_img = results_comment_reply[0].user_profile_img;
										} else {
											results_comment_reply_data.user_name = '';
											results_comment_reply_data.user_profile_img = '';
										}
										results_comment_reply_data.is_friend = (res.totalfriendsList.includes(results_comment_reply_data.comment_reply_user_id)) ? "1" : "0";
										if (results_comment_reply_data.created_date != '0000-00-00 00:00:00')
											results_comment_reply_data.comment_reply_ago = timeAgo(new Date(results_comment_reply_data.created_date).toISOString());
										else
											results_comment_reply_data.comment_reply_ago = 'just now';
										comment_re.push(results_comment_reply_data);
										if (idx_re === array_re.length - 1) {
											results_comment_data.comment_replies = comment_re;
											comment.push(results_comment_data);
											if (idx12 === array12.length - 1) {
												return res.status(200).send({
													status: 200,
													msg: "Success",
													//   commentListCount: comment.length,
													commentList: comment
												});
											}
										}

									});
								});
							} else {
								results_comment_data.comment_replies = [];
								comment.push(results_comment_data);
								if (idx12 === array12.length - 1) {
									return res.status(200).send({
										status: 200,
										msg: "Success",
										// commentListCount: comment.length,
										commentList: comment
									});
								}
							}

						});
					});
				});
			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}
		});

	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_reaction_list = async (req, res) => {
	try {
	if (req.query.zktor_video_id && req.query.user_id) {
		var reaction = [];
		db.query(`SELECT * FROM tbl_zktor_video_like where zktor_video_id=? `, [req.query.zktor_video_id], function(error, results_reaction, fields) {
			if (error) throw error;
			if (results_reaction.length > 0) {
				Object.keys(results_reaction).forEach(function(key12, idx12, array12) {
					var results_reaction_data = results_reaction[key12];
					db.query(`SELECT * FROM tbl_user_profile where user_id=?`, [results_reaction_data.zktor_video_user_id], function(error, results_reaction1, fields) {
						if (error) throw error;
						if (results_reaction1.length > 0) {
							results_reaction_data.user_name = results_reaction1[0].user_name;
							results_reaction_data.user_profile_img = results_reaction1[0].user_profile_img;
							results_reaction_data.user_profile_background = results_reaction1[0].user_profile_background;
							results_reaction_data.user_channel_id = results_reaction1[0].user_channel_id;
							results_reaction_data.user_channel_name = results_reaction1[0].user_channel_name;
						} else {
							results_reaction_data.user_name = '';
							results_reaction_data.user_profile_img = '';
							results_reaction_data.user_profile_background = '';
							results_reaction_data.user_channel_id = '';
							results_reaction_data.user_channel_name = '';
						}
						results_reaction_data.is_friend = (res.totalfriendsList.includes(results_reaction_data.zktor_video_user_id)) ? "1" : "0";
						if (results_reaction_data.created_date != '0000-00-00 00:00:00')
							results_reaction_data.reacted_ago = timeAgo(new Date(results_reaction_data.created_date).toISOString());
						else
							results_reaction_data.reacted_ago = 'just now';
						reaction.push(results_reaction_data);
						if (idx12 === array12.length - 1) {
							return res.status(200).send({
								status: 200,
								msg: "Success",
								reactionListCount: reaction.length,
								reactionList: reaction
							});
						}
					});
				});
			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}
		});

	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.zktor_video_comments = async (req, res) => {
	try {
	var pagination = [];
	if (req.query.comment_zktor_video_id && req.query.user_id && req.query.page_no) {
		var no_of_records_per_page = 10;
		var rowno = req.query.page_no;
		if (rowno != 0) {
			rowno = (rowno - 1) * no_of_records_per_page;
		}
		var comment = [];
		db.query(res.pro, [req.query.comment_zktor_video_id, no_of_records_per_page, rowno, req.query.comment_zktor_video_id], function(error, results_comment, fields) {
			if (error) throw error;
			if (results_comment[0].length > 0) {
				//console.log(timeAgo(new Date('2022-02-22 07:12:49').toISOString()));
				Object.keys(results_comment[0]).forEach(function(key12, idx12, array12) {
					var results_comment_data = results_comment[0][key12];
					db.query(`SELECT * FROM tbl_user_profile where user_id=?;SELECT reaction_comment_id, COUNT(*) as total FROM tbl_zktor_video_comment_reaction WHERE reaction_comment_id = ? GROUP BY reaction_comment_id;SELECT * FROM tbl_zktor_video_comment_reaction where reaction_comment_id=?`, [results_comment_data.comment_user_id, results_comment_data.comment_id, results_comment_data.comment_id], function(error, results_comment1, fields) {
						if (error) throw error;
						if (results_comment1[0].length > 0) {
							results_comment_data.user_name = results_comment1[0][0].user_name;
							results_comment_data.user_profile_img = results_comment1[0][0].user_profile_img;
						} else {
							results_comment_data.user_name = '';
							results_comment_data.user_profile_img = '';
						}
						if (results_comment1[1].length > 0)
							results_comment_data.reaction_count = results_comment1[1][0].total;
						else
							results_comment_data.reaction_count = 0;
						results_comment_data.user_reaction_string = (results_comment1[2].length > 0) ? results_comment1[2][0].comment_feeling_string : '';
						results_comment_data.is_friend = (res.totalfriendsList.includes(results_comment_data.comment_user_id)) ? "1" : "0";
						if (results_comment_data.created_date != '0000-00-00 00:00:00')
							results_comment_data.comment_ago = timeAgo(new Date(results_comment_data.created_date).toISOString());
						else
							results_comment_data.comment_ago = 'just now';


						var comment_re = [];
						db.query(`SELECT * FROM tbl_zktor_video_comment_reply where comment_id=? and comment_reply_operation!=?`, [results_comment_data.comment_id, '2'], function(error, results_comment_re, fields) {
							if (error) throw error;
							if (results_comment_re.length <= 0) {
								results_comment_re[0] = {
									comment_reply_user_id: '',
									comment_reply_id: ''
								}
							}
							if (results_comment_re.length > 0) {
								Object.keys(results_comment_re).forEach(function(key_re, idx_re, array_re) {
									var results_comment_reply_data = results_comment_re[key_re];
									db.query(`SELECT * FROM tbl_user_profile where user_id=?;SELECT reaction_comment_reply_id, COUNT(*) as total FROM tbl_zktor_video_comment_reply_reaction WHERE reaction_comment_reply_id = ? GROUP BY reaction_comment_reply_id;SELECT * FROM tbl_zktor_video_comment_reply_reaction where reaction_comment_reply_id=?`, [results_comment_reply_data.comment_reply_user_id, results_comment_reply_data.comment_reply_id, results_comment_reply_data.comment_reply_id, results_comment_reply_data.comment_reply_id], function(error, results_comment_reply, fields) {
										if (error) throw error;
										if (results_comment_reply[0].length > 0) {
											results_comment_reply_data.user_name = results_comment_reply[0][0].user_name;
											results_comment_reply_data.user_profile_img = results_comment_reply[0][0].user_profile_img;
										} else {
											results_comment_reply_data.user_name = '';
											results_comment_reply_data.user_profile_img = '';
										}
										if (results_comment_reply[1].length > 0)
											results_comment_reply_data.reaction_count = results_comment_reply[1][0].total;
										else
											results_comment_reply_data.reaction_count = 0;
										results_comment_reply_data.user_reaction_string = (results_comment_reply[2].length > 0) ? results_comment_reply[2][0].comment_feeling_string : '';
										results_comment_reply_data.is_friend = (res.totalfriendsList.includes(results_comment_reply_data.comment_reply_user_id)) ? "1" : "0";

										if (results_comment_reply_data.comment_reply_id != '') {
											if (results_comment_reply_data.created_date != '0000-00-00 00:00:00')
												results_comment_reply_data.comment_reply_ago = timeAgo(new Date(results_comment_reply_data.created_date).toISOString());
											else
												results_comment_reply_data.comment_reply_ago = 'just now';
											comment_re.push(results_comment_reply_data);
										}
										if (idx_re === array_re.length - 1) {
											results_comment_data.comment_replies = comment_re;
											comment.push(results_comment_data);
											if (idx12 === array12.length - 1) {
												let max_pages = parseInt(Math.ceil((results_comment[1][0].numrows) / no_of_records_per_page));
												if (req.query.page_no && req.query.page_no <= max_pages) {
													let page_no = req.query.page_no;

													// PAGINATION START

													let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
													//  let sliceData = final_array.slice(offset, offset + no_of_records_per_page)
													var pagination = {
														total_rows: results_comment[1][0].numrows,
														total_pages: parseInt(Math.ceil((results_comment[1][0].numrows) / no_of_records_per_page)),
														per_page: no_of_records_per_page,
														offset: offset,
														current_page_no: page_no
													};
													// PAGINATION END
													return res.status(200).send({
														status: 200,
														msg: "Success",
														commentListCount: results_comment[1][0].numrows,
														commentList: comment,
														pagination: pagination
													});
												} else {
													return res.status(404).send({
														status: 404,
														msg: "Page no missing or Its incorrect."
													});
												}
											}
										}

									});
								});
							} else {
								results_comment_data.comment_replies = [];
								comment.push(results_comment_data);
								if (idx12 === array12.length - 1) {
									let max_pages = parseInt(Math.ceil((results_comment[1][0].numrows) / no_of_records_per_page));
									if (req.query.page_no && req.query.page_no <= max_pages) {
										let page_no = req.query.page_no;

										// PAGINATION START

										let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
										//  let sliceData = final_array.slice(offset, offset + no_of_records_per_page)
										var pagination = {
											total_rows: results_comment[1][0].numrows,
											total_pages: parseInt(Math.ceil((results_comment[1][0].numrows) / no_of_records_per_page)),
											per_page: no_of_records_per_page,
											offset: offset,
											current_page_no: page_no
										};
										// PAGINATION END
										return res.status(200).send({
											status: 200,
											msg: "Success",
											commentListCount: results_comment[1][0].numrows,
											commentList: comment,
											pagination: pagination
										});
									} else {
										return res.status(404).send({
											status: 404,
											msg: "Page no missing or Its incorrect."
										});
									}
								}
							}

						});
					});
				});
			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}
		});

	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.zktor_video_comments_reply = async (req, res) => {
	try {
	if (req.query.comment_id) {

		var comment_re = [];
		db.query(`SELECT * FROM tbl_zktor_video_comment_reply where comment_id=? and comment_reply_operation!=?`, [req.query.comment_id, '2'], function(error, results_comment_re, fields) {
			if (error) throw error;
			if (results_comment_re.length > 0) {
				Object.keys(results_comment_re).forEach(function(key_re, idx_re, array_re) {
					var results_comment_reply_data = results_comment_re[key_re];
					db.query(`SELECT * FROM tbl_user_profile where user_id=?;SELECT  reaction_comment_reply_id , COUNT(*) as total FROM  tbl_zktor_video_comment_reply_reaction WHERE  reaction_comment_reply_id  = ? GROUP BY  reaction_comment_reply_id;SELECT * FROM tbl_zktor_video_comment_reply_reaction where reaction_comment_reply_id=? AND reaction_user_id=?`, [results_comment_reply_data.comment_reply_user_id, results_comment_reply_data.comment_reply_id, results_comment_reply_data.comment_reply_id, req.query.user_id], function(error, results_comment_reply, fields) {
						if (error) throw error;
						if (results_comment_reply[0].length > 0) {
							results_comment_reply_data.user_name = results_comment_reply[0][0].user_name;
							results_comment_reply_data.user_profile_img = results_comment_reply[0][0].user_profile_img;
						} else {
							results_comment_reply_data.user_name = '';
							results_comment_reply_data.user_profile_img = '';
						}
						results_comment_reply_data.reaction_count = (results_comment_reply[1].length > 0) ? results_comment_reply[1][0].total : 0;
						results_comment_reply_data.user_reaction_string = (results_comment_reply[2].length > 0) ? results_comment_reply[2][0].comment_reply_feeling_string : '';
						if (results_comment_reply_data.created_date != '0000-00-00 00:00:00')
							results_comment_reply_data.duration = timeAgo(new Date(results_comment_reply_data.created_date).toISOString());
						else
							results_comment_reply_data.duration = 'just now';
						comment_re.push(results_comment_reply_data);
						if (idx_re === array_re.length - 1) {

							return res.status(200).send({
								status: 200,
								msg: "Success",
								// commentReplyListCount: comment_re.length,
								commentReplyList: comment_re
							});
						}

					});
				});
			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}

		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.delete_recent = async (req, res) => {
	try {
	if (req.query.recent_id) {
		db.query(`DELETE from tbl_zktor_video_recent where recent_id=?`, [req.query.recent_id], function(error, results1, fields) {
			if (error) throw error;
			return res.status(200).send({
				status: 200,
				msg: "Success"
			});
		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.delete_wishlist = async (req, res) => {
	try {
	if (req.query.wishlist_id) {
		db.query(`DELETE from tbl_zktor_video_wishlist where wishlist_id=?`, [req.query.wishlist_id], function(error, results1, fields) {
			if (error) throw error;
			return res.status(200).send({
				status: 200,
				msg: "Success"
			});
		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.ignore_video = async (req, res) => {
	try {
	let upload = multer({
		storage: zktor,
	}).single('');
	upload(req, res, function(err) {
		if (err) {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		} else {
			if (req.body.zktor_video_id && req.body.zktor_video_user_id) {

				db.query(`INSERT INTO tbl_zktor_video_ignore SET ?`, [req.body], function(error, results66, fields) {
					if (error) {
						return res.status(400).send({
							status: 400,
							msg: "fail"
						});
					} else {
						return res.status(200).send({
							status: 200,
							msg: "Success"
						});
					}
				});

			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.ignore_channel_video = async (req, res) => {
	try {
	let upload = multer({
		storage: zktor,
	}).single('');
	upload(req, res, function(err) {
		if (err) {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		} else {
			if (req.body.zktor_video_ignored_by_user_id && req.body.zktor_video_ignored_to_user_id) {

				db.query(`INSERT INTO tbl_zktor_video_channel_ignore SET ?`, [req.body], function(error, results66, fields) {
					if (error) {
						return res.status(400).send({
							status: 400,
							msg: "fail"
						});
					} else {
						return res.status(200).send({
							status: 200,
							msg: "Success"
						});
					}
				});

			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_collection = async (req, res) => {
	try {
	let upload = multer({
		storage: zktor,
	}).single('');
	upload(req, res, function(err) {
		if (err) {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		} else {
			if (req.body.collection_name && req.body.collection_user_id) {
				db.query(`Select * From tbl_zktor_video_collection where collection_name= ? and collection_user_id=?;`, [req.body.collection_name, req.body.collection_user_id], function(error, results, fields) {
					if (error) {
						return res.status(400).send({
							status: 400,
							msg: "fail"
						});
					} else {
						if (results.length <= 0) {
							db.query(`INSERT INTO tbl_zktor_video_collection SET ?`, [req.body], function(error, results66, fields) {
								if (error) {
									return res.status(400).send({
										status: 400,
										msg: "fail"
									});
								} else {
									return res.status(200).send({
										status: 200,
										msg: "Success"
									});
								}
							});
						} else {

							return res.status(200).send({
								status: 200,
								msg: "Success"
							});
						}
					}
				});

			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.update_collection = async (req, res) => {
	try {
	let upload = multer({
		storage: zktor,
	}).single('');
	upload(req, res, function(err) {
		if (err) {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		} else {
			if (req.body.collection_id) {
				var collection_id = req.body.collection_id;
				delete(req.body.collection_id);
				db.query(`UPDATE tbl_zktor_video_collection SET ? where collection_id=?`, [req.body, collection_id], function(error, results66, fields) {
					if (error) {
						return res.status(400).send({
							status: 400,
							msg: "fail"
						});
					} else {
						return res.status(200).send({
							status: 200,
							msg: "Success"
						});
					}
				});

			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_collection_detail = async (req, res) => {
	try {
	let upload = multer({
		storage: zktor,
	}).single('');
	upload(req, res, function(err) {
		if (err) {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		} else {
			if (req.body.collection_id && req.body.zktor_video_id) {
				db.query(`Select * From tbl_zktor_video_collection_detail where collection_id= ? and zktor_video_id=?;`, [req.body.collection_id, req.body.zktor_video_id], function(error, results, fields) {
					if (error) {
						return res.status(400).send({
							status: 400,
							msg: "fail"
						});
					} else {
						if (results.length <= 0) {
							db.query(`INSERT INTO tbl_zktor_video_collection_detail SET ?`, [req.body], function(error, results66, fields) {
								if (error) {
									return res.status(400).send({
										status: 400,
										msg: "fail"
									});
								} else {
									return res.status(200).send({
										status: 200,
										msg: "Success"
									});
								}
							});
						} else {

							return res.status(200).send({
								status: 200,
								msg: "Success"
							});
						}
					}
				});

			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.add_notification = async (req, res) => {
	try {
	let upload = multer({
		storage: zktor,
	}).single('');
	upload(req, res, function(err) {
		if (err) {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		} else {
			if (req.body.notification_user_id) {

				db.query(`INSERT INTO tbl_zktor_video_notification SET ?`, [req.body], function(error, results66, fields) {
					if (error) {
						return res.status(400).send({
							status: 400,
							msg: "fail"
						});
					} else {
						return res.status(200).send({
							status: 200,
							msg: "Success"
						});
					}
				});

			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.update_notification = async (req, res) => {
	try {
	let upload = multer({
		storage: zktor,
	}).single('');
	upload(req, res, function(err) {
		if (err) {
			return res.status(400).send({
				status: 400,
				msg: "fail"
			});
		} else {
			if (req.body.notification_id) {
				var notification_id = req.body.notification_id;
				delete(req.body.notification_id);
				db.query(`UPDATE tbl_zktor_video_notification SET ? where notification_id=?`, [req.body, notification_id], function(error, results66, fields) {
					if (error) {
						return res.status(400).send({
							status: 400,
							msg: "fail"
						});
					} else {
						return res.status(200).send({
							status: 200,
							msg: "Success"
						});
					}
				});

			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}
		}
	});
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_comment_reaction = async (req, res) => {
	try {
	if (req.query.comment_id) {
		var comment_re = [];
		db.query(`SELECT comment_feeling_string, COUNT(*) as count FROM tbl_zktor_video_comment_reaction WHERE reaction_comment_id = ? GROUP BY comment_feeling_string`, [req.query.comment_id], function(error, results_comment_re, fields) {
			if (error) throw error;
			if (results_comment_re.length > 0) {
				//console.log(results_comment_re);
				var cccc = 0;
				Object.keys(results_comment_re).forEach(function(key_re, idx_re, array_re) {
					var results_comment_reply_data = results_comment_re[key_re];
					cccc = cccc + results_comment_reply_data.count;
					var comment_re_re = [];
					db.query(`SELECT * FROM tbl_zktor_video_comment_reaction where reaction_comment_id=? AND comment_feeling_string=?`, [req.query.comment_id, results_comment_reply_data.comment_feeling_string], function(error, results_comment_reply, fields) {
						if (error) {

						} else {

							Object.keys(results_comment_reply).forEach(function(key_re1, idx_re1, array_re1) {
								var results_comment_reply_data_re = results_comment_reply[key_re1];

								db.query(`SELECT user_id,user_name,user_profile_img,user_phone FROM tbl_user_profile where user_id=?;SELECT DISTINCT receiver_user_id,sender_user_id FROM tbl_friend_request WHERE (receiver_user_id = ? or sender_user_id = ?) AND request_status = ? `, [results_comment_reply_data_re.reaction_user_id, results_comment_reply_data_re.reaction_user_id, results_comment_reply_data_re.reaction_user_id, '1'], function(error, results_comment_reply_re, fields) {
									if (error) {

									} else {

										if (results_comment_reply_re[0].length > 0) {
											results_comment_reply_re[0][0].friendCount = results_comment_reply_re[1].length;
											comment_re_re.push(results_comment_reply_re[0][0]);
										}
										if (idx_re1 === array_re1.length - 1) {
											results_comment_reply_data.user = comment_re_re;
											comment_re.push(results_comment_reply_data);
											if (idx_re === array_re.length - 1) {

												return res.status(200).send({
													status: 200,
													msg: "Success",
													totalCommentReactionCount: cccc,
													commentCountList: comment_re
												});
											}
										}
									}
								});
							});
						}
					});
				});
			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}

		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_all_subscriber_detail = async (req, res) => {
	try {
	if (req.query.subscriber_by_user_id) {

		var comment_re = [];
		db.query(`SELECT * FROM tbl_zktor_video_subscriber WHERE subscriber_by_user_id = ? AND status=?`, [req.query.subscriber_by_user_id, '1'], function(error, results_comment_re, fields) {
			if (error) throw error;
			if (results_comment_re.length > 0) {
				Object.keys(results_comment_re).forEach(function(key_re, idx_re, array_re) {
					var results_comment_reply_data = results_comment_re[key_re];
					db.query(`SELECT * FROM tbl_user_profile where user_id=?;SELECT  COUNT(*) AS numrows  FROM tbl_zktor_video_subscriber where subscriber_to_user_id=? and status=?`, [results_comment_reply_data.subscriber_to_user_id, results_comment_reply_data.subscriber_to_user_id, '1'], function(error, results_comment_reply, fields) {
						if (error) throw error;
						if (results_comment_reply[0].length > 0) {
							results_comment_reply_data.user_id = results_comment_reply[0][0].user_id;
							results_comment_reply_data.user_name = results_comment_reply[0][0].user_name;
							results_comment_reply_data.user_profile_img = results_comment_reply[0][0].user_profile_img;
							results_comment_reply_data.user_profile_background = results_comment_reply[0][0].user_profile_background;
							results_comment_reply_data.user_channel_id = results_comment_reply[0][0].user_channel_id;
							results_comment_reply_data.user_channel_name = results_comment_reply[0][0].user_channel_name;
						} else {
							results_comment_reply_data.user_id = '';
							results_comment_reply_data.user_name = '';
							results_comment_reply_data.user_profile_img = '';
							results_comment_reply_data.user_profile_background = '';
							results_comment_reply_data.user_channel_id = '';
							results_comment_reply_data.user_channel_name = '';
						}

						results_comment_reply_data.subscriber_count = results_comment_reply[1][0].numrows;
						comment_re.push(results_comment_reply_data);
						if (idx_re === array_re.length - 1) {

							return res.status(200).send({
								status: 200,
								msg: "Success",
								subscriber_count: comment_re.length,
								subscriberList: comment_re
							});
						}

					});
				});
			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}

		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_collection_data = async (req, res) => {
	try {
	if (req.query.user_id) {
		var array = [];
		var final_array = [];
		db.query(`SELECT  * FROM tbl_zktor_video_collection where collection_user_id=?;SELECT user_name,user_profile_img,user_profile_background,user_channel_id,user_channel_name FROM tbl_user_profile where user_id=? `, [req.query.user_id, req.query.user_id], function(error, results_comment12, fields) {
			if (error) {} else {
				if (results_comment12[0].length > 0) {

					Object.keys(results_comment12[0]).forEach(function(key16, idx16, array16) {
						var result_data12 = results_comment12[0][key16];
						db.query(`SELECT  * FROM tbl_zktor_video_collection_detail where collection_id=? `, [result_data12.collection_id], function(error, results_comment, fields) {
							if (error) {
								return res.status(400).send({
									status: 400,
									msg: "fail"
								});
							} else {
								//console.log(results_comment);
								var bar = new Promise((resolve, reject) => {
									if (results_comment.length <= 0) {
										results_comment[0] = {
											collection_detail_id: '',
											collection_id: '',
											zktor_video_id: '',
											created_date: "",
											modified_date: ""
										};
									}
									if (results_comment.length > 0) {
										var main_v = [];
										var video = [];

										Object.keys(results_comment).forEach(function(key1, idx1, array1) {
											var result_data = results_comment[key1];
											db.query(`SELECT * FROM tbl_zktor_video where zktor_video_id=?`, [result_data.zktor_video_id], function(error, results_ignore, fields) {
												if (error) {
													return res.status(400).send({
														status: 400,
														msg: "fail"
													});
												} else {
													if (results_ignore.length > 0) {
														video.push({
															collection_detail_id: result_data.collection_detail_id,
															collection_id: result_data.collection_id,
															zktor_video_id: result_data.zktor_video_id,
															created_date: result_data.created_date,
															modified_date: result_data.modified_date,
															zktor_video_user_id: results_ignore[0].zktor_video_user_id,
															zktor_video_views: results_ignore[0].zktor_video_views,
															zktor_video_title: results_ignore[0].zktor_video_title,
															zktor_video_thumbnail_url: results_ignore[0].zktor_video_thumbnail_url,
															zktor_short_video_url: results_ignore[0].zktor_short_video_url,
															zktor_video_like_count: results_ignore[0].zktor_video_like_count,
															zktor_video_folder_id: results_ignore[0].zktor_video_folder_id,
															zktor_video_language: results_ignore[0].zktor_video_language,
															zktor_video_rated: results_ignore[0].zktor_video_rated,
															zktor_video_rated_content: results_ignore[0].zktor_video_rated_content,
															zktor_video_description: results_ignore[0].zktor_video_description,
															zktor_video_video_length: results_ignore[0].zktor_video_video_length
														});
														main_v.push({
															collection_detail_id: result_data.collection_detail_id,
															collection_id: result_data.collection_id,
															zktor_video_id: result_data.zktor_video_id,
															created_date: result_data.created_date,
															modified_date: result_data.modified_date,
															zktor_video_user_id: results_ignore[0].zktor_video_user_id,
															zktor_video_views: results_ignore[0].zktor_video_views,
															zktor_video_title: results_ignore[0].zktor_video_title,
															zktor_video_thumbnail_url: results_ignore[0].zktor_video_thumbnail_url,
															zktor_short_video_url: results_ignore[0].zktor_short_video_url,
															zktor_video_like_count: results_ignore[0].zktor_video_like_count,
															zktor_video_folder_id: results_ignore[0].zktor_video_folder_id,
															zktor_video_language: results_ignore[0].zktor_video_language,
															zktor_video_rated: results_ignore[0].zktor_video_rated,
															zktor_video_rated_content: results_ignore[0].zktor_video_rated_content,
															zktor_video_description: results_ignore[0].zktor_video_description,
															zktor_video_video_length: results_ignore[0].zktor_video_video_length
														});
													}
													//main_v.push(video);
													if (idx1 === array1.length - 1) {


														result_data12.user_name = '';
														result_data12.user_profile_img = '';
														result_data12.user_profile_background = '';
														result_data12.user_channel_id = '';
														result_data12.user_channel_name = '';
														result_data12.vide_list = main_v;
														//  }

														final_array.push(result_data12);
														resolve();
													}
												}
											});
										});

									} else {
										if (idx16 == array16.length - 1) {
											result_data12.user_name = '';
											result_data12.user_profile_img = '';
											result_data12.user_profile_background = '';
											result_data12.user_channel_id = '';
											result_data12.user_channel_name = '';
											result_data12.vide_list = [];
											final_array.push(result_data12);
											resolve();
										}
									}
								});
								bar.then(() => {
									if (idx16 == array16.length - 1) {
										return res.status(200).send({
											status: 200,
											msg: "Success",
											collectionDetaillList: final_array
										});
									}
								});
							}
						});
					});

				} else {
					return res.status(400).send({
						status: 400,
						msg: "fail"
					});
				}
			}
		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}

	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_ignore_video = async (req, res) => {
	try {
	if (req.query.zktor_video_user_id) {

		var comment_re = [];
		db.query(`SELECT * FROM tbl_zktor_video_ignore WHERE zktor_video_user_id = ?`, [req.query.zktor_video_user_id], function(error, results_comment_re, fields) {
			if (error) throw error;
			if (results_comment_re.length > 0) {
				Object.keys(results_comment_re).forEach(function(key_re, idx_re, array_re) {
					var results_comment_reply_data = results_comment_re[key_re];
					db.query(`SELECT * FROM tbl_zktor_video where zktor_video_id=?;`, [results_comment_reply_data.zktor_video_id], function(error, results_comment_reply, fields) {
						if (error) throw error;
						if (results_comment_reply.length > 0) {

							results_comment_reply_data.zktor_video_title = results_comment_reply[0].zktor_video_title;
							results_comment_reply_data.zktor_video_thumbnail_url = results_comment_reply[0].zktor_video_thumbnail_url;
							results_comment_reply_data.zktor_video_video_length = results_comment_reply[0].zktor_video_video_length;

						} else {
							results_comment_reply_data.zktor_video_title = '';
							results_comment_reply_data.zktor_video_thumbnail_url = '';
							results_comment_reply_data.zktor_video_video_length = '';

						}
						comment_re.push(results_comment_reply_data);
						if (idx_re === array_re.length - 1) {

							return res.status(200).send({
								status: 200,
								msg: "Success",
								ignoreVideoListCount: comment_re.length,
								ignoreVideoList: comment_re
							});
						}

					});
				});
			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}

		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.remove_ignore_video = async (req, res) => {
	try {
	if (req.query.zktor_video_id && req.query.zktor_video_user_id) {
		db.query(`DELETE from tbl_zktor_video_ignore where zktor_video_id=? and zktor_video_user_id=?`, [req.query.zktor_video_id, req.query.zktor_video_user_id], function(error, results1, fields) {
			if (error) throw error;
			return res.status(200).send({
				status: 200,
				msg: "Success"
			});
		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_ignore_video_channel = async (req, res) => {
	try {
	if (req.query.user_id) {

		var comment_re = [];
		db.query(`SELECT * FROM tbl_zktor_video_channel_ignore WHERE zktor_video_ignored_by_user_id = ?`, [req.query.user_id], function(error, results_comment_re, fields) {
			if (error) throw error;
			if (results_comment_re.length > 0) {
				Object.keys(results_comment_re).forEach(function(key_re, idx_re, array_re) {
					var results_comment_reply_data = results_comment_re[key_re];
					db.query(`SELECT * FROM tbl_user_profile where user_id=?;SELECT  COUNT(*) AS numrows  FROM tbl_zktor_video_subscriber where subscriber_to_user_id=? and status=?`, [results_comment_reply_data.zktor_video_ignored_to_user_id, results_comment_reply_data.zktor_video_ignored_to_user_id, '1'], function(error, results_comment_reply, fields) {
						if (error) throw error;
						if (results_comment_reply[0].length > 0) {

							results_comment_reply_data.user_name = results_comment_reply[0][0].user_name;
							results_comment_reply_data.user_profile_img = results_comment_reply[0][0].user_profile_img;
							results_comment_reply_data.user_profile_background = results_comment_reply[0][0].user_profile_background;
							results_comment_reply_data.user_channel_id = results_comment_reply[0][0].user_channel_id;
							results_comment_reply_data.user_channel_name = results_comment_reply[0][0].user_channel_name;
						} else {
							results_comment_reply_data.user_name = '';
							results_comment_reply_data.user_profile_img = '';
							results_comment_reply_data.user_profile_background = '';
							results_comment_reply_data.user_channel_id = '';
							results_comment_reply_data.user_channel_name = '';
						}

						results_comment_reply_data.subscriber_count = results_comment_reply[1][0].numrows;
						comment_re.push(results_comment_reply_data);
						if (idx_re === array_re.length - 1) {

							return res.status(200).send({
								status: 200,
								msg: "Success",
								ignoreVideoChannelListCount: comment_re.length,
								ignoreVideoChannelList: comment_re
							});
						}

					});
				});
			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}

		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.remove_channel_ignore_video = async (req, res) => {
	try {
	if (req.query.zktor_video_ignored_by_user_id && req.query.zktor_video_ignored_to_user_id) {
		db.query(`DELETE from tbl_zktor_video_channel_ignore where zktor_video_ignored_by_user_id=? and zktor_video_ignored_to_user_id=?`, [req.query.zktor_video_ignored_by_user_id, req.query.zktor_video_ignored_to_user_id], function(error, results1, fields) {
			if (error) throw error;
			return res.status(200).send({
				status: 200,
				msg: "Success"
			});
		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.delete_collection_data = async (req, res) => {
	try {
	if (req.query.collection_id) {
		db.query(`DELETE from tbl_zktor_video_collection where collection_id=? `, [req.query.collection_id], function(error, results1, fields) {
			if (error) throw error;
			return res.status(200).send({
				status: 200,
				msg: "Success"
			});
		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.delete_collection_detail = async (req, res) => {
	try {
	if (req.query.collection_detail_id) {
		db.query(`DELETE from tbl_zktor_video_collection_detail where collection_detail_id=? `, [req.query.collection_detail_id], function(error, results1, fields) {
			if (error) throw error;
			return res.status(200).send({
				status: 200,
				msg: "Success"
			});
		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_video_notification = async (req, res) => {
	try {
	if (req.query.notification_user_id) {

		var comment_re = [];
		db.query(`SELECT * FROM tbl_zktor_video_notification where notification_user_id=? order by notification_id desc`, [req.query.notification_user_id], function(error, results_comment_re, fields) {
			if (error) throw error;
			if (results_comment_re.length > 0) {
				return res.status(200).send({
					status: 200,
					msg: "Success",
					notificationListCount: results_comment_re.length,
					notificationList: results_comment_re
				});

			} else {
				return res.status(400).send({
					status: 400,
					msg: "fail"
				});
			}

		});
	} else {
		return res.status(400).send({
			status: 400,
			msg: "fail"
		});
	}
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
