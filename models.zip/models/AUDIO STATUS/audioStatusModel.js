
const fs = require('fs');
const db = require("../../config/connection");
var timeAgo = require('node-time-ago');
const {
    getVideoDurationInSeconds
} = require('get-video-duration');
const multer = require('fastify-multer');
const crypto = require("crypto");
var path = require('path')
var zktor = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, '../uploads/ztkor_audio_media/');
    },
    filename: function(req, file, cb) {
        cb(null, "zktor_audio_media_" + crypto.createHash('md5').update('abcdefgh').digest('hex') + Date.now() + path.extname(file.originalname));
    }
});
exports.get_zktor_audio_status = async (req, res) => {
	try {
    if (req.query.page_no) {
        var no_of_records_per_page = 10;
        var rowno = req.query.page_no;
        if (rowno != 0) {
            rowno = (rowno - 1) * no_of_records_per_page;
        }
        db.query(`SELECT * FROM tbl_zktor_status_audio ORDER BY RAND() LIMIT ? OFFSET ?; SELECT COUNT(*) AS numrows FROM tbl_zktor_status_audio`, [no_of_records_per_page, rowno], function(error, results, fields) {
            if (error) throw error;
            if (results[0].length > 0) {
                var final_array = [];
                var final_array_one = [];
                var comment = [];
                var rating = 0;
                var rating_count = 0;
                var flag = 2;
                if (results[0].length > 0) {
                    const merged = results[0].concat(results[1]);
                    console.log(merged);
                    Object.keys(results[0]).forEach(function(key, idx, array) {
                        var result_data = results[0][key];

                          db.query(` SELECT * FROM tbl_zktor_status_audio_category where zktor_status_audio_category_id=?`, [result_data.zktor_status_audio_category_id], function(error, results_comment, fields) {
                            if (error) throw error;
                            // if (results_comment[0].length > 0) {
                            //     result_data.user_name = results_comment[0][0].user_name;
                            //     result_data.user_profile_img = results_comment[0][0].user_profile_img;
                            //     result_data.user_profile_background = results_comment[0][0].user_profile_background;
                            //     result_data.user_channel_id = results_comment[0][0].user_channel_id;
                            //     result_data.user_channel_name = results_comment[0][0].user_channel_name;
                            // } else {
                            //     result_data.user_name = '';
                            //     result_data.user_profile_img = '';
                            //     result_data.user_profile_background = '';
                            //     result_data.user_channel_id = '';
                            //     result_data.user_channel_name = '';
                            // }
                            if (results_comment.length > 0) {
                                result_data.zktor_status_audio_category = results_comment[0].zktor_status_audio_category;
                            } else {
                                result_data.zktor_status_audio_category = '';
                            }
                              if (result_data.created_date != '0000-00-00 00:00:00')
                              result_data.zktor_video_duration = timeAgo(new Date(result_data.created_date).toISOString());
                              else
                              result_data.zktor_video_duration  = 'just now';
                
                            final_array.push(result_data);
                            if (idx === array.length - 1) {
                                let max_pages = parseInt(Math.ceil((results[1][0].numrows) / no_of_records_per_page));
                                if (req.query.page_no && req.query.page_no <= max_pages) {
                                    let page_no = req.query.page_no;
                                    // PAGINATION START
                                    let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
                                    //  let sliceData = final_array.slice(offset, offset + no_of_records_per_page)
                                    var pagination = {
                                        total_rows: results[1][0].numrows,
                                        total_pages: parseInt(Math.ceil((results[1][0].numrows) / no_of_records_per_page)),
                                        per_page: no_of_records_per_page,
                                        offset: offset,
                                        current_page_no: page_no
                                    };
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        zktorAudioListCount: results[1][0].numrows,
                                        zktorAudioList: final_array,
                                        pagination: pagination
                                    });
                                } else {
                                    return res.status(404).send({
                                        status: 404,
                                        msg: "Page no missing or Its incorrect.",
                                         zktorAudioListCount: 0,
                                        zktorAudioList: [],
                                        pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                                    });
                                }
                            }
                        });
                    });
                } else {
                    if (idx === array.length - 1) {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success",
                            zktorAudioList: final_array
                        });
                    }
                }


            } else {
                return res.status(404).send({
                    status: 404,
                    msg: "Record not found",
                       zktorAudioListCount: 0,
                                        zktorAudioList: [],
                                        pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
               zktorAudioListCount: 0,
                                        zktorAudioList: [],
                                        pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_zktor_audio_status_category_id = async (req, res) => {
	try {
    if (req.query.page_no && req.query.zktor_status_audio_category_id) {
        var no_of_records_per_page = 10;
        var rowno = req.query.page_no;
        if (rowno != 0) {
            rowno = (rowno - 1) * no_of_records_per_page;
        }
        db.query(`SELECT * FROM tbl_zktor_status_audio where zktor_status_audio_category_id=?  LIMIT ? OFFSET ?; SELECT COUNT(*) AS numrows FROM tbl_zktor_status_audio where zktor_status_audio_category_id=?`, [req.query.zktor_status_audio_category_id, no_of_records_per_page, rowno, req.query.zktor_status_audio_category_id], function(error, results, fields) {
            if (error) throw error;
            if (results[0].length > 0) {
                var final_array = [];
                var final_array_one = [];
                var comment = [];
                var rating = 0;
                var rating_count = 0;
                var flag = 2;
                if (results[0].length > 0) {
                    const merged = results[0].concat(results[1]);
                    console.log(merged);
                    Object.keys(results[0]).forEach(function(key, idx, array) {
                        var result_data = results[0][key];

                     db.query(` SELECT * FROM tbl_zktor_status_audio_category where zktor_status_audio_category_id=?`, [result_data.zktor_status_audio_category_id], function(error, results_comment, fields) {
                            if (error) throw error;
                            // if (results_comment[0].length > 0) {
                            //     result_data.user_name = results_comment[0][0].user_name;
                            //     result_data.user_profile_img = results_comment[0][0].user_profile_img;
                            //     result_data.user_profile_background = results_comment[0][0].user_profile_background;
                            //     result_data.user_channel_id = results_comment[0][0].user_channel_id;
                            //     result_data.user_channel_name = results_comment[0][0].user_channel_name;
                            // } else {
                            //     result_data.user_name = '';
                            //     result_data.user_profile_img = '';
                            //     result_data.user_profile_background = '';
                            //     result_data.user_channel_id = '';
                            //     result_data.user_channel_name = '';
                            // }
                            if (results_comment.length > 0) {
                                result_data.zktor_status_audio_category = results_comment[0].zktor_status_audio_category;
                            } else {
                                result_data.zktor_status_audio_category = '';
                            }
                          
                             if (result_data.created_date != '0000-00-00 00:00:00')
                             result_data.zktor_audio_duration = timeAgo(new Date(result_data.created_date).toISOString());
                        else
                             result_data.zktor_audio_duration  = 'just now';
                            final_array.push(result_data);
                            if (idx === array.length - 1) {
                                let max_pages = parseInt(Math.ceil((results[1][0].numrows) / no_of_records_per_page));
                                if (req.query.page_no && req.query.page_no <= max_pages) {
                                    let page_no = req.query.page_no;
                                    // PAGINATION START
                                    let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
                                    //  let sliceData = final_array.slice(offset, offset + no_of_records_per_page)
                                    var pagination = {
                                        total_rows: results[1][0].numrows,
                                        total_pages: parseInt(Math.ceil((results[1][0].numrows) / no_of_records_per_page)),
                                        per_page: no_of_records_per_page,
                                        offset: offset,
                                        current_page_no: page_no
                                    };
                                    return res.status(200).send({
                                        status: 200,
                                        msg: "Success",
                                        audioCategoryListCount: results[1][0].numrows,
                                        audioCategoryList: final_array,
                                        pagination: pagination
                                    });
                                } else {
                                    return res.status(404).send({
                                        status: 404,
                                        msg: "Page no missing or Its incorrect.",
                                         audioCategoryListCount: 0,
                                        audioCategoryList: [],
                                         pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }

                                    });
                                }
                            }
                        });
                    });
                } else {
                    if (idx === array.length - 1) {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success",
                            audioCategoryList: final_array
                        });
                    }
                }


            } else {
                return res.status(404).send({
                    status: 404,
                    msg: "Record not found",
                     audioCategoryListCount: 0,
                                        audioCategoryList: [],
                                         pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
             audioCategoryListCount: 0,
                                        audioCategoryList: [],
                                         pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_zktor_audio_status_category = async (req, res) => {
	try {
    if (req.query.page_no) {
        var no_of_records_per_page = 10;
        var rowno = req.query.page_no;
        if (rowno != 0) {
            rowno = (rowno - 1) * no_of_records_per_page;
        }
        db.query(`SELECT * FROM tbl_zktor_status_audio_category LIMIT ? OFFSET ?; SELECT COUNT(*) AS numrows FROM tbl_zktor_status_audio_category `, [no_of_records_per_page, rowno], function(error, results, fields) {
            if (error) throw error;
            if (results[0].length > 0) {
                var final_array = [];
                var final_array_one = [];
                var comment = [];
                var rating = 0;
                var rating_count = 0;
                var flag = 2;
                if (results[0].length > 0) {
                    let max_pages = parseInt(Math.ceil((results[1][0].numrows) / no_of_records_per_page));
                    if (req.query.page_no && req.query.page_no <= max_pages) {
                        let page_no = req.query.page_no;
                        // PAGINATION START
                        let offset = parseInt(Math.ceil((page_no * no_of_records_per_page) - no_of_records_per_page));
                        //  let sliceData = final_array.slice(offset, offset + no_of_records_per_page)
                        var pagination = {
                            total_rows: results[1][0].numrows,
                            total_pages: parseInt(Math.ceil((results[1][0].numrows) / no_of_records_per_page)),
                            per_page: no_of_records_per_page,
                            offset: offset,
                            current_page_no: page_no
                        };
                        return res.status(200).send({
                            status: 200,
                            msg: "Success",
                            zktoraudioCategoryListCount: results[1][0].numrows,
                            zktoraudioCategoryList: results[0],
                            pagination: pagination
                        });
                    } else {
                        return res.status(404).send({
                            status: 404,
                            msg: "Page no missing or Its incorrect.",
                             zktoraudioCategoryListCount: 0,
                                        zktoraudioCategoryList: [],
                                         pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                        });
                    }
                } else {
                    if (idx === array.length - 1) {
                        return res.status(200).send({
                            status: 200,
                            msg: "Success",
                            zktoraudioCategoryList: final_array
                        });
                    }
                }


            } else {
                return res.status(404).send({
                    status: 404,
                    msg: "Record not found",
                               zktoraudioCategoryListCount: 0,
                                        zktoraudioCategoryList: [],
                                         pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
                });
            }
        });
    } else {
        return res.status(400).send({
            status: 400,
            msg: "fail",
                       zktoraudioCategoryListCount: 0,
                                        zktoraudioCategoryList: [],
                                         pagination:  {
                                        total_rows: 0,
                                        total_pages: 0,
                                        per_page: 0,
                                        offset: 0,
                                        current_page_no: '0'
                                    }
        });
    }
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_zktor_audio_status_category_without_pagination = async (req, res) => {
	try {

    db.query(`SELECT * FROM tbl_zktor_status_audio_category`, function(error, results, fields) {
        if (error) throw error;
        if (results.length > 0) {
            var final_array = [];
            var final_array_one = [];
            var comment = [];
            var rating = 0;
            var rating_count = 0;
            var flag = 2;
            if (results.length > 0) {

                return res.status(200).send({
                    status: 200,
                    msg: "Success",
                    zktoraudioCategoryListCount: results.length,
                    zktoraudioCategoryList: results

                });

            } else {

                return res.status(200).send({
                    status: 200,
                    msg: "Success",
                    zktoraudioCategoryList: final_array
                });
            }


        } else {
            return res.status(404).send({
                status: 404,
                msg: "Record not found"
            });
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
exports.get_zktor_audio_category_without_pagination = async (req, res) => {
	try {
    var comment = [];
    db.query(`SELECT * FROM tbl_zktor_status_audio_category`, function(error, results_comment, fields) {
        if (error) throw error;
        if (results_comment.length > 0) {

            return res.status(200).send({
                status: 200,
                msg: "Success",
                zktoraudioCategoryListCount: results_comment.length,
                zktoraudioCategoryList: results_comment
            });

        } else {
            return res.status(400).send({
                status: 400,
                msg: "fail"
            });
        }
    });
	} catch (err) {
		let errorName = define.DEFAULT_ERROR_NAME;
		let errorMessage = define.DEFAULT_ERROR_MESSAGE;
		if (err.name)
			errorName = err.name;
		if (err.message)
			errorMessage = err.message;
		return res.status(400).send({
			status: 400,
			error: errorName,
			msg: errorMessage
		});
	}
};
